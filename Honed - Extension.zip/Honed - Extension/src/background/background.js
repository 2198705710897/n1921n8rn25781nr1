/**
 * Background Service Worker
 * Handles API requests and caching for the X Community Detector extension
 * Uses shared API client from api.js
 */

// Import database module first (loads indexedDBStorage global)
import { storage as indexedDBStorage } from '../shared/database.js';

// Make available globally for api.js
self.indexedDBStorage = indexedDBStorage;

// Import Google Sheets sync service
import './sheets-sync.js';

// Import shared API client
import { api } from '../shared/api.js';

// Add MEVX-specific method to the imported api client
api.getMevxTokenData = async function(tokenAddress) {
  const url = `https://api.mevx.io/api/v1/pools/search?q=${encodeURIComponent(tokenAddress)}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`MEVX API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error(`[API] MEVX fetch failed for ${tokenAddress}:`, error);
    throw error;
  }
};

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchCommunityInfo') {
    api.getCommunity(request.communityId)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchUserProfile' || request.action === 'fetchFullProfile') {
    api.getUserProfile(request.username)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchMevxTokenData') {
    api.getMevxTokenData(request.tokenAddress)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'clearCache') {
    api.clearCache()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'getCacheStats') {
    const stats = api.getStats();
    sendResponse({ success: true, stats });
    return true;
  }

  if (request.action === 'registerCommunityOwner') {
    const { communityName, adminUsername } = request;

    // Get existing community owners
    chrome.storage.local.get(['communityOwners'], (result) => {
      const owners = result.communityOwners || {};
      const existingOwner = owners[communityName];

      let responseData = {
        isFirstOwner: !existingOwner,
        isVerified: true,
        realOwner: existingOwner || null
      };

      // If no existing owner, register this one
      if (!existingOwner) {
        owners[communityName] = adminUsername;
        chrome.storage.local.set({ communityOwners: owners }, () => {
          sendResponse({ success: true, data: responseData });
        });
      } else {
        // Check if this admin matches the registered owner
        responseData.isVerified = existingOwner.toLowerCase() === adminUsername.toLowerCase();
        sendResponse({ success: true, data: responseData });
      }
    });
    return true;
  }
});

// Inject content scripts into existing tabs on install/update
chrome.runtime.onInstalled.addListener(async () => {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://trade.padre.gg/trenches*' });

    for (const tab of tabs) {
      try {
        // Inject CSS first
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['src/styles/content.css']
        });

        // Then inject JS
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['src/shared/storage.js', 'src/content/content.js', 'src/content/core.js']
        });
      } catch (err) {
        // Silently skip tabs that can't be injected
      }
    }
  } catch (err) {
    console.error('❌ Error injecting scripts:', err);
  }
});

// Log cache statistics on startup
chrome.storage.local.get(null, (items) => {
  const cacheKeys = Object.keys(items).filter(key =>
    key.startsWith('community_cache_') ||
    key.startsWith('user_profile_') ||
    key.startsWith('mevx_token_')
  );
});

// ============================================
// SPA Navigation Handling
// Triggers content script execution on client-side routing
// ============================================

// Helper function to inject all content scripts for padre.gg trenches
async function injectTrenchesScripts(tabId) {
  try {
    const scripts = [
      'src/shared/constants.js',
      'src/shared/sheets-data.js',
      'src/shared/comments-data.js',
      'src/shared/profile-tooltip-core.js',
      'src/shared/admin-display-core.js',
      'src/shared/community-api-core.js',
      'src/shared/mevx-api-client.js',
      'src/shared/admin-tokens-modal.js',
      'src/shared/score-filtered-tokens-modal.js',
      'src/shared/analytics-modal.js',
      'src/shared/leaderboard-modal.js',
      'src/content/content.js',
      'src/content/core.js',
      'src/content/tracked-tweets.js',
      'src/services/adminAlertAudio.js'
    ];

    for (const script of scripts) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: [script]
      });
    }

    // Inject CSS
    await chrome.scripting.insertCSS({
      target: { tabId: tabId },
      files: [
        'src/styles/content.css',
        'src/styles/admin-tokens-modal.css',
        'src/styles/analytics-modal.css',
        'src/styles/leaderboard-modal.css'
      ]
    });
  } catch (err) {
    // Script might already be injected - that's okay
  }
}

// Helper function to inject all content scripts for axiom.trade
async function injectAxiomScripts(tabId) {
  try {
    const scripts = [
      'src/shared/constants.js',
      'src/shared/sheets-data.js',
      'src/shared/comments-data.js',
      'src/shared/profile-tooltip-core.js',
      'src/shared/admin-display-core.js',
      'src/shared/community-api-core.js',
      'src/shared/mevx-api-client.js',
      'src/shared/admin-tokens-modal.js',
      'src/shared/score-filtered-tokens-modal.js',
      'src/shared/analytics-modal.js',
      'src/shared/leaderboard-modal.js',
      'src/content/axiom.js',
      'src/content/tracked-tweets.js',
      'src/services/adminAlertAudio.js'
    ];

    for (const script of scripts) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: [script]
      });
    }

    // Inject CSS
    await chrome.scripting.insertCSS({
      target: { tabId: tabId },
      files: [
        'src/styles/axiom.css',
        'src/styles/admin-tokens-modal.css',
        'src/styles/analytics-modal.css',
        'src/styles/leaderboard-modal.css'
      ]
    });
  } catch (err) {
    // Script might already be injected - that's okay
  }
}

// Track which tabs have scripts injected to avoid duplicate injection
const injectedTabs = new Set();

// Helper to determine which scripts to inject based on URL
async function injectScriptsForUrl(tabId, url) {
  // Check if already injected for this tab
  const tabKey = `${tabId}-${url.split('?')[0]}`;
  if (injectedTabs.has(tabKey)) {
    // Already injected, just trigger reprocessing
    chrome.tabs.sendMessage(tabId, { action: 'processTokenCards' }, () => {
      // Ignore errors
    });
    return;
  }

  if (url.includes('trade.padre.gg/trenches') || url.includes('trade.padre.gg/trade/')) {
    await injectTrenchesScripts(tabId);
    injectedTabs.add(tabKey);
  } else if (url.includes('axiom.trade')) {
    await injectAxiomScripts(tabId);
    injectedTabs.add(tabKey);
  }
}

// Listen for SPA history state changes (pushState/replaceState)
chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Listen for reference fragment updates (hash changes)
chrome.webNavigation.onReferenceFragmentUpdated.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Also listen for completed navigation (full page loads and SPA transitions)
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const url = details.url;
  if (url.includes('trade.padre.gg') || url.includes('axiom.trade')) {
    await injectScriptsForUrl(details.tabId, url);
  }
}, { url: [{ hostSuffix: '.padre.gg' }, { hostSuffix: '.trade' }] });

// Clear injected tabs tracker when tabs are closed or updated
chrome.tabs.onRemoved.addListener((tabId) => {
  // Remove all entries for this tab
  for (const key of injectedTabs) {
    if (key.startsWith(`${tabId}-`)) {
      injectedTabs.delete(key);
    }
  }
});
