/**
 * Google Sheets Sync Service
 * Runs in background service worker
 * Fetches admin stats and tokens from Vercel API (secure backend)
 * Uses IndexedDB for storage (no quota limits)
 */

import { storage as indexedDBStorage } from '../shared/database.js';
import { licenseValidator } from '../shared/license-validator.js';

class SheetsSyncService {
  constructor() {
    this.syncIntervalMinutes = 0.5; // 30 seconds - sync twice per minute for freshest data
    this.apiUrl = 'https://n1921n8rn25781nr1.vercel.app/api/sheets';
    this.isSyncing = false;
  }

  /**
   * Initialize the sync service
   */
  async init() {
    // Initialize license validator first
    await licenseValidator.init();

    // Use setInterval for 30-second sync intervals (chrome.alarms doesn't support < 1 minute)
    // Note: In service workers, setInterval may not persist across restarts, so we also set a backup alarm
    this.syncIntervalId = setInterval(() => {
      this.sync().catch(err => {
        console.error('[SheetsSync] Periodic sync failed:', err);
      });
    }, 30000); // 30 seconds

    // Set up a backup alarm (1 minute minimum) in case setInterval doesn't persist
    chrome.alarms.create('sheetsSync', {
      delayInMinutes: 1,
      periodInMinutes: 1
    });

    // Listen for alarm events (backup)
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'sheetsSync') {
        this.sync().catch(err => {
          console.error('[SheetsSync] Periodic sync failed:', err);
        });
      }
    });

    // Do initial sync after 2 seconds to let extension fully load
    setTimeout(() => this.sync(), 2000);
  }

  /**
   * Parse a number that may use European locale format (comma as decimal, period as thousands)
   * Handles both formats:
   * - European: "2,69" or "1.234,56" (comma decimal, period thousands)
   * - US: "2.69" or "1,234.56" (period decimal, comma thousands)
   */
  parseLocaleNumber(value) {
    if (!value) return 0;

    // If already a number, return as-is
    if (typeof value === 'number') return value;

    const str = String(value).trim();

    // Detect European format: last comma before end of number
    // European: "2,69" or "1.234,56" - comma is decimal separator
    // US: "2.69" or "1,234.56" - period is decimal separator

    // Check if the last separator is a comma (European decimal)
    const lastCommaIndex = str.lastIndexOf(',');
    const lastPeriodIndex = str.lastIndexOf('.');

    if (lastCommaIndex > lastPeriodIndex) {
      // European format: comma is decimal, period is thousands
      // Remove period (thousands), then replace comma with period (decimal)
      const normalized = str.replace(/\./g, '').replace(',', '.');
      return parseFloat(normalized) || 0;
    } else {
      // US format or already has period as decimal
      // Remove commas (thousands separator)
      const normalized = str.replace(/,/g, '');
      return parseFloat(normalized) || 0;
    }
  }

  /**
   * Fetch data from Vercel API
   * @param {string} range - Optional sheet range to fetch
   * @returns {Promise<Object>} API response
   */
  async fetchFromAPI(range = null) {
    // Add cache-busting timestamp to ensure fresh data
    const timestamp = Date.now();
    const url = range
      ? `${this.apiUrl}?range=${encodeURIComponent(range)}&_t=${timestamp}`
      : `${this.apiUrl}?_t=${timestamp}`;

    // Get auth token from license validator
    const token = await licenseValidator.getAuthToken();

    const headers = {
      'Content-Type': 'application/json'
    };

    // Add Authorization header if we have a valid token
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
      headers,
      // Ensure fetch doesn't use browser cache
      cache: 'no-store'
    });
    const data = await response.json();

    if (!response.ok) {
      // Check if it's an auth error
      if (response.status === 401) {
        throw new Error('License validation required. Please check your license key.');
      }
      throw new Error(data.error || 'API request failed');
    }

    if (!data.success) {
      throw new Error(data.error || 'API request failed');
    }

    return data;
  }

  /**
   * Parse admin stats from sheet data
   */
  parseAdminStats(values) {
    if (!values || values.length < 2) return {};

    const admins = {};
    let skippedRows = 0;
    let processedRows = 0;

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = row[0]?.toLowerCase().trim();

      if (!username) {
        skippedRows++;
        continue;
      }

      processedRows++;

      admins[username] = {
        admin_username: row[0]?.trim() || '',
        total_rating: this.parseLocaleNumber(row[1]),
        tokens_score_0: parseInt(row[2]) || 0,
        tokens_score_1: parseInt(row[3]) || 0,
        tokens_score_2: parseInt(row[4]) || 0,
        tokens_score_3: parseInt(row[5]) || 0,
        tokens_score_4: parseInt(row[6]) || 0,
        tokens_score_5: parseInt(row[7]) || 0,
        tokens_score_6: parseInt(row[8]) || 0,  // Column I (8) - Score 6 (Failed)
        total_tokens_created: parseInt(row[9]) || 0,
        winrate: this.parseLocaleNumber(row[10]) / 100, // Convert percentage to decimal
        avg_migrate_time: row[11]?.trim() || '',  // Column L (11) - Avg Migrate Time
        last_active: row[12]?.trim() || '',  // Column M (12) - Last Active
        last_updated: row[13]?.trim() || ''   // Column N (13) - Last Updated
      };
    }

    console.log('[SheetsSync] Parsed admin stats for', Object.keys(admins).length, 'admins from', processedRows, 'rows. Skipped', skippedRows, 'rows with empty usernames.');
    console.log('[SheetsSync] Admin usernames (first 10):', Object.keys(admins).slice(0, 10));

    return admins;
  }

  /**
   * Parse token data from sheet
   * @param {Array} values - Sheet values
   * @param {boolean} isFailed - Whether these are failed tokens (default: false)
   */
  parseTokens(values, isFailed = false) {
    if (!values || values.length < 2) return {};

    const tokens = {};
    let skippedRows = 0;
    let processedRows = 0;

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = row[0]?.toLowerCase().trim();

      if (!username) {
        skippedRows++;
        continue;
      }

      processedRows++;

      if (!tokens[username]) {
        tokens[username] = [];
      }

      tokens[username].push({
        admin_username: username,  // Already normalized to lowercase
        base_token: row[1]?.trim() || '',
        token_name: row[2]?.trim() || '',
        token_symbol: row[3]?.trim() || '',
        community_link: row[4]?.trim() || '',
        token_age: row[5]?.trim() || '',  // Column F (5) - Token Age (e.g., "24d ago")
        market_cap: this.parseLocaleNumber(row[6]),  // Column G - Current MC
        ath_market_cap: this.parseLocaleNumber(row[7]),  // Column H - ATH MC
        token_score: parseInt(row[8]) || 0,  // Column I - Score
        is_failed_token: isFailed  // Mark as failed token
      });
    }

    const sheetType = isFailed ? 'failed' : 'regular';
    console.log(`[SheetsSync] Parsed ${processedRows} ${sheetType} token rows for ${Object.keys(tokens).length} admins. Skipped ${skippedRows} rows with empty usernames.`);

    return tokens;
  }

  /**
   * Parse comments from Comments sheet
   * @param {Array} values - Sheet values
   * @returns {Object} Comments keyed by username
   */
  parseComments(values) {
    if (!values || values.length < 2) return {};

    const comments = {};
    let skippedRows = 0;
    let processedRows = 0;

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const username = row[1]?.toLowerCase().trim(); // Column B: admin_username

      if (!username) {
        skippedRows++;
        continue;
      }

      processedRows++;

      if (!comments[username]) {
        comments[username] = [];
      }

      comments[username].push({
        comment_id: row[0]?.trim() || '',
        admin_username: row[1]?.trim() || '',
        author: row[2]?.trim() || '',
        content: row[3]?.trim() || '',
        timestamp: row[4]?.trim() || '',
        updated_at: row[5]?.trim() || ''
      });
    }

    console.log(`[SheetsSync] Parsed ${processedRows} comment rows for ${Object.keys(comments).length} admins. Skipped ${skippedRows} rows with empty usernames.`);

    return comments;
  }

  /**
   * Parse daily stats from Daily Stats sheet
   * @param {Array} values - Sheet values
   * @returns {Array} Parsed daily stats objects
   */
  parseDailyStats(values) {
    if (!values || values.length < 2) return [];

    const dailyStats = [];

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const date = row[0]?.trim();

      if (!date) continue;

      dailyStats.push({
        date: date,  // YYYY-MM-DD format
        tokens_created: parseInt(row[1]) || 0,
        avg_score: this.parseLocaleNumber(row[2]),
        win_rate: this.parseLocaleNumber(row[3]),
        good_tokens_0_2: parseInt(row[4]) || 0,
        avg_migrate_time_hrs: this.parseLocaleNumber(row[5]),
        top_admin: row[6]?.trim() || '',
        top_admin_avg_score: this.parseLocaleNumber(row[7]),
        top_admin_tokens: parseInt(row[8]) || 0,
        token_1_address: row[9]?.trim() || '',
        token_1_score: parseInt(row[10]) || 0,
        token_1_ath: this.parseCurrency(row[11]),
        token_2_address: row[12]?.trim() || '',
        token_2_score: parseInt(row[13]) || 0,
        token_2_ath: this.parseCurrency(row[14]),
        token_3_address: row[15]?.trim() || '',
        token_3_score: parseInt(row[16]) || 0,
        token_3_ath: this.parseCurrency(row[17])
      });
    }

    console.log(`[SheetsSync] Parsed ${dailyStats.length} daily stats`);
    return dailyStats;
  }

  /**
   * Parse currency string to number
   * @param {string|number} value - Currency value like "$125,430.00"
   * @returns {number} Parsed number
   */
  parseCurrency(value) {
    if (!value) return 0;
    if (typeof value === 'number') return value;
    return parseFloat(String(value).replace(/[$,]/g, '')) || 0;
  }

  /**
   * Main sync function - stores admin stats, comments, and tokens
   */
  async sync() {
    // Check license first
    if (!licenseValidator.isLicenseValid()) {
      console.warn('[SheetsSync] Sync blocked - license invalid');
      throw new Error(licenseValidator.getErrorMessage());
    }

    // Check if already syncing - if so, wait for it to complete
    if (this.isSyncing) {
      // Wait for current sync to complete (max 30 seconds)
      const maxWait = 300;
      let waited = 0;
      while (this.isSyncing && waited < maxWait) {
        await new Promise(resolve => setTimeout(resolve, 100));
        waited++;
      }
      // If still syncing after timeout, throw error
      if (this.isSyncing) {
        throw new Error('Sync timed out (already in progress)');
      }
      // Storage was already updated by the original sync
      return;
    }

    try {
      this.isSyncing = true;

      // Clear previous error
      await this.clearError();

      // Fetch all data from Vercel API
      console.log('[SheetsSync] Fetching data from Vercel API...');
      const apiData = await this.fetchFromAPI();

      console.log('[SheetsSync] API returned data:', {
        admins: apiData.admins?.length || 0,
        tokens: apiData.tokens?.length || 0,
        failedTokens: apiData.failedTokens?.length || 0,
        comments: apiData.comments?.length || 0,
        dailyStats: apiData.dailyStats?.length || 0
      });

      // Parse admin stats
      const adminsData = this.parseAdminStats(apiData.admins || []);
      console.log('[SheetsSync] Parsed', Object.keys(adminsData).length, 'admins');

      // Parse tokens
      const tokensData = this.parseTokens(apiData.tokens || [], false);
      const failedTokensData = this.parseTokens(apiData.failedTokens || [], true);
      const commentsData = this.parseComments(apiData.comments || []);
      const dailyStatsData = this.parseDailyStats(apiData.dailyStats || []);

      // Merge regular and failed tokens
      const allTokens = { ...tokensData };
      for (const [username, tokenList] of Object.entries(failedTokensData)) {
        if (!allTokens[username]) {
          allTokens[username] = [];
        }
        allTokens[username].push(...tokenList);
      }

      const totalTokens = Object.values(allTokens).flat().length;
      console.log('[SheetsSync] Parsed', totalTokens, 'total tokens for', Object.keys(allTokens).length, 'admins');

      // Store admin stats, comments, tokens, and daily stats in IndexedDB (no quota limits)
      await indexedDBStorage.setAdminStats(adminsData);
      await indexedDBStorage.setComments(commentsData);
      await indexedDBStorage.setTokens(allTokens);
      await indexedDBStorage.setDailyStats(dailyStatsData);
      await indexedDBStorage.setLastSyncTime(Date.now());
      await indexedDBStorage.setMetadata('sheetsSyncError', null);

      // Notify all tabs to invalidate their cache
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.url && (tab.url.includes('trade.padre.gg') || tab.url.includes('axiom.trade'))) {
            chrome.tabs.sendMessage(tab.id, { action: 'sheetsDataUpdated' }).catch(() => {
              // Tab might not be ready to receive messages, ignore error
            });
          }
        }
      });

      console.log('[SheetsSync] Storage write successful');
      console.log('[SheetsSync] Stored', Object.keys(adminsData).length, 'admins with stats');
      console.log('[SheetsSync] Stored comments for', Object.keys(commentsData).length, 'admins');
      console.log('[SheetsSync] Stored', totalTokens, 'tokens for', Object.keys(allTokens).length, 'admins');
      console.log('[SheetsSync] Stored', dailyStatsData.length, 'daily stats');
      console.log('[SheetsSync] Sync completed successfully');

    } catch (error) {
      console.error('[SheetsSync] Sync failed:', error);
      await this.updateError(error.message);
      throw error;
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Fetch tokens for a specific admin from IndexedDB
   * Falls back to Vercel API if not found in IndexedDB
   * @param {string} username - Admin username
   * @returns {Promise<Array>} Array of token data
   */
  async fetchAdminTokens(username) {
    const usernameLower = username.toLowerCase().trim();

    try {
      // Try to get from IndexedDB first
      console.log('[SheetsSync] Fetching tokens for admin from IndexedDB:', usernameLower);
      const tokens = await indexedDBStorage.getTokens(usernameLower);

      if (tokens && tokens.length > 0) {
        console.log('[SheetsSync] Found', tokens.length, 'tokens in IndexedDB for admin:', usernameLower);
        return tokens;
      }

      // Fallback: Fetch from API (shouldn't happen after first full sync)
      console.log('[SheetsSync] No tokens in IndexedDB, fetching from API for admin:', usernameLower);

      const allTokens = [];

      // Fetch regular tokens for this admin
      const tokensData = await this.fetchFromAPI("'Tokens - Sorted by Admin'!A1:I");
      const parsedTokens = this.parseTokens(tokensData.values || []);

      if (parsedTokens[usernameLower]) {
        allTokens.push(...parsedTokens[usernameLower]);
      }

      // Fetch failed tokens for this admin
      const failedTokensData = await this.fetchFromAPI("'Tokens - Failed (Under 10k)'!A1:I");
      const parsedFailedTokens = this.parseTokens(failedTokensData.values || [], true);

      if (parsedFailedTokens[usernameLower]) {
        allTokens.push(...parsedFailedTokens[usernameLower]);
      }

      console.log('[SheetsSync] Fetched', allTokens.length, 'tokens from API for admin:', usernameLower);
      return allTokens;

    } catch (error) {
      console.error('[SheetsSync] Failed to fetch tokens for admin:', usernameLower, error);
      // Return empty array instead of throwing, so modal can still render
      return [];
    }
  }

  /**
   * Update error in storage
   */
  async updateError(error) {
    return await indexedDBStorage.setMetadata('sheetsSyncError', error);
  }

  /**
   * Clear error from storage
   */
  async clearError() {
    return await indexedDBStorage.setMetadata('sheetsSyncError', null);
  }

  /**
   * Manual trigger for sync
   */
  async manualSync() {
    await this.sync();
  }

  /**
   * Test connection by fetching from API
   */
  async testConnection() {
    try {
      const data = await this.fetchFromAPI("'Admins'!A1:N2");
      return { success: true, rowCount: data.values?.length || 0 };
    } catch (error) {
      throw error;
    }
  }

  /**
   * Append rows to Google Sheets (for adding new comments)
   * NOTE: This would need a separate API endpoint on Vercel
   * For now, this is a placeholder - write operations need to be implemented
   */
  async appendToSheets(range, values) {
    // TODO: Implement Vercel API endpoint for writing to sheets
    throw new Error('Write operations not yet implemented - please add endpoint to Vercel API');
  }

  /**
   * Update a specific cell in Google Sheets (for editing comments)
   * NOTE: This would need a separate API endpoint on Vercel
   */
  async updateSheetCell(range, value) {
    // TODO: Implement Vercel API endpoint for writing to sheets
    throw new Error('Write operations not yet implemented - please add endpoint to Vercel API');
  }

  /**
   * Delete a row from Google Sheets (for deleting comments)
   * NOTE: This would need a separate API endpoint on Vercel
   */
  async deleteSheetRow(rowIndex, sheetId = 0) {
    // TODO: Implement Vercel API endpoint for writing to sheets
    throw new Error('Write operations not yet implemented - please add endpoint to Vercel API');
  }

  /**
   * Find row number by comment ID
   * NOTE: This would need a separate API endpoint on Vercel
   */
  async findRowByCommentId(commentId) {
    // TODO: Implement Vercel API endpoint for searching sheets
    throw new Error('Search operations not yet implemented - please add endpoint to Vercel API');
  }

  /**
   * Create the Comments sheet if it doesn't exist
   * NOTE: This would need a separate API endpoint on Vercel
   */
  async ensureCommentsSheetExists() {
    // TODO: Implement Vercel API endpoint for sheet management
    return true; // Assume it exists for now
  }
}

// Initialize on service worker start
const sheetsSync = new SheetsSyncService();
sheetsSync.init();

// Listen for manual sync requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncSheetsNow') {
    sheetsSync.manualSync()
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'testSheetsConnection') {
    sheetsSync.testConnection()
      .then((result) => sendResponse({ success: true, ...result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === 'fetchAdminTokens') {
    sheetsSync.fetchAdminTokens(request.username)
      .then((tokens) => sendResponse({ success: true, tokens }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Add new comment
  if (request.action === 'addComment') {
    sheetsSync.appendToSheets("'Comments'!A1:F", [[
      request.commentId,
      request.username,
      request.author,
      request.content,
      request.timestamp,
      '' // updated_at is empty for new comments
    ]])
      .then(async () => {
        // Add to IndexedDB cache immediately
        await indexedDBStorage.addComment({
          comment_id: request.commentId,
          admin_username: request.username,
          author: request.author,
          content: request.content,
          timestamp: request.timestamp,
          updated_at: ''
        });
        sendResponse({ success: true });
      })
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Update existing comment
  if (request.action === 'updateComment') {
    sheetsSync.findRowByCommentId(request.commentId)
      .then(async (rowNumber) => {
        if (!rowNumber) {
          throw new Error('Comment not found');
        }
        // Update content (column D) and updated_at (column F)
        await sheetsSync.updateSheetCell(`'Comments'!D${rowNumber}`, request.content);
        await sheetsSync.updateSheetCell(`'Comments'!F${rowNumber}`, request.updatedAt);
        // Update IndexedDB cache immediately
        await indexedDBStorage.updateComment(request.commentId, {
          content: request.content,
          updated_at: request.updatedAt
        });
        return { success: true };
      })
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Delete comment
  if (request.action === 'deleteComment') {
    sheetsSync.findRowByCommentId(request.commentId)
      .then(async (rowNumber) => {
        if (!rowNumber) {
          throw new Error('Comment not found');
        }
        await sheetsSync.deleteSheetRow(rowNumber);
        // Delete from IndexedDB cache immediately
        await indexedDBStorage.deleteComment(request.commentId);
        return { success: true };
      })
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get admin stats from IndexedDB (for content scripts)
  if (request.action === 'getAdminStats') {
    indexedDBStorage.getAdminStats(request.username.toLowerCase())
      .then(admin => sendResponse({ success: true, admin }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get all admin stats from IndexedDB (for content scripts)
  if (request.action === 'getAllAdminStats') {
    indexedDBStorage.getAllAdminStats()
      .then(admins => sendResponse({ success: true, admins }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get last sync info from IndexedDB (for content scripts)
  if (request.action === 'getSyncInfo') {
    Promise.all([
      indexedDBStorage.getLastSyncTime(),
      indexedDBStorage.getMetadata('sheetsSyncError')
    ])
      .then(([lastSync, error]) => sendResponse({ success: true, lastSync, error }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // Get comments for a specific admin from IndexedDB (for content scripts)
  if (request.action === 'getAdminComments') {
    indexedDBStorage.getComments(request.username.toLowerCase())
      .then(comments => sendResponse({ success: true, comments }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get all comments from IndexedDB (for content scripts)
  if (request.action === 'getAllComments') {
    indexedDBStorage.getAllComments()
      .then(comments => sendResponse({ success: true, comments }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get all daily stats from IndexedDB (for content scripts)
  if (request.action === 'getAllDailyStats') {
    indexedDBStorage.getAllDailyStats()
      .then(dailyStats => sendResponse({ success: true, dailyStats }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  // Get daily stats for a specific date from IndexedDB (for content scripts)
  if (request.action === 'getDailyStats') {
    indexedDBStorage.getDailyStats(request.date)
      .then(stat => sendResponse({ success: true, stat }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SheetsSyncService;
}
