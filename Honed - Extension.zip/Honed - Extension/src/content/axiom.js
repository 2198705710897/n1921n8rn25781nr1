// Axiom.trade Content Script
// Uses borderOverlay pattern for visual styling on token cards

(async function() {
  'use strict';

  // ============================================
  // LICENSE CHECK - Always validates with server
  // ============================================
  let licenseCheckInterval = null;
  let isLicenseValid = false;

  // Initial license check (with server)
  isLicenseValid = await checkLicense();
  if (!isLicenseValid) {
    console.log('[Honed] License invalid - content script disabled');
    return; // Stop all execution
  }

  // Start periodic license validation (every 30 seconds)
  licenseCheckInterval = setInterval(async () => {
    const valid = await checkLicense();
    if (!valid) {
      console.log('[Honed] License invalidated during runtime - stopping content script');
      clearInterval(licenseCheckInterval);
      // Reload page to force re-validation
      window.location.reload();
    }
  }, 30000); // 30 seconds

  // Cleanup interval on page unload
  window.addEventListener('beforeunload', () => {
    if (licenseCheckInterval) {
      clearInterval(licenseCheckInterval);
    }
  });

  async function checkLicense() {
    // Get license key and device ID
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey', 'honedDeviceId'], async (result) => {
        const key = result.licenseKey;
        const deviceId = result.honedDeviceId;

        if (!key) {
          resolve(false);
          return;
        }

        try {
          // Always validate with server - don't trust cached storage
          const response = await fetch('https://n1921n8rn25781nr1.vercel.app/api/validate?key=' + encodeURIComponent(key) + '&deviceId=' + encodeURIComponent(deviceId || ''));
          const data = await response.json();

          if (data.valid) {
            resolve(true);
          } else {
            console.log('[Honed] Server validation: invalid -', data.reason);
            resolve(false);
          }
        } catch (error) {
          console.error('[Honed] Validation error:', error);
          // On network error, deny access (fail-closed)
          resolve(false);
        }
      });
    });
  }

  // Helper to safely call Chrome APIs
  function safeChromeAPI(apiCall, fallback) {
    try {
      return apiCall();
    } catch (e) {
      if (e.message.includes('Extension context invalidated')) {
        return fallback;
      }
      throw e;
    }
  }

  // In-memory cache for community data
  const communityDataCache = new Map();
  const processedCards = new Set();

  // Track tokens that have already played their admin alert (persists across page navigations)
  let playedAlertTokens = new Set();
  let playedAlertsLoaded = false;

  // Load played alerts from storage on init (returns Promise)
  function loadPlayedAlerts() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['playedAdminAlerts'], (result) => {
        if (result.playedAdminAlerts && Array.isArray(result.playedAdminAlerts)) {
          playedAlertTokens = new Set(result.playedAdminAlerts);
          console.log('[AdminAlert] Loaded', playedAlertTokens.size, 'played alerts from storage');
        }
        playedAlertsLoaded = true;
        resolve();
      });
    });
  }

  // Check if token has already played alert
  function hasPlayedAlert(tokenAlertId) {
    return playedAlertTokens.has(tokenAlertId);
  }

  // Mark token as having played alert and persist to storage
  function markAlertPlayed(tokenAlertId) {
    playedAlertTokens.add(tokenAlertId);
    chrome.storage.local.set({ playedAdminAlerts: Array.from(playedAlertTokens) });
  }

  // Settings cache
  let cachedSettings = {
    xCommunityEnabled: true,
    trackedGradientEnabled: true,
    adminBackgroundEnabled: true,
    trackedBorderColor: '#22d3ee',
    trackedGradientColor: '#22d3ee',
    normalAdminColor: '#1a1a2e',
    trackedGradientOpacity: 20,
    showAdminInfo: true,
    showMemberPreview: true,
    showFollowerCount: true,
    showTrackBlacklistButtons: true,
    communityVerificationEnabled: true,
    showSheetScores: true
  };

  let cachedTrackedAdmins = [];
  let cachedBlacklistedAdmins = [];
  let trackedUsernamesSet = new Set();
  let blacklistedUsernamesSet = new Set();

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      safeChromeAPI(() => {
        chrome.storage.sync.get({
          xCommunityEnabled: true,
          trackedGradientEnabled: true,
          adminBackgroundEnabled: true,
          trackedBorderColor: '#22d3ee',
          trackedGradientColor: '#22d3ee',
          normalAdminColor: '#1a1a2e',
          trackedGradientOpacity: 20,
          showAdminInfo: true,
          showMemberPreview: true,
          showFollowerCount: true,
          showTrackBlacklistButtons: true,
          communityVerificationEnabled: true,
          showSheetScores: true,
          showChartScoreDistro: true
        }, (settings) => {
          resolve(settings);
        });
      }, () => resolve({
        xCommunityEnabled: true,
        trackedGradientEnabled: true,
        adminBackgroundEnabled: true,
        trackedBorderColor: '#22d3ee',
        trackedGradientColor: '#22d3ee',
        normalAdminColor: '#1a1a2e',
        trackedGradientOpacity: 20,
        showAdminInfo: true,
        showMemberPreview: true,
        showFollowerCount: true,
        showTrackBlacklistButtons: true,
        communityVerificationEnabled: true,
        showSheetScores: true,
        showChartScoreDistro: true
      }));
    });
  }

  // Get tracked admins from storage
  async function getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  // Get blacklisted admins from storage
  async function getBlacklistedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['blacklistedAdmins'], (result) => {
        resolve(result.blacklistedAdmins || []);
      });
    });
  }

  // Update cached tracked admins
  function updateCachedTrackedAdmins(admins) {
    cachedTrackedAdmins = admins;
    trackedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Update cached blacklisted admins
  function updateCachedBlacklistedAdmins(admins) {
    cachedBlacklistedAdmins = admins;
    blacklistedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Extract community ID from URL
  function extractCommunityId(url) {
    const match = url.match(/(?:x\.com|twitter\.com)\/i\/communities\/(\d+)/);
    return match ? match[1] : null;
  }

  // Fetch community information from background worker
  async function fetchCommunityInfo(communityId) {
    if (communityDataCache.has(communityId)) {
      return communityDataCache.get(communityId);
    }

    const data = await new Promise((resolve, reject) => {
      safeChromeAPI(() => {
        chrome.runtime.sendMessage({
          action: 'fetchCommunityInfo',
          communityId: communityId
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response?.error || 'Failed to fetch community info'));
          }
        });
      }, () => reject(new Error('Extension context invalidated')));
    });

    communityDataCache.set(communityId, data);
    return data;
  }

  // Format follower count
  function formatNumber(count) {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    }
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  }

  // ============================================
  // ProfileTooltip - Cursor-following hover tooltip
  // Extends ProfileTooltipCore with sheet stats functionality
  // ============================================
  class ProfileTooltip extends ProfileTooltipCore {
    constructor() {
      super();
    }

    async _loadAndShow() {
      if (!this.tooltip) {
        this.tooltip = this._createTooltip();
      }

      this._setLoading();
      this.tooltip.style.display = 'block';
      this.tooltip.style.pointerEvents = 'auto'; // Ensure it can receive events when shown
      this.isActive = true;

      // Initial position near target element with viewport boundary checking
      const rect = this.targetElement.getBoundingClientRect();
      const offset = 8;
      const tooltipRect = this.tooltip.getBoundingClientRect();

      // Calculate initial position (right of target)
      let left = rect.right + offset;
      let top = rect.top;

      // Prevent right edge overflow - show to the left instead
      if (left + tooltipRect.width > window.innerWidth) {
        left = rect.left - tooltipRect.width - offset;
      }

      // Prevent bottom edge overflow
      if (top + tooltipRect.height > window.innerHeight) {
        top = window.innerHeight - tooltipRect.height - offset;
      }

      // Also prevent top overflow
      if (top < offset) {
        top = offset;
      }

      // Prevent left overflow
      if (left < offset) {
        left = offset;
      }

      this.tooltip.style.left = `${left}px`;
      this.tooltip.style.top = `${top}px`;

      try {
        const data = await this._fetchProfile(this.currentUsername);
        this._populate(data);

        // Re-check boundaries after content loads (dimensions may have changed)
        const newRect = this.tooltip.getBoundingClientRect();
        let newLeft = parseFloat(this.tooltip.style.left);
        let newTop = parseFloat(this.tooltip.style.top);

        if (newLeft + newRect.width > window.innerWidth) {
          newLeft = window.innerWidth - newRect.width - offset;
        }
        if (newLeft < offset) {
          newLeft = offset;
        }
        if (newTop + newRect.height > window.innerHeight) {
          newTop = window.innerHeight - newRect.height - offset;
        }
        if (newTop < offset) {
          newTop = offset;
        }

        this.tooltip.style.left = `${newLeft}px`;
        this.tooltip.style.top = `${newTop}px`;
      } catch (err) {
        console.error('[ProfileTooltip] Failed to fetch profile:', err);
        this._setError();
      }
    }

    async _fetchProfile(username) {
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'fetchUserProfile', username },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (response?.success && response?.data) {
              resolve(response.data);
            } else {
              reject(new Error(response?.error || 'Fetch failed'));
            }
          }
        );
      });
    }

    async _populate(data) {
      // Use core's populate method for basic profile data
      this._populateData(data);

      // Add sheet stats section - use the original Community API username
      // NOT the profile API username, as they may differ in casing/format
      await this._addSheetStatsSection(this.currentUsername);
    }

    // Add sheet stats section to tooltip
    async _addSheetStatsSection(username) {
      if (typeof SheetsData === 'undefined') return;

      const stats = await SheetsData.getAdminStats(username);
      if (!stats) return;

      const tooltip = this.tooltip;

      // Remove ALL existing stats sections (for when hovering over different admins)
      const existingSections = tooltip.querySelectorAll('.tooltip-sheet-stats');
      existingSections.forEach(section => section.remove());

      const contentArea = tooltip.querySelector('.tooltip-content');
      if (!contentArea) return;

      const scoreData = SheetsData.formatScore(stats.total_rating);

      // Create score section
      const scoreSection = document.createElement('div');
      scoreSection.className = 'tooltip-sheet-stats';

      scoreSection.innerHTML = `
        <div class="sheet-stats-divider"></div>
        <div class="sheet-stats-header">Admin Performance</div>
        <div class="sheet-stats-grid">
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Rating</span>
            <span class="sheet-stat-value ${scoreData.class}" style="color: ${scoreData.color}">
              ${scoreData.formatted}
            </span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Tokens</span>
            <span class="sheet-stat-value">${stats.total_tokens_created || 0}</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Winrate</span>
            <span class="sheet-stat-value">${((stats.winrate || 0) * 100).toFixed(0)}%</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Failed</span>
            <span class="sheet-stat-value score-poor">${stats.tokens_score_6 || 0}</span>
          </div>
        </div>
        <div class="score-distribution">
          <div class="dist-label">Score Distribution</div>
          <div class="dist-grid">
            ${[0,1,2,3,4,5].map(score => {
              const count = stats[`tokens_score_${score}`] || 0;
              return `
                <div class="dist-cell dist-cell-${score}">
                  <span class="dist-cell-score">${score}</span>
                  <div class="dist-cell-divider"></div>
                  <span class="dist-cell-count">${count}</span>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;

      contentArea.appendChild(scoreSection);
    }
  }

  // Create singleton tooltip instance
  const profileTooltip = new ProfileTooltip();

  // Create singleton modal instances
  const adminTokensModal = typeof AdminTokensModal !== 'undefined' ? new AdminTokensModal(profileTooltip) : null;
  const analyticsModal = typeof AnalyticsModal !== 'undefined' ? new AnalyticsModal() : null;
  const leaderboardModal = typeof LeaderboardModal !== 'undefined' ? new LeaderboardModal() : null;

  // Initialize hot reload manager for admin scores
  if (typeof AdminDisplayHotReload !== 'undefined' && typeof SheetsData !== 'undefined') {
    const adminDisplayHotReload = new AdminDisplayHotReload(SheetsData);
    adminDisplayHotReload.start();
  }

  // ============================================
  // Button Injection Functions for Axiom Toolbar
  // ============================================

  // Inject Analytics button into axiom.trade toolbar
  function injectAnalyticsButton() {
    // Look for the toolbar by finding existing buttons with the characteristic structure
    // The toolbar contains buttons with ri-* icon classes
    const existingButtons = document.querySelectorAll('button[class*="ri-"], button i[class*="ri-"]');

    for (const buttonOrIcon of existingButtons) {
      // Get the actual button element
      const button = buttonOrIcon.tagName === 'BUTTON' ? buttonOrIcon : buttonOrIcon.closest('button');
      if (!button) continue;

      // Find the toolbar container (flex container with gap-4)
      const toolbar = button.closest('.flex.flex-row.items-center.gap-4');
      if (!toolbar) continue;

      // Check if analytics button already exists
      if (toolbar.querySelector('.axiom-analytics-trigger-button')) continue;

      // Create analytics button matching Axiom's styling
      const analyticsButton = document.createElement('button');
      analyticsButton.type = 'button';
      analyticsButton.className = 'group relative flex h-8 w-8 items-center justify-center rounded-full bg-background transition-colors hover:bg-primaryStroke/60 axiom-analytics-trigger-button';
      analyticsButton.innerHTML = `<i class="ri-bar-chart-box-line text-[16px] text-textSecondary group-hover:text-textPrimary"></i>`;

      // Add click handler to open analytics modal
      analyticsButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (analyticsModal) {
          analyticsModal.show();
        } else {
          console.error('Analytics modal not available');
        }
      });

      // Insert after the first button (question mark button)
      if (button.nextSibling) {
        toolbar.insertBefore(analyticsButton, button.nextSibling);
      } else {
        toolbar.appendChild(analyticsButton);
      }

      // Only inject once per toolbar
      break;
    }
  }

  // Inject Leaderboard button into axiom.trade toolbar
  function injectLeaderboardButton() {
    // Look for the analytics button we just injected
    const analyticsButtons = document.querySelectorAll('.axiom-analytics-trigger-button');

    for (const analyticsBtn of analyticsButtons) {
      // Get the toolbar
      const toolbar = analyticsBtn.closest('.flex.flex-row.items-center.gap-4');
      if (!toolbar) continue;

      // Check if leaderboard button already exists
      if (toolbar.querySelector('.axiom-leaderboard-trigger-button')) continue;

      // Create leaderboard button matching Axiom's styling
      const leaderboardButton = document.createElement('button');
      leaderboardButton.type = 'button';
      leaderboardButton.className = 'group relative flex h-8 w-8 items-center justify-center rounded-full bg-background transition-colors hover:bg-primaryStroke/60 axiom-leaderboard-trigger-button';
      leaderboardButton.innerHTML = `<i class="ri-trophy-line text-[16px] text-textSecondary group-hover:text-textPrimary"></i>`;

      // Add click handler to open leaderboard modal
      leaderboardButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (leaderboardModal) {
          leaderboardModal.show();
        } else {
          console.error('Leaderboard modal not available');
        }
      });

      // Insert after the analytics button
      if (analyticsBtn.nextSibling) {
        toolbar.insertBefore(leaderboardButton, analyticsBtn.nextSibling);
      } else {
        toolbar.appendChild(leaderboardButton);
      }

      // Only inject once per toolbar
      break;
    }
  }

  // Inject Admin Search button into axiom.trade toolbar
  function injectAdminSearchButton() {
    // Look for the leaderboard button we just injected
    const leaderboardButtons = document.querySelectorAll('.axiom-leaderboard-trigger-button');

    for (const leaderboardBtn of leaderboardButtons) {
      // Get the toolbar
      const toolbar = leaderboardBtn.closest('.flex.flex-row.items-center.gap-4');
      if (!toolbar) continue;

      // Check if admin search button already exists
      if (toolbar.querySelector('.axiom-admin-search-trigger-button')) continue;

      // Create admin search button matching Axiom's styling
      const adminSearchButton = document.createElement('button');
      adminSearchButton.type = 'button';
      adminSearchButton.className = 'group relative flex h-8 w-8 items-center justify-center rounded-full bg-background transition-colors hover:bg-primaryStroke/60 axiom-admin-search-trigger-button';
      adminSearchButton.innerHTML = `<i class="ri-search-line text-[16px] text-textSecondary group-hover:text-textPrimary"></i>`;

      // Add click handler to open admin search modal
      adminSearchButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openAdminSearchModal();
      });

      // Insert after the leaderboard button
      if (leaderboardBtn.nextSibling) {
        toolbar.insertBefore(adminSearchButton, leaderboardBtn.nextSibling);
      } else {
        toolbar.appendChild(adminSearchButton);
      }

      // Only inject once per toolbar
      break;
    }
  }

  // Open admin search modal
  function openAdminSearchModal() {
    // Create modal backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'analytics-modal-backdrop admin-search-modal-backdrop';
    backdrop.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.9);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: analytics-backdrop-fade-in 0.15s ease-out;
    `;

    // Create modal container
    const modal = document.createElement('div');
    modal.className = 'analytics-modal-container admin-search-modal-container';
    modal.style.cssText = `
      position: relative;
      width: 500px;
      max-width: 95vw;
      background: #111;
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      overflow: hidden;
      animation: analytics-scale-in 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      flex-direction: column;
    `;

    modal.innerHTML = `
      <button class="analytics-modal-close-button admin-search-close-button" style="
        position: absolute;
        top: 16px;
        right: 16px;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        cursor: pointer;
        z-index: 10;
        transition: all 0.2s ease;
        color: #888;
      ">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <div class="analytics-modal-header" style="
        padding: 20px 24px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      ">
        <div class="analytics-modal-title" style="font-size: 18px; font-weight: 700; color: #fff;">🔍 Admin Search</div>
      </div>

      <div class="analytics-modal-content" style="
        padding: 24px;
        overflow-y: auto;
        max-height: 70vh;
      ">
        <div style="margin-bottom: 12px;">
          <p style="margin: 0; font-size: 13px; color: #888;">Search for tracked admins from the spreadsheet</p>
        </div>

        <div class="admin-search-input-wrapper" style="position: relative;">
          <input type="text" id="adminSearchUsername" class="admin-search-input" placeholder="Type to search admins..." style="
            width: 100%;
            padding: 14px 16px;
            padding-left: 44px;
            background: #1a1a1a;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #e0e0e0;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            box-sizing: border-box;
          ">
          <svg style="
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px;
            height: 18px;
            color: #666;
            pointer-events: none;
          " viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </div>

        <div id="adminSearchSuggestions" class="admin-search-suggestions" style="
          margin-top: 8px;
          display: none;
        "></div>

        <div id="adminSearchStatus" class="admin-search-status" style="
          margin-top: 16px;
          padding: 12px 16px;
          border-radius: 10px;
          font-size: 13px;
          text-align: center;
          display: none;
        "></div>
      </div>
    `;

    // Add CSS styles
    const style = document.createElement('style');
    style.textContent = `
      @keyframes analytics-backdrop-fade-in {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes analytics-scale-in {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }
      @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
      }

      .admin-search-input:focus {
        border-color: #22d3ee !important;
        box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.1);
      }

      .admin-search-close-button:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(255, 255, 255, 0.2) !important;
        color: #fff !important;
      }

      .admin-search-suggestions {
        display: block !important;
      }

      .admin-search-suggestion-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        background: #1a1a1a;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        margin-bottom: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .admin-search-suggestion-item:hover {
        background: #252525;
        border-color: rgba(34, 211, 238, 0.3);
        transform: translateX(4px);
      }

      .admin-search-suggestion-item:last-child {
        margin-bottom: 0;
      }

      .admin-search-suggestion-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #2a2a2a;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
        color: #888;
        flex-shrink: 0;
        overflow: hidden;
      }

      .admin-search-suggestion-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .admin-search-suggestion-info {
        flex: 1;
        min-width: 0;
      }

      .admin-search-suggestion-username {
        font-size: 14px;
        font-weight: 600;
        color: #e0e0e0;
      }

      .admin-search-suggestion-last-active {
        font-size: 12px;
        color: #888;
        margin-top: 2px;
      }

      .admin-search-suggestion-score {
        font-size: 13px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 6px;
        flex-shrink: 0;
      }

      .admin-search-suggestion-score.score-excellent {
        background: rgba(16, 185, 129, 0.15);
        color: #10b981;
      }

      .admin-search-suggestion-score.score-good {
        background: rgba(34, 211, 238, 0.15);
        color: #22d3ee;
      }

      .admin-search-suggestion-score.score-fair {
        background: rgba(251, 191, 36, 0.15);
        color: #fbbf24;
      }

      .admin-search-suggestion-score.score-poor {
        background: rgba(239, 68, 68, 0.15);
        color: #ef4444;
      }

      .admin-search-status.show {
        display: block !important;
      }

      .admin-search-status.loading {
        background: rgba(34, 211, 238, 0.1);
        color: #22d3ee;
        border: 1px solid rgba(34, 211, 238, 0.2);
      }

      .admin-search-status.error {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
      }

      .admin-search-suggestions-empty {
        text-align: center;
        padding: 32px 20px;
        color: #666;
        font-size: 14px;
      }
    `;
    document.head.appendChild(style);

    // Add modal to backdrop
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // Get references
    const input = modal.querySelector('#adminSearchUsername');
    const suggestionsEl = modal.querySelector('#adminSearchSuggestions');
    const statusEl = modal.querySelector('#adminSearchStatus');
    const closeBtn = modal.querySelector('.admin-search-close-button');

    // State
    let allAdmins = [];
    let searchTimeout = null;

    // Load admins from spreadsheet
    async function loadAdmins() {
      try {
        if (typeof SheetsData !== 'undefined') {
          const adminsData = await SheetsData.getAllAdmins();
          allAdmins = Object.entries(adminsData).map(([username, data]) => ({
            username,
            ...data
          }));
        }
      } catch (error) {
        console.error('[Admin Search] Failed to load admins:', error);
      }
    }

    // Focus input and load admins
    setTimeout(() => {
      input.focus();
      loadAdmins();
    }, 100);

    // Debounced search function
    function performSearch(query) {
      const trimmedQuery = query.toLowerCase().trim();

      // Clear previous timeout
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }

      if (!trimmedQuery) {
        suggestionsEl.style.display = 'none';
        suggestionsEl.innerHTML = '';
        statusEl.style.display = 'none';
        return;
      }

      // Debounce the search
      searchTimeout = setTimeout(() => {
        // Filter admins by username
        const matches = allAdmins.filter(admin => {
          return admin.username && admin.username.toLowerCase().includes(trimmedQuery);
        });

        // Show first 5 results
        const topMatches = matches.slice(0, 5);

        if (topMatches.length === 0) {
          suggestionsEl.innerHTML = '<div class="admin-search-suggestions-empty">No matching admins found in spreadsheet</div>';
        } else {
          suggestionsEl.innerHTML = topMatches.map(admin => {
            const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating || 0) : { formatted: 'N/A', class: 'score-poor' };
            const initials = (admin.username || '?').substring(0, 2).toUpperCase();

            return `
              <div class="admin-search-suggestion-item" data-username="${escapeHtml(admin.username)}">
                <div class="admin-search-suggestion-avatar">
                  <img src="https://unavatar.io/twitter/${admin.username}" alt="" onerror="this.style.display='none';this.parentNode.innerHTML='${escapeHtml(initials)}'">
                </div>
                <div class="admin-search-suggestion-info">
                  <div class="admin-search-suggestion-username">@${escapeHtml(admin.username)}</div>
                  ${admin.last_active ? `<div class="admin-search-suggestion-last-active">Last active ${escapeHtml(admin.last_active)}</div>` : ''}
                </div>
                <div class="admin-search-suggestion-score ${scoreData.class}">${scoreData.formatted}</div>
              </div>
            `;
          }).join('');

          // Add click handlers to suggestions
          suggestionsEl.querySelectorAll('.admin-search-suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
              const username = item.getAttribute('data-username');
              openAdminModal(username);
            });
          });
        }

        suggestionsEl.style.display = 'block';
      }, 150);
    }

    // Open admin modal
    async function openAdminModal(username) {
      closeModal();

      // Open admin tokens modal
      if (adminTokensModal) {
        await adminTokensModal.show(username);
      }
    }

    // Escape HTML
    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    // Close modal
    function closeModal() {
      if (backdrop.parentNode) {
        backdrop.style.animation = 'fadeOut 0.15s ease';
        setTimeout(() => {
          if (backdrop.parentNode) {
            backdrop.parentNode.removeChild(backdrop);
          }
          if (style.parentNode) {
            style.parentNode.removeChild(style);
          }
        }, 150);
      }
    }

    // Event listeners
    input.addEventListener('input', (e) => performSearch(e.target.value));

    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const trimmedQuery = input.value.toLowerCase().trim();
        if (trimmedQuery) {
          // Find exact match or first match
          const match = allAdmins.find(admin => admin.username.toLowerCase() === trimmedQuery);
          if (match) {
            openAdminModal(match.username);
          } else {
            const partialMatch = allAdmins.find(admin => admin.username.toLowerCase().includes(trimmedQuery));
            if (partialMatch) {
              openAdminModal(partialMatch.username);
            }
          }
        }
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });

    closeBtn.addEventListener('click', closeModal);

    // Close on backdrop click
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) closeModal();
    });

    // Close on ESC key (global)
    const escHandler = (e) => {
      if (e.key === 'Escape') closeModal();
    };
    document.addEventListener('keydown', escHandler);

    // Cleanup when modal is removed
    backdrop.addEventListener('DOMNodeRemoved', function() {
      document.removeEventListener('keydown', escHandler);
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    });
  }

  // Find token cards on axiom.trade
  function findTokenCards() {
    // Look for elements containing community links
    const communityLinks = document.querySelectorAll('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    const cards = [];

    communityLinks.forEach((link) => {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) return;

      // Skip X community popup/preview cards (fixed positioned elements)
      const fixedPopup = link.closest('.fixed, [class*="z-[9999"], [class*="z-\\[9999\\]"]');
      if (fixedPopup) return;

      // Walk up from the community link to find the card element
      // The card is the .group div that contains all the card content
      let current = link;
      let cardFound = null;

      for (let i = 0; i < 15; i++) {
        // Skip known non-card UI elements during traversal (modals, popovers, etc.)
        // Only stop if we hit a parent with these classes within first few levels
        if (i < 3 && current.classList &&
            (current.classList.contains('padre-no-scroll') ||
             current.classList.contains('css-xek4ag') ||
             current.classList.contains('MuiModal-root') ||
             current.classList.contains('MuiBackdrop-root') ||
             current.getAttribute('tabindex') === '-1')) {
          break;
        }

        // Check if current element looks like the card (has 'group' class and the structure)
        if (current.classList && current.classList.contains('group')) {
          // Verify it has the card structure (should have a relative parent or specific classes)
          const hasCardStructure = current.querySelector('.flex.flex-col') ||
                                  current.querySelector('[class*="h-"]');
          if (hasCardStructure) {
            // Additional check: skip if inside a modal
            if (current.closest('.MuiModal-root')) break;

            cardFound = current;
            break;
          }
        }
        const parent = current.parentElement;
        if (!parent) break;
        current = parent;
      }

      if (cardFound && !cards.includes(cardFound)) {
        cards.push(cardFound);
      }
    });

    return cards;
  }

  // Get X community link from a card
  function getXCommunityLink(card) {
    const link = card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    return link ? link.href : null;
  }

  // Detect platform type
  function detectPlatform(card) {
    const xLink = card.querySelector('a[href*="x.com/i/communities"]');
    if (xLink) return 'x-community';

    const twitterLink = card.querySelector('a[href*="twitter.com/i/communities"]');
    if (twitterLink) return 'twitter';

    return 'x-community'; // Default
  }

  // Create admin display element (full padre feature parity, centered in card)
  async function createAdminDisplay(admin, settings, verificationBadge = null) {
    const container = document.createElement('div');
    container.className = 'admin-display honed-admin-info x-community-admin-info no-hover-effect';
    // Position on the left side, vertically centered
    container.style.cssText = `
      position: absolute !important;
      top: calc(50% + 3px) !important;
      left: 91px !important;
      transform: translateY(-50%) !important;
      z-index: 50 !important;
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      gap: 4px !important;
    `;

    // Admin avatar
    const avatar = document.createElement('img');
    const fallbackIcon = chrome.runtime?.getURL?.('icons/icon48.png') || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="10"/></svg>';
    avatar.src = admin.profile_image_url_https || fallbackIcon;
    avatar.alt = admin.screen_name || 'Admin';
    avatar.className = 'admin-avatar';
    avatar.style.cssText = 'width: 18px !important; height: 18px !important; border-radius: 50% !important; flex-shrink: 0 !important; position: relative !important;';
    avatar.onerror = () => {
      avatar.src = fallbackIcon;
    };

    // Add indicator dot if admin has comments (check via CommentsData if available)
    if (typeof CommentsData !== 'undefined') {
      CommentsData.hasComments(admin.screen_name || '').then(hasComments => {
        if (hasComments) {
          avatar.classList.add('has-comments-indicator');
        }
      }).catch(err => {
        // Silently fail - comments check is non-critical
      });
    }

    // Admin info container
    const infoContainer = document.createElement('div');
    infoContainer.className = 'admin-username-container';
    infoContainer.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important;';

    // Username label
    const usernameLabel = document.createElement('span');
    usernameLabel.className = 'admin-username';
    usernameLabel.textContent = '@' + (admin.screen_name || 'unknown');
    usernameLabel.style.cssText = 'font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important; cursor: pointer !important;';

    // Add hover event listeners for profile tooltip
    usernameLabel.addEventListener('mouseenter', (e) => {
      profileTooltip.show(e.target, admin.screen_name || 'unknown');
    });

    usernameLabel.addEventListener('mousemove', (e) => {
      profileTooltip.updatePosition(e.clientX, e.clientY);
    });

    usernameLabel.addEventListener('mouseleave', () => {
      profileTooltip.hide();
    });

    // Add click event listener to open modal
    usernameLabel.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const username = admin.screen_name || 'unknown';
      if (adminTokensModal) {
        adminTokensModal.show(username);
      }
    });

    infoContainer.appendChild(usernameLabel);

    // Follower count (if enabled and available)
    if (settings.showFollowerCount && admin.followers_count) {
      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' • ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const followerCount = document.createElement('span');
      followerCount.className = 'admin-follower-count';
      followerCount.textContent = formatNumber(admin.followers_count);
      followerCount.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      infoContainer.appendChild(separator);
      infoContainer.appendChild(followerCount);
    }

    // Sheet score (if enabled) - ALWAYS create element, will be updated by hot reload
    if (settings.showSheetScores && typeof SheetsData !== 'undefined') {
      const stats = await SheetsData.getAdminStats(admin.screen_name);

      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' - ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const scoreSpan = document.createElement('span');
      scoreSpan.className = `admin-sheet-score`;
      scoreSpan.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');

      // Set initial state based on available data
      if (stats && stats.total_rating >= 0) {
        const scoreData = SheetsData.formatScore(stats.total_rating);
        scoreSpan.className = `admin-sheet-score ${scoreData.class}`;
        scoreSpan.textContent = scoreData.formatted;
        scoreSpan.style.cssText = `font-size: 12px !important; color: ${scoreData.color} !important; font-weight: 600 !important;`;
      } else {
        // Show loading state - will be updated by hot reload when data arrives
        scoreSpan.textContent = '...';
        scoreSpan.style.cssText = 'font-size: 12px !important; color: #64748b !important; font-weight: 400 !important;';
      }

      infoContainer.appendChild(separator);
      infoContainer.appendChild(scoreSpan);
    }

    container.appendChild(avatar);
    container.appendChild(infoContainer);

    // Add verification badge if available
    if (verificationBadge && settings.communityVerificationEnabled) {
      const verificationBadgeContainer = document.createElement('div');
      verificationBadgeContainer.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; padding: 2px !important;';
      verificationBadgeContainer.appendChild(verificationBadge);
      container.appendChild(verificationBadgeContainer);
    }

    // Add track and blacklist buttons (if enabled)
    if (settings.showTrackBlacklistButtons) {
      // Track button
      const trackBtn = document.createElement('button');
      trackBtn.className = 'admin-track-btn';
      trackBtn.setAttribute('data-admin-username', admin.screen_name || '');
      trackBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      // Check if admin is tracked
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        const tracked = result.trackedAdmins || [];
        const existing = tracked.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === (admin.screen_name || '').toLowerCase();
        });

        const updateTrackButtonState = (isTracked) => {
          if (isTracked) {
            trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>`;
            trackBtn.title = `Untrack @${admin.screen_name}`;
            trackBtn.style.color = '#fbbf24';
          } else {
            trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>`;
            trackBtn.title = `Track @${admin.screen_name}`;
            trackBtn.style.color = '#22d3ee';
          }
        };

        updateTrackButtonState(!!existing);

        // Handle click
        trackBtn.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();

          const username = admin.screen_name;
          if (!username) return;

          // Check if already tracked
          const result = await chrome.storage.local.get(['trackedAdmins']);
          const tracked = result.trackedAdmins || [];
          const existingIndex = tracked.findIndex(a => {
            const adminUsername = a.username || a.userName || a.screen_name;
            return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
          });

          if (existingIndex >= 0) {
            // Untrack
            tracked.splice(existingIndex, 1);
            await chrome.storage.local.set({ trackedAdmins: tracked });
            updateCachedTrackedAdmins(tracked);
            updateTrackButtonState(false);
          } else {
            // Track - fetch full profile
            try {
              const response = await chrome.runtime.sendMessage({
                action: 'fetchUserProfile',
                username: username
              });

              if (response && response.success) {
                const userData = response.data?.data || response.data;
                if (userData && (userData.userName || userData.screen_name)) {
                  const newAdmin = {
                    username: userData.userName || userData.screen_name,
                    profileImage: userData.profilePicture || userData.profile_image_url_https,
                    followersCount: userData.followers || userData.followers_count,
                    name: userData.name,
                    banner: userData.coverPicture || userData.profile_banner_url,
                    description: userData.description,
                    addedAt: Date.now()
                  };
                  tracked.push(newAdmin);
                  await chrome.storage.local.set({ trackedAdmins: tracked });
                  updateCachedTrackedAdmins(tracked);
                  updateTrackButtonState(true);
                }
              }
            } catch (error) {
              console.error('[Axiom] Error fetching profile:', error);
            }
          }
        });

        // Hover effects
        trackBtn.addEventListener('mouseenter', () => {
          trackBtn.style.opacity = '1';
        });
        trackBtn.addEventListener('mouseleave', () => {
          trackBtn.style.opacity = '0.6';
        });
      });

      container.appendChild(trackBtn);

      // Blacklist button
      const blacklistBtn = document.createElement('button');
      blacklistBtn.className = 'admin-blacklist-btn';
      blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>`;
      blacklistBtn.title = `Blacklist @${admin.screen_name}`;
      blacklistBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; color: #f43f5e !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      blacklistBtn.addEventListener('mouseenter', () => {
        blacklistBtn.style.opacity = '1';
      });
      blacklistBtn.addEventListener('mouseleave', () => {
        blacklistBtn.style.opacity = '0.6';
      });

      blacklistBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const username = admin.screen_name;
        if (!username) return;

        // Check if already blacklisted
        const result = await chrome.storage.local.get(['blacklistedAdmins']);
        const blacklist = result.blacklistedAdmins || [];
        const existing = blacklist.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
        });

        if (existing) {
          blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>`;
          blacklistBtn.title = `@${username} is blacklisted`;
          blacklistBtn.style.color = '#10b981';
          return;
        }

        // Fetch profile and add to blacklist
        try {
          const response = await chrome.runtime.sendMessage({
            action: 'fetchUserProfile',
            username: username
          });

          if (response && response.success) {
            const userData = response.data?.data || response.data;
            if (userData && (userData.userName || userData.screen_name)) {
              const newAdmin = {
                username: userData.userName || userData.screen_name,
                profileImage: userData.profilePicture || userData.profile_image_url_https,
                followersCount: userData.followers || userData.followers_count,
                name: userData.name,
                banner: userData.coverPicture || userData.profile_banner_url,
                description: userData.description,
                addedAt: Date.now()
              };
              blacklist.push(newAdmin);
              await chrome.storage.local.set({ blacklistedAdmins: blacklist });
              updateCachedBlacklistedAdmins(blacklist);

              blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>`;
              blacklistBtn.title = `@${username} is blacklisted`;
              blacklistBtn.style.color = '#10b981';
            }
          }
        } catch (error) {
          console.error('[Axiom] Error fetching profile:', error);
        }
      });

      container.appendChild(blacklistBtn);
    }

    return container;
  }

  // Create admin info element (wrapper for consistency)
  async function createAdminInfoElement(adminData, settings) {
    return await createAdminDisplay(adminData, settings, null);
  }

  // Create verification badge (green check or red X)
  function createVerificationBadge(verificationResult) {
    if (!verificationResult) {
      return null;
    }

    const badge = document.createElement('div');
    badge.className = 'verification-badge';

    // Show green check if verified
    if (verificationResult.isVerified === true) {
      badge.className += ' verified-green';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>`;
      badge.title = verificationResult.isFirstOwner ? 'Official community owner (registered)' : 'Verified community owner';
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #10b981 !important; flex-shrink: 0 !important;';
    } else if (verificationResult.isVerified === false) {
      badge.className += ' verified-red';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>`;
      const ownerName = verificationResult.realOwner || 'unknown';
      badge.title = `Fake! Real owner: @${ownerName}`;
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #ef4444 !important; flex-shrink: 0 !important;';
    } else {
      return null;
    }

    return badge;
  }

  // Register community and check ownership
  async function registerAndVerifyCommunity(communityName, adminUsername) {
    return new Promise((resolve) => {
      safeChromeAPI(() => {
        chrome.runtime.sendMessage({
          action: 'registerCommunityOwner',
          communityName: communityName,
          adminUsername: adminUsername
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('[Axiom] Error registering community:', chrome.runtime.lastError);
            resolve({ isFirstOwner: true, isVerified: true });
            return;
          }

          if (response && response.success) {
            resolve(response.data);
          } else {
            console.error('[Axiom] Failed to register community:', response?.error);
            resolve({ isFirstOwner: true, isVerified: true });
          }
        });
      }, () => resolve({ isFirstOwner: true, isVerified: true }));
    });
  }

  // Check if admin is tracked
  function isTrackedAdmin(username) {
    if (!username) return false;
    return trackedUsernamesSet.has(username.toLowerCase());
  }

  // Check if admin is blacklisted
  function isBlacklistedAdmin(username) {
    if (!username) return false;
    return blacklistedUsernamesSet.has(username.toLowerCase());
  }

  // Apply overlay to card (from guide pattern)
  async function addOverlay(card) {
    // Check if X community detection is enabled
    if (!cachedSettings.xCommunityEnabled) {
      return;
    }

    const communityLink = getXCommunityLink(card);
    if (!communityLink) {
      return;
    }

    const cardId = communityLink;

    // Temporary lock to prevent concurrent processing (like padre)
    if (processedCards.has(cardId)) {
      return;
    }
    processedCards.add(cardId);

    const platformType = detectPlatform(card);

    // Set card to relative for absolute positioning of overlay
    card.style.position = 'relative';

    // Add hexToRgba function if not exists
    const hexToRgba = (hex, alpha) => {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };

    let adminData = null;
    let isAdmin = false;
    let isBlacklisted = false;
    let verificationResult = null;

    try {
      const communityId = extractCommunityId(communityLink);
      if (communityId) {
        const communityInfo = await fetchCommunityInfo(communityId);
        if (communityInfo && communityInfo.community_info) {
          adminData = communityInfo.community_info.creator || communityInfo.community_info.admin;

          if (adminData && adminData.screen_name) {
            isAdmin = isTrackedAdmin(adminData.screen_name);
            isBlacklisted = isBlacklistedAdmin(adminData.screen_name);

            // Register and verify community ownership
            if (communityInfo.community_info.name && cachedSettings.communityVerificationEnabled) {
              verificationResult = await registerAndVerifyCommunity(
                communityInfo.community_info.name,
                adminData.screen_name
              );
            }
          }
        }
      }
    } catch (error) {
      console.error('[Axiom] Error fetching community info:', error.message);
      // Continue anyway - we'll still show the overlay
    }

    try {
      // Create verification badge if available
      let verificationBadge = null;
      if (verificationResult) {
        verificationBadge = createVerificationBadge(verificationResult);
      }

      // Add background styling - SAME for normal and tracked admins
      // Use the same color/opacity as core.js uses for normal admins
      if (cachedSettings.adminBackgroundEnabled) {
        const opacity = (cachedSettings.trackedGradientOpacity || 20) / 100 * 0.5; // Same calculation as padre
        const normalColorHex = cachedSettings.normalAdminColor || '#1a1a2e';
        const normalColor = hexToRgba(normalColorHex, opacity);

        // Apply background (same for all)
        card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');

        // Add border for tracked admins (ONLY difference)
        if (isAdmin && !isBlacklisted) {
          card.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor || '#22d3ee'}`, 'important');

          // CRITICAL FIX: Also apply border to any wrapper elements that have the gradient background
          // This fixes the border overlay issue on padre/axiom where a separate wrapper div
          // contains the gradient background but doesn't inherit the border from the card
          const wrapperSelector = `div[style*="linear-gradient(to left"]`;
          const wrappers = card.querySelectorAll(wrapperSelector);
          wrappers.forEach(wrapper => {
            const style = wrapper.getAttribute('style') || '';
            if (style.includes('linear-gradient')) {
              wrapper.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor || '#22d3ee'}`, 'important');
            }
          });

          // Play tracked admin alert sound (only once per unique token, persists across page navigations)
          if (typeof window.AdminAlertAudio !== 'undefined') {
            const adminUsername = adminData.screen_name.toLowerCase();
            const tokenAlertId = `${adminUsername}-${cardId}`;
            if (!hasPlayedAlert(tokenAlertId)) {
              markAlertPlayed(tokenAlertId);
              window.AdminAlertAudio.playAdminAlert();
            }
          }
        } else {
          card.style.setProperty('border', 'none', 'important');

          // Also remove border from wrapper elements
          const wrapperSelector = `div[style*="linear-gradient(to left"]`;
          const wrappers = card.querySelectorAll(wrapperSelector);
          wrappers.forEach(wrapper => {
            const style = wrapper.getAttribute('style') || '';
            if (style.includes('linear-gradient')) {
              wrapper.style.setProperty('border', 'none', 'important');
            }
          });
        }

        // Add blacklist overlay if admin is blacklisted (overrides everything)
        if (isBlacklisted) {
          applyBlacklistOverlay(card, adminData?.screen_name || 'unknown');
        }
      }

      // Create and append admin info to card (with verification badge)
      // CRITICAL FIX: Ensure admin display is ALWAYS created, even if adminData is null
      // This fixes the issue where tracked admin usernames don't show on axiom.trade
      if (cachedSettings.showAdminInfo) {
        let adminInfoElement;

        if (adminData) {
          // We have admin data from the API - use it
          adminInfoElement = await createAdminDisplay(adminData, cachedSettings, verificationBadge);
        } else {
          // API failed or adminData is null - create fallback with minimal info
          // Try to find username from existing community indicator (from content.js)
          const existingIndicator = card.querySelector('.admin-username');
          const fallbackUsername = existingIndicator?.textContent?.replace('@', '') || 'Admin';

          // Create minimal admin display object
          const fallbackAdminData = {
            screen_name: fallbackUsername.replace('@', ''),
            profile_image_url_https: null,
            followers_count: null
          };

          adminInfoElement = await createAdminDisplay(fallbackAdminData, cachedSettings, verificationBadge);
        }

        card.appendChild(adminInfoElement);
      } else {
        const fallbackElement = createFallbackIndicator(communityLink, adminData);
        card.appendChild(fallbackElement);
      }
    } finally {
      // Remove from processing set (like padre - allows reprocessing)
      processedCards.delete(cardId);
    }
  }

  // Create fallback indicator when API fails (matching padre style, centered)
  function createFallbackIndicator(communityLink, adminData = null) {
    const container = document.createElement('div');
    container.className = 'admin-display honed-admin-info x-community-admin-info no-hover-effect';
    // Center in card (offset down 1px, left 15px)
    container.style.cssText = `
      position: absolute !important;
      top: calc(50% + 1px) !important;
      left: calc(50% - 15px) !important;
      transform: translate(-50%, -50%) !important;
      z-index: 50 !important;
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      gap: 4px !important;
    `;

    // If we have admin data but showAdminInfo is off, still show the username
    if (adminData && adminData.screen_name) {
      const screenName = adminData.screen_name || adminData.userName || adminData.name || 'Unknown';
      const displayName = screenName.startsWith('@') ? screenName : `@${screenName}`;

      const usernameLabel = document.createElement('span');
      usernameLabel.className = 'admin-username';
      usernameLabel.textContent = displayName;
      usernameLabel.style.cssText = 'font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important;';

      container.appendChild(usernameLabel);
    } else {
      // Show "Community" badge when we can't fetch admin info
      const label = document.createElement('span');
      label.className = 'admin-username';
      label.textContent = 'Community';
      label.style.cssText = 'font-size: 12px !important; color: #5DBCFF !important; font-weight: 500 !important;';

      container.appendChild(label);
    }

    return container;
  }

  // Apply blacklist overlay with blur and reveal button
  function applyBlacklistOverlay(card, username) {
    // Skip known non-card UI elements
    if (card.classList.contains('padre-no-scroll') ||
        card.classList.contains('css-xek4ag')) {
      return;
    }

    // Mark card as blacklisted
    card.classList.add('blacklisted-token');

    // Check if overlay already exists
    if (card.querySelector('.blacklist-overlay')) {
      return;
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'blacklist-overlay';
    overlay.setAttribute('data-blacklist-username', username);

    // Create reveal button
    const revealBtn = document.createElement('button');
    revealBtn.className = 'blacklist-reveal-btn';
    revealBtn.textContent = 'Show';
    revealBtn.title = 'This token is from a blacklisted admin';

    revealBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.classList.add('revealed');
    });

    overlay.appendChild(revealBtn);
    card.appendChild(overlay);
  }

  // Process all token cards
  async function processTokenCards() {
    // Skip processing if X community detection is disabled
    if (!cachedSettings.xCommunityEnabled) {
      return;
    }

    const tokenCards = findTokenCards();
    await Promise.all(Array.from(tokenCards).map(card => addOverlay(card)));
  }

  // Hot reload for settings changes
  function setupHotReload() {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        const startTime = performance.now();

        // Handle background color/opacity changes - update instantly (exactly like padre)
        if (changes.trackedGradientOpacity || changes.normalAdminColor) {
          const updateStart = performance.now();

          const opacity = ((changes.trackedGradientOpacity?.newValue || cachedSettings.trackedGradientOpacity || 20) / 100 * 0.5);
          const normalColorHex = changes.normalAdminColor?.newValue || cachedSettings.normalAdminColor || '#1a1a2e';

          // hexToRgba function
          const hexToRgba = (hex, alpha) => {
            const r = parseInt(hex.slice(1, 3), 16);
            const g = parseInt(hex.slice(3, 5), 16);
            const b = parseInt(hex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
          };

          const normalColor = hexToRgba(normalColorHex, opacity);

          // Update all cards that have been processed (have position relative and background)
          const updatedCards = new Set();

          // First, update cards with admin info
          document.querySelectorAll('.honed-admin-info').forEach(adminInfo => {
            const card = adminInfo.closest('.group');
            if (card) {
              card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
              card.style.setProperty('border-radius', `12px`, 'important');
              updatedCards.add(card);
            }
          });

          // Also update any .group cards that already have the gradient background (in case admin info is disabled)
          document.querySelectorAll('.group').forEach(card => {
            if (updatedCards.has(card)) return; // Skip already updated

            const currentBg = card.style.getPropertyValue('background');
            if (currentBg && currentBg.includes('linear-gradient')) {
              card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
              card.style.setProperty('border-radius', `12px`, 'important');
              updatedCards.add(card);
            }
          });

          // Update cached settings
          if (changes.trackedGradientOpacity) {
            cachedSettings.trackedGradientOpacity = changes.trackedGradientOpacity.newValue;
          }
          if (changes.normalAdminColor) {
            cachedSettings.normalAdminColor = changes.normalAdminColor.newValue;
          }

          const updateTime = performance.now() - updateStart;
        }

        // Handle tracked border color changes
        if (changes.trackedBorderColor) {
          const trackedBorderColor = changes.trackedBorderColor.newValue || '#22d3ee';

          document.querySelectorAll('.group').forEach(card => {
            const currentBorder = card.style.getPropertyValue('border');
            // Update cards that have the tracked admin border (solid, not none)
            if (currentBorder && currentBorder.includes('solid') && !currentBorder.includes('none')) {
              card.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
            }

            // CRITICAL FIX: Also update wrapper elements with gradient background
            const wrapperSelector = `div[style*="linear-gradient(to left"]`;
            const wrappers = card.querySelectorAll(wrapperSelector);
            wrappers.forEach(wrapper => {
              const style = wrapper.getAttribute('style') || '';
              if (style.includes('linear-gradient') && style.includes('solid')) {
                wrapper.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
              }
            });
          });

          cachedSettings.trackedBorderColor = changes.trackedBorderColor.newValue;
        }

        // For other settings, update cache and reprocess
        const hasOtherChanges = Object.keys(changes).some(key =>
          ['xCommunityEnabled', 'showAdminInfo', 'showMemberPreview', 'showFollowerCount', 'showTrackBlacklistButtons', 'communityVerificationEnabled'].includes(key)
        );

        if (hasOtherChanges) {
          Object.keys(changes).forEach(key => {
            if (cachedSettings.hasOwnProperty(key)) {
              cachedSettings[key] = changes[key].newValue;
            }
          });

          (async () => {
            // Clear processed cards cache to force reprocessing of all cards
            processedCards.clear();
            // Remove existing indicators first for clean reprocessing
            document.querySelectorAll('.honed-admin-info').forEach(el => el.remove());

            await processTokenCards();
            const totalTime = performance.now() - startTime;
          })();
        } else {
          const totalTime = performance.now() - startTime;
        }
      }
    });

    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        if (changes.trackedAdmins) {
          updateCachedTrackedAdmins(changes.trackedAdmins.newValue || []);
        }
        if (changes.blacklistedAdmins) {
          updateCachedBlacklistedAdmins(changes.blacklistedAdmins.newValue || []);
        }
      }
    });
  }

  // Initialize
  async function init() {
    // License check - verify user has valid license
    if (typeof window.License !== 'undefined') {
      const isLicensed = await window.License.isLicensed();
      if (!isLicensed) {
        return; // Stop initialization - extension won't function
      }
    }

    // Load previously played admin alerts (must complete before processing cards)
    await loadPlayedAlerts();

    // Load initial data
    const [settings, trackedAdmins, blacklistedAdmins] = await Promise.all([
      getSettings(),
      getTrackedAdmins(),
      getBlacklistedAdmins()
    ]);

    Object.assign(cachedSettings, settings);
    updateCachedTrackedAdmins(trackedAdmins);
    updateCachedBlacklistedAdmins(blacklistedAdmins);

    // Setup hot reload
    setupHotReload();

    // Initial processing - no delay, run immediately
    // Use requestAnimationFrame to ensure DOM is ready
    await new Promise(resolve => requestAnimationFrame(() => resolve()));
    await processTokenCards();

    // Inject Analytics and Leaderboard buttons into toolbar
    injectAnalyticsButton();
    injectLeaderboardButton();
    injectAdminSearchButton();

    // Re-inject buttons when toolbar changes (SPA navigation)
    const buttonInjectionObserver = new MutationObserver(() => {
      injectAnalyticsButton();
      injectLeaderboardButton();
      injectAdminSearchButton();
    });
    buttonInjectionObserver.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Debounced processing to prevent rapid reprocessing
    let processTimeout = null;
    let isProcessing = false;

    const debouncedProcess = () => {
      if (isProcessing) return;

      if (processTimeout) {
        clearTimeout(processTimeout);
      }

      processTimeout = setTimeout(async () => {
        if (isProcessing) return;

        isProcessing = true;
        try {
          await processTokenCards();
        } finally {
          isProcessing = false;
        }
      }, 250); // Wait 250ms after last mutation before processing
    };

    // Monitor for new cards
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
              // Ignore our own elements
              if (node.classList?.contains('honed-admin-info') ||
                  node.classList?.contains('admin-display') ||
                  node.querySelector?.('.honed-admin-info')) {
                continue;
              }

              if (node.matches('a[href*="x.com/i/communities"]') ||
                  node.matches('a[href*="twitter.com/i/communities"]') ||
                  node.querySelector('a[href*="x.com/i/communities"]') ||
                  node.querySelector('a[href*="twitter.com/i/communities"]')) {
                debouncedProcess();
                break;
              }
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Periodic scan (reduced frequency) - store for cleanup
    const periodicScanInterval = setInterval(() => {
      if (!isProcessing) {
        debouncedProcess();
      }
    }, 300); // Fast periodic scan

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', () => {
      clearInterval(periodicScanInterval);
      observer.disconnect();
      buttonInjectionObserver.disconnect();
    });

    // Handle page visibility changes (navigation, back button, tab switch)
    document.addEventListener('visibilitychange', async () => {
      if (document.visibilityState === 'visible') {
        await processTokenCards();
      }
    });

    // Also handle URL changes (SPA navigation)
    let lastUrl = location.href;
    const urlObserver = new MutationObserver(() => {
      const currentUrl = location.href;
      if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        // Small delay to let page settle
        setTimeout(() => processTokenCards(), 250);
      }
    });
    urlObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ============================================
  // Message listener for background script triggers
  // Handles webNavigation events from background.js
  // ============================================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'processTokenCards') {
      processTokenCards().then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        console.error('[Axiom] Error processing token cards:', err);
        sendResponse({ success: false, error: err.message });
      });
      return true; // Keep message channel open for async response
    }

    if (request.action === 'sheetsDataUpdated') {
      console.log('[Axiom] Data updated in background, invalidating cache');
      if (typeof SheetsData !== 'undefined') {
        SheetsData.invalidateCache();
      }
      // Refresh all admin displays with new data
      if (typeof AdminDisplayHotReload !== 'undefined' && typeof SheetsData !== 'undefined') {
        processTokenCards(); // Re-process cards with fresh data
      }
    }
  });

  // ============================================
  // SPA Navigation Detection - Override History API
  // Catches client-side routing changes (pushState/replaceState)
  // ============================================
  (function() {
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      setTimeout(() => processTokenCards(), 100);
    };

    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      setTimeout(() => processTokenCards(), 100);
    };

    // Also listen to popstate (back/forward buttons)
    window.addEventListener('popstate', () => {
      setTimeout(() => processTokenCards(), 100);
    });
  })();

  // Start
  init();

})();
