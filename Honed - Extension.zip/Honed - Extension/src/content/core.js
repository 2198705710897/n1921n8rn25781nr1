// Tracked Admins Enhancement Script
// This script runs alongside content.js to add tracked admin features

(async function() {
  'use strict';

  // Cached data for instant access (updated via storage listeners)
  let cachedTrackedAdmins = [];
  let cachedBlacklistedAdmins = [];
  let cachedSettings = {
    trackedGradientEnabled: true,
    adminBackgroundEnabled: true,
    trackedBorderColor: '#22d3ee',
    trackedGradientColor: '#22d3ee',
    normalAdminColor: '#1a1a2e',
    trackedGradientOpacity: 20,
    adminAlertEnabled: false,
    adminAlertVolume: 50,
    // Score Alert settings
    scoreAlertEnabled: false,
    scoreAlertThreshold: 2,
    scoreAlertVolume: 50,
    scoreAlertBorderColor: '#10b981',
    scoreAlertGradientColor: '#10b981',
    scoreAlertGradientOpacity: 20
  };
  let trackedUsernamesSet = new Set(); // Cached lowercase usernames
  let blacklistedUsernamesSet = new Set(); // Cached blacklisted usernames

  // Get tracked admins from storage
  async function getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  // Get blacklisted admins from storage
  async function getBlacklistedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['blacklistedAdmins'], (result) => {
        resolve(result.blacklistedAdmins || []);
      });
    });
  }

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get({
        trackedGradientEnabled: true,
        adminBackgroundEnabled: true,
        trackedBorderColor: '#22d3ee',
        trackedGradientColor: '#22d3ee',
        normalAdminColor: '#1a1a2e',
        trackedGradientOpacity: 20,
        adminAlertEnabled: false,
        adminAlertVolume: 50,
        // Score Alert settings
        scoreAlertEnabled: false,
        scoreAlertThreshold: 2,
        scoreAlertVolume: 50,
        scoreAlertBorderColor: '#10b981',
        scoreAlertGradientColor: '#10b981',
        scoreAlertGradientOpacity: 20
      }, (settings) => {
        resolve(settings);
      });
    });
  }

  // Update cached tracked admins and usernames set
  function updateCachedTrackedAdmins(admins) {
    cachedTrackedAdmins = admins;
    trackedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Update cached blacklisted admins and usernames set
  function updateCachedBlacklistedAdmins(admins) {
    cachedBlacklistedAdmins = admins;
    blacklistedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Initialize admin alert audio service
  async function initAdminAlertAudio() {
    const settings = await getSettings();

    if (window.AdminAlertAudio) {
      const volume = (settings.adminAlertVolume || 50) / 100;
      window.AdminAlertAudio.configure({
        enabled: settings.adminAlertEnabled || false,
        volume: volume,
        customSoundUrl: null
      });

    }
  }

  // Play admin alert sound when tracked admin creates token
  async function onTrackedAdminTokenDetected(adminUsername) {

    if (!window.AdminAlertAudio) {
      return;
    }

    const settings = await getSettings();

    if (!settings.adminAlertEnabled) {
      return;
    }

    // Try to unlock audio and play
    const audioService = window.AdminAlertAudio;

    // Update configuration with latest settings
    const volume = (settings.adminAlertVolume || 50) / 100;
    audioService.configure({
      enabled: true,
      volume: volume
    });

    const played = await audioService.playAdminAlert();

  }

  // Play score alert sound when admin score meets threshold
  async function onScoreThresholdMet(adminUsername, adminScore) {
    if (!window.ScoreAlertAudio) {
      return;
    }

    const settings = await getSettings();

    if (!settings.scoreAlertEnabled) {
      return;
    }

    // Check if score meets threshold (better than or equal to)
    if (adminScore > settings.scoreAlertThreshold) {
      return; // Score doesn't meet threshold
    }

    const audioService = window.ScoreAlertAudio;
    const volume = (settings.scoreAlertVolume || 50) / 100;
    audioService.configure({
      enabled: true,
      volume: volume
    });

    const played = await audioService.playScoreAlert();
  }

  // Hex to RGBA converter
  function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  // Find token card containers (works with new page structure)
  function findTokenCards() {
    const allCards = [];
    const seenCards = new Set();

    // Strategy 1: Look for [role="gridcell"] that contain community links
    const gridCells = document.querySelectorAll('[role="gridcell"]');
    gridCells.forEach((cell) => {
      // Skip known non-card UI elements (navigation, search bars, modals, etc.)
      // Only skip if the cell itself has these classes, not if it's a descendant
      if (cell.classList.contains('padre-no-scroll') ||
          cell.classList.contains('css-xek4ag') ||
          cell.classList.contains('MuiModal-root') ||
          cell.classList.contains('MuiBackdrop-root') ||
          cell.getAttribute('tabindex') === '-1' || // Skip modals/popovers
          cell.closest('.MuiModal-root')) { // Skip if inside any modal
        return;
      }

      // Only include if this cell contains a community link
      if (cell.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
        if (!seenCards.has(cell)) {
          allCards.push(cell);
          seenCards.add(cell);
        }
      }
    });

    // Strategy 2: Find cards via community links (walk up to find container)
    const communityLinks = document.querySelectorAll('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');

    communityLinks.forEach((link) => {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) return;

      let parent = link;
      for (let i = 0; i < 20; i++) {
        parent = parent.parentElement;
        if (!parent) break;

        // Skip known non-card UI elements during traversal
        // Only stop if we hit a parent with these classes within first few levels
        if (i < 3 && (parent.classList.contains('padre-no-scroll') ||
                       parent.classList.contains('css-xek4ag') ||
                       parent.classList.contains('MuiModal-root') ||
                       parent.classList.contains('MuiBackdrop-root') ||
                       parent.getAttribute('tabindex') === '-1')) {
          break;
        }

        // Look for various indicators of a card container:
        // 1. Has position absolute with dimensions
        // 2. Has specific MuiStack classes
        // 3. Has both width and height set
        const style = window.getComputedStyle(parent);
        const isPositionAbsolute = style.position === 'absolute';
        const hasHeight = parent.style.height || style.height !== 'auto';
        const hasWidth = parent.style.width || style.width !== 'auto';
        const isMuiStack = parent.className.includes('MuiStack');

        // Check if this looks like a card container
        if ((isPositionAbsolute && hasHeight && hasWidth) ||
            (isMuiStack && parent.children.length > 2)) {
          // Additional check: skip if inside a modal
          if (parent.closest('.MuiModal-root')) break;

          if (!seenCards.has(parent)) {
            allCards.push(parent);
            seenCards.add(parent);
          }
          break;
        }
      }
    });

    return allCards;
  }

  function applyTrackedAdminStyling(specificNodes = null, forceRefresh = false) {
    const settings = cachedSettings;
    const trackedUsernames = trackedUsernamesSet;
    const blacklistedUsernames = blacklistedUsernamesSet;
    const viewportHeight = window.innerHeight;

    const adminUsernameElements = specificNodes ||
      Array.from(document.querySelectorAll('.admin-username'));

    if (adminUsernameElements.length === 0) {
      return;
    }

    let styledCount = 0;
    let trackedCount = 0;

    adminUsernameElements.forEach((adminUsername) => {
      const username = adminUsername.textContent.replace('@', '').toLowerCase();
      const isTracked = trackedUsernames.has(username);
      const isBlacklisted = blacklistedUsernames.has(username);

      // Add indicator dot to avatar if admin has comments (check via CommentsData if available)
      if (typeof CommentsData !== 'undefined') {
        CommentsData.hasComments(username).then(hasComments => {
          // Find the admin avatar (sibling of username in the same container)
          const container = adminUsername.closest('.admin-username-container');
          const avatar = container?.querySelector('.admin-avatar') || adminUsername.parentElement?.querySelector('.admin-avatar');
          if (avatar) {
            if (hasComments) {
              avatar.classList.add('has-comments-indicator');
            } else {
              avatar.classList.remove('has-comments-indicator');
            }
          }
        }).catch(err => {
          // Silently fail - comments check is non-critical
        });
      }

      let card = adminUsername;
      let found = false;
      for (let i = 0; i < 30; i++) {
        card = card.parentElement;
        if (!card) break;

        // CRITICAL: Skip known non-card elements (navigation, search bars, modals, etc.)
        if (card.classList.contains('padre-no-scroll') ||
            card.classList.contains('css-xek4ag') ||
            card.classList.contains('MuiModal-root') ||
            card.classList.contains('MuiBackdrop-root') ||
            card.getAttribute('tabindex') === '-1') {
          break;
        }

        const style = window.getComputedStyle(card);
        const isPositionAbsolute = style.position === 'absolute';
        const hasHeight = style.height !== 'auto' && style.height !== '0px';
        const hasWidth = style.width !== 'auto' && style.width !== '0px';

        // CRITICAL: Must be a real token card
        // On padre/pump.fun: cards have role="gridcell"
        // On trade.padre: cards are position:absolute with dimensions but NO gridcell role
        // Also check if it has the gradient background (characteristic of token cards)
        const isGridCell = card.getAttribute('role') === 'gridcell';
        const inlineStyle = card.getAttribute('style') || '';
        const hasGradientBackground = inlineStyle.includes('linear-gradient');

        // Accept as token card if:
        // 1. Has gridcell role (padre/pump.fun), OR
        // 2. Has gradient background (trade.padre wrapper), OR
        // 3. Is position:absolute with dimensions AND contains community link
        const hasCommunityLink = card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
        const isTokenCard = isGridCell || hasGradientBackground || (isPositionAbsolute && hasHeight && hasWidth && hasCommunityLink);

        if (isPositionAbsolute && hasHeight && hasWidth && isTokenCard) {
          found = true;
          break;
        }
      }

      if (!found || !card) {
        return;
      }

      // Per-card alert tracking: play alert once per card per session
      if (isTracked && !card.hasAttribute('data-alert-played')) {
        card.setAttribute('data-alert-played', 'true');
        onTrackedAdminTokenDetected(username);
      }

      const rect = card.getBoundingClientRect();
      const isVisible = rect.top < viewportHeight && rect.bottom > 0;

      if (!isVisible) {
        return;
      }

      // Check if card already has blacklist overlay for this admin
      const existingOverlay = card.querySelector('.blacklist-overlay');
      const existingOverlayUsername = existingOverlay?.getAttribute('data-blacklist-username');

      // Handle blacklist overlay
      if (isBlacklisted && !existingOverlay) {
        applyBlacklistOverlay(card, username);
      } else if (existingOverlay && !existingOverlay.classList.contains('revealed') && (forceRefresh || existingOverlayUsername !== username || !isBlacklisted)) {
        existingOverlay.remove();
        card.classList.remove('blacklisted-token');
      }

      // ===== SCORE ALERT LOGIC =====
      // Check admin score and apply overlay if score meets threshold
      // Use async IIFE since this requires async SheetsData lookup
      (async () => {
        if (!settings.scoreAlertEnabled) {
          return;
        }

        // Check if SheetsData is available
        if (typeof SheetsData === 'undefined') {
          return;
        }

        try {
          // Get admin stats
          const stats = await SheetsData.getAdminStats(username);
          if (!stats || stats.total_rating === undefined) {
            return;
          }

          const adminScore = stats.total_rating;
          const meetsScoreThreshold = adminScore <= settings.scoreAlertThreshold;

          if (!meetsScoreThreshold) {
            return;
          }

          // Trigger score alert sound (one-time per card)
          if (!card.hasAttribute('data-score-alert-played')) {
            card.setAttribute('data-score-alert-played', 'true');
            await onScoreThresholdMet(username, adminScore);
          }

          // Apply score alert overlay (gradient + border)
          const opacity = settings.scoreAlertGradientOpacity / 100;
          const scoreColor = hexToRgba(settings.scoreAlertGradientColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${scoreColor} 0%, transparent 50%)`, 'important');
          card.style.setProperty('border', `2px solid ${settings.scoreAlertBorderColor}`, 'important');
          card.style.setProperty('border-radius', `12px`, 'important');

          // Also apply border to wrapper elements
          const wrapperSelector = `div[style*="linear-gradient(to left"]`;
          const wrappers = card.querySelectorAll(wrapperSelector);
          wrappers.forEach(wrapper => {
            const style = wrapper.getAttribute('style') || '';
            if (style.includes('linear-gradient')) {
              wrapper.style.setProperty('border', `2px solid ${settings.scoreAlertBorderColor}`, 'important');
            }
          });
        } catch (err) {
          // Silently fail on score check errors
        }
      })();
      // ===== END SCORE ALERT LOGIC =====

      // Apply tracked admin styling - ALWAYS show border for tracked admins regardless of gradient setting
      if (isTracked) {
        if (settings.adminBackgroundEnabled && settings.trackedGradientEnabled) {
          const opacity = settings.trackedGradientOpacity / 100;
          const trackedColor = hexToRgba(settings.trackedGradientColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
        } else if (settings.adminBackgroundEnabled) {
          const opacity = settings.trackedGradientOpacity / 100;
          const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        }
        // ALWAYS apply border for tracked admins
        card.style.setProperty('border', `2px solid ${settings.trackedBorderColor}`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');

        // CRITICAL FIX: Also apply border to any wrapper elements that have the gradient background
        // This fixes the border overlay issue on padre where a separate wrapper div
        // contains the gradient background but doesn't inherit the border from the card
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', `2px solid ${settings.trackedBorderColor}`, 'important');
          }
        });

        trackedCount++;
        styledCount++;
      } else if (settings.adminBackgroundEnabled) {
        const opacity = settings.trackedGradientOpacity / 100;
        const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
        card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        card.style.setProperty('border', `none`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');

        // Also remove border from wrapper elements
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', 'none', 'important');
          }
        });

        styledCount++;
      }
    });
  }

  // Apply blacklist overlay with blur and reveal button
  function applyBlacklistOverlay(card, username) {
    // Skip known non-card UI elements
    if (card.classList.contains('padre-no-scroll') ||
        card.classList.contains('css-xek4ag')) {
      return;
    }

    // Mark card as blacklisted
    card.classList.add('blacklisted-token');

    // Check if overlay already exists
    if (card.querySelector('.blacklist-overlay')) {
      return;
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'blacklist-overlay';
    overlay.setAttribute('data-blacklist-username', username);

    // Create reveal button
    const revealBtn = document.createElement('button');
    revealBtn.className = 'blacklist-reveal-btn';
    revealBtn.textContent = 'Show';
    revealBtn.title = 'This token is from a blacklisted admin';

    revealBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.classList.add('revealed');
    });

    overlay.appendChild(revealBtn);
    card.appendChild(overlay);
  }

  // Find admin username elements within new nodes only
  function findAdminUsernamesInNodes(nodes) {
    const adminElements = [];
    nodes.forEach(node => {
      if (node.nodeType === 1) { // Element node
        // Check if the node itself is an admin username
        if (node.classList && node.classList.contains('admin-username')) {
          adminElements.push(node);
        }
        // Check children for admin usernames
        if (node.querySelectorAll) {
          const found = node.querySelectorAll('.admin-username');
          adminElements.push(...Array.from(found));
        }
      }
    });
    return adminElements;
  }

  // Initialize
  async function init() {

    // Populate cache with initial data
    const [trackedAdmins, blacklistedAdmins, settings] = await Promise.all([
      getTrackedAdmins(),
      getBlacklistedAdmins(),
      getSettings()
    ]);
    updateCachedTrackedAdmins(trackedAdmins);
    updateCachedBlacklistedAdmins(blacklistedAdmins);
    Object.assign(cachedSettings, settings);

    // Initialize admin alert audio service
    await initAdminAlertAudio();

    let attempts = 0;
    const maxAttempts = 100; // Increased from 10 to 100 (10 seconds max)

    while (attempts < maxAttempts) {
      const adminUsernames = document.querySelectorAll('.admin-username');
      if (adminUsernames.length > 0) {
        break;
      }
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    if (attempts >= maxAttempts) {
    }

    // Apply styling (no await needed - uses cached data)
    applyTrackedAdminStyling();

    const observer = new MutationObserver((mutations) => {
      const addedNodes = [];
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === 1) {
            addedNodes.push(node);
          }
        }
      }

      if (addedNodes.length === 0) return;

      const adminElements = findAdminUsernamesInNodes(addedNodes);
      if (adminElements.length > 0) {
        applyTrackedAdminStyling(adminElements);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    let scrollFrame;
    window.addEventListener('scroll', () => {
      cancelAnimationFrame(scrollFrame);
      scrollFrame = requestAnimationFrame(() => {
        applyTrackedAdminStyling();
      });
    }, { passive: true });

    // Periodic scan every 100ms for tracked admin styling - store for cleanup
    const periodicStylingScan = setInterval(() => {
      applyTrackedAdminStyling();
    }, 100);

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', () => {
      clearInterval(periodicStylingScan);
      observer.disconnect();
    });

    // Setup hot-reload listener for settings changes
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        const startTime = performance.now();

        const relevantKeys = [
          'trackedGradientEnabled',
          'adminBackgroundEnabled',
          'trackedBorderColor',
          'trackedGradientColor',
          'normalAdminColor',
          'trackedGradientOpacity',
          'adminAlertEnabled',
          'adminAlertVolume',
          // Score Alert settings
          'scoreAlertEnabled',
          'scoreAlertVolume',
          'scoreAlertThreshold',
          'scoreAlertBorderColor',
          'scoreAlertGradientColor',
          'scoreAlertGradientOpacity'
        ];

        const hasRelevantChange = Object.keys(changes).some(key => {
          if (!relevantKeys.includes(key)) return false;

          const setting = changes[key];
          const oldValue = setting.oldValue;
          const newValue = setting.newValue;


          // Update cached settings immediately
          cachedSettings[key] = newValue;

          // Update CSS custom properties for colors
          if (key === 'trackedBorderColor') {
            document.documentElement.style.setProperty('--tracked-border-color', newValue);
          }

          if (key === 'trackedGradientColor') {
            document.documentElement.style.setProperty('--tracked-gradient-color', newValue);
          }

          if (key === 'normalAdminColor') {
            document.documentElement.style.setProperty('--normal-admin-color', newValue);
          }

          // Update admin alert audio settings
          if (key === 'adminAlertEnabled' || key === 'adminAlertVolume') {
            initAdminAlertAudio();
          }

          // Update score alert audio settings
          if (key === 'scoreAlertEnabled' || key === 'scoreAlertVolume') {
            if (window.ScoreAlertAudio) {
              const volume = (cachedSettings.scoreAlertVolume || 50) / 100;
              window.ScoreAlertAudio.configure({
                enabled: cachedSettings.scoreAlertEnabled || false,
                volume: volume
              });
            }
          }

          return true;
        });

        if (hasRelevantChange) {
          // Clear existing inline styles and styling markers for clean reapplication
          document.querySelectorAll('[data-tracked-styled]').forEach(el => {
            el.removeAttribute('data-tracked-styled');
          });
          // Only clear styles from actual token cards (gridcells with community links)
          document.querySelectorAll('[role="gridcell"]').forEach(card => {
            // Verify this is a token card by checking for community link
            if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
              if (card.style.background || card.style.border) {
                card.style.removeProperty('background');
                card.style.removeProperty('border');
                card.style.removeProperty('border-radius');
              }
            }
          });
          applyTrackedAdminStyling();
          const totalTime = performance.now() - startTime;
        } else {
          const totalTime = performance.now() - startTime;
        }
      }

      // Handle tracked admins list changes
      if (areaName === 'local' && changes.trackedAdmins) {
        const newAdmins = changes.trackedAdmins.newValue || [];
        updateCachedTrackedAdmins(newAdmins);
      }

      // Handle blacklisted admins list changes
      if (areaName === 'local' && changes.blacklistedAdmins) {
        const newBlacklist = changes.blacklistedAdmins.newValue || [];
        updateCachedBlacklistedAdmins(newBlacklist);
        // Force refresh to show/hide blacklist overlays
        applyTrackedAdminStyling(null, true);
      }
    });

  }

  // Run initialization
  init();
})();
