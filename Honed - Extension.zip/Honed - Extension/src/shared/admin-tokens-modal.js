/**
 * Admin Tokens Detail Modal
 * Modal overlay for displaying admin profile and detailed token list
 * Shows when clicking on admin usernames (hover shows tooltip)
 */

// Guard against duplicate script loading
if (typeof window.AdminTokensModal !== 'undefined') {
  console.log('[AdminTokensModal] Already loaded, skipping...');
} else {

class AdminTokensModal {
  constructor(profileTooltip) {
    this.profileTooltip = profileTooltip;
    this.backdrop = null;
    this.container = null;
    this.currentUsername = null;
    this.isOpen = false;
    this.mevxClient = new MevxApiClient();
    this.pendingMevxRequests = null;
    this.abortController = null;
    this.escapeHandlerBound = null;
    this.storageListenerBound = null;
    // Cache for escaped HTML to avoid repeated DOM operations
    this.escapeCache = new Map();
    this.maxCacheSize = 500;

    // Track current load request to prevent race conditions
    this.currentLoadRequestId = 0;

    // Pagination state
    this.pagination = {
      currentPage: 1,
      itemsPerPage: 25,  // Increased from 5 for better UX
      allTokens: []
    };

    // Intersection Observer for lazy loading MEVX data
    this.mevxIntersectionObserver = null;

    // Comments panel state
    this.isCommentsPanelOpen = false;
    this.comments = [];
    this.editingCommentId = null;
  }

  /**
   * Show modal for admin username
   * @param {string} username - Admin username
   */
  async show(username) {
    if (this.isOpen) {
      // Close existing modal first
      this.hide();
    }

    this.currentUsername = username;
    this.isOpen = true;
    this.abortController = new AbortController();

    // Reset pagination state
    this.pagination.currentPage = 1;
    this.pagination.allTokens = [];

    // Hide the profile tooltip
    if (this.profileTooltip) {
      this.profileTooltip.hide();
      this.profileTooltip._enabled = false;
    }

    // Create modal structure
    this._createModal();

    // Add to DOM
    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Listen for storage changes to auto-refresh when sheet data updates
    this.storageListenerBound = this._handleStorageChange.bind(this);
    chrome.storage.onChanged.addListener(this.storageListenerBound);

    // Load and render data
    await this._loadData();
  }

  /**
   * Hide modal and restore tooltip
   */
  hide() {
    if (!this.isOpen) return;

    // Cancel pending MEVX requests
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    // Disconnect intersection observer
    if (this.mevxIntersectionObserver) {
      this.mevxIntersectionObserver.disconnect();
      this.mevxIntersectionObserver = null;
    }

    // Clear escape cache
    if (this.escapeCache.size > 100) {
      this.escapeCache.clear();
    }

    // Immediately disable pointer events on backdrop to prevent any further interactions
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
      this.backdrop.style.display = 'none'; // Also hide visually
    }

    // Remove modal from DOM - use try/catch to ensure removal even if errors occur
    try {
      if (this.backdrop && this.backdrop.parentNode) {
        this.backdrop.parentNode.removeChild(this.backdrop);
      }
    } catch (e) {
      console.error('[AdminTokensModal] Error removing backdrop:', e);
    }

    // Ensure modal-open class is removed from body
    document.body.classList.remove('modal-open');

    // Remove ESC key listener
    if (this.escapeHandlerBound) {
      document.removeEventListener('keydown', this.escapeHandlerBound);
      this.escapeHandlerBound = null;
    }

    // Remove storage change listener
    if (this.storageListenerBound) {
      chrome.storage.onChanged.removeListener(this.storageListenerBound);
      this.storageListenerBound = null;
    }

    // Clear pending MEVX requests
    this.pendingMevxRequests = null;

    // Restore profile tooltip
    if (this.profileTooltip) {
      this.profileTooltip._enabled = true;
    }

    this.isOpen = false;
    this.currentUsername = null;
    this.backdrop = null;
    this.container = null;

    // Force a cleanup of any orphaned backdrops (defensive measure)
    setTimeout(() => {
      const orphanedBackdrops = document.querySelectorAll('.admin-tokens-modal-backdrop');
      orphanedBackdrops.forEach(backdrop => {
        if (backdrop.parentNode) {
          console.warn('[AdminTokensModal] Removing orphaned backdrop');
          backdrop.parentNode.removeChild(backdrop);
        }
      });
    }, 100);
  }

  /**
   * Create modal DOM structure
   * @private
   */
  _createModal() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'admin-tokens-modal-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'admin-tokens-modal-container';

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'modal-close-button';
    closeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
    closeButton.addEventListener('click', () => this.hide());

    // Create content area
    const content = document.createElement('div');
    content.className = 'admin-tokens-modal-content';
    content.innerHTML = `
      <div class="modal-left-panel">
        <div class="modal-profile-section">
          <div class="modal-loading-skeleton" style="height: 100px; border-radius: 12px; margin-bottom: 12px;"></div>
          <div class="modal-loading-skeleton" style="width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 12px;"></div>
          <div class="modal-loading-skeleton" style="height: 24px; width: 60%; margin: 0 auto 8px;"></div>
          <div class="modal-loading-skeleton" style="height: 16px; width: 40%; margin: 0 auto;"></div>
        </div>
        <div class="modal-performance-section">
          <div class="modal-loading-skeleton" style="height: 20px; width: 80px; margin-bottom: 16px;"></div>
          <div class="modal-loading-skeleton" style="height: 50px; border-radius: 8px; margin-bottom: 8px;"></div>
          <div class="modal-loading-skeleton" style="height: 50px; border-radius: 8px; margin-bottom: 8px;"></div>
          <div class="modal-loading-skeleton" style="height: 50px; border-radius: 8px;"></div>
        </div>
        <div class="modal-score-distribution-section">
          <div class="modal-loading-skeleton" style="height: 20px; width: 80px; margin-bottom: 12px;"></div>
          <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px;">
            ${Array(6).fill('<div class="modal-loading-skeleton" style="height: 40px; border-radius: 8px;"></div>').join('')}
          </div>
        </div>
      </div>
      <div class="modal-right-panel">
        <div class="modal-tokens-header">
          <div class="modal-tokens-title">Tokens</div>
          <button class="modal-comments-tab" id="modalCommentsTab" title="View Comments">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            <span class="modal-comments-count" id="modalCommentsCount"></span>
          </button>
          <button class="modal-refresh-btn" id="modalRefreshBtn" title="Force refresh from spreadsheet">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M23 4v6h-6"></path>
              <path d="M1 20v-6h6"></path>
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
            </svg>
            Refresh
          </button>
        </div>
        <div class="modal-loading-skeleton" style="height: 20px; width: 120px; margin-bottom: 16px;"></div>
        ${Array(5).fill('<div class="modal-token-loading"><div class="modal-loading-skeleton modal-token-logo"></div><div class="modal-loading-skeleton" style="height: 16px; margin-bottom: 8px;"></div><div class="modal-loading-skeleton" style="height: 12px; width: 60%;"></div></div>').join('')}
      </div>
      <div class="modal-comments-panel" id="modalCommentsPanel">
        <div class="modal-comments-header">
          <div class="modal-comments-title">Comments</div>
          <button class="modal-comments-close-btn" id="modalCommentsCloseBtn" title="Close Comments">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        <div class="modal-comments-list" id="modalCommentsList">
          <div class="modal-loading-skeleton" style="height: 60px; border-radius: 8px; margin-bottom: 12px;"></div>
          <div class="modal-loading-skeleton" style="height: 60px; border-radius: 8px; margin-bottom: 12px;"></div>
        </div>
        <div class="modal-comments-input-section">
          <textarea class="modal-comment-input" id="modalCommentInput" placeholder="Add a comment..."></textarea>
          <div class="modal-comment-actions">
            <button class="modal-comment-cancel-btn" id="modalCommentCancelBtn" style="display: none;">Cancel</button>
            <button class="modal-comment-submit-btn" id="modalCommentSubmitBtn" disabled>Post</button>
          </div>
        </div>
      </div>
    `;

    // Assemble modal
    this.container.appendChild(closeButton);
    this.container.appendChild(content);
    this.backdrop.appendChild(this.container);

    // Add event listeners
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });

    // Bind and store ESC handler for proper cleanup
    this.escapeHandlerBound = this._handleEscape.bind(this);
    document.addEventListener('keydown', this.escapeHandlerBound);

    // Setup comments panel event listeners
    this._setupCommentsPanelListeners();
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape(e) {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  }

  /**
   * Handle storage changes - refresh modal data when sheet data updates
   * @private
   */
  _handleStorageChange(changes, areaName) {
    // Only care about local storage changes
    if (areaName !== 'local' || !this.isOpen) return;

    // Check if admin stats were updated (tokens are fetched on-demand, not stored)
    if (changes.sheetsAdmins) {
      // Refresh the data with current username
      this._loadData().catch(err => {
        console.error('[AdminTokensModal] Failed to refresh data:', err);
      });
    }
  }

  /**
   * Handle refresh button click - trigger sync and reload data
   * @private
   */
  async _handleRefreshClick() {
    const refreshBtn = this.container?.querySelector('#modalRefreshBtn');
    if (!refreshBtn) return;

    // Show loading state
    const originalHTML = refreshBtn.innerHTML;
    refreshBtn.innerHTML = `<svg class="spinning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M23 4v6h-6"></path>
      <path d="M1 20v-6h6"></path>
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
    </svg> Syncing...`;
    refreshBtn.disabled = true;

    try {
      // Trigger a background sync
      await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'syncSheetsNow' },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (response?.success) {
              resolve();
            } else {
              reject(new Error(response?.error || 'Sync failed'));
            }
          }
        );
      });

      // Reload the modal data
      await this._loadData();

      // Show success state briefly
      refreshBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg> Updated!`;
      setTimeout(() => {
        if (refreshBtn && this.isOpen) {
          refreshBtn.innerHTML = originalHTML;
          refreshBtn.disabled = false;
        }
      }, 1500);

    } catch (error) {
      console.error('[AdminTokensModal] Refresh failed:', error);
      // Show error state briefly
      refreshBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg> Failed`;
      setTimeout(() => {
        if (refreshBtn && this.isOpen) {
          refreshBtn.innerHTML = originalHTML;
          refreshBtn.disabled = false;
        }
      }, 2000);
    }
  }

  /**
   * Load and render data
   * @private
   */
  async _loadData() {
    const username = this.currentUsername;
    if (!username) return;

    // Increment request ID to track this specific load request
    const requestId = ++this.currentLoadRequestId;

    try {
      // Phase 1: Load profile, stats, and comments first (fast)
      const [profileData, adminStats, comments] = await Promise.all([
        this._fetchProfile(username),
        this._fetchAdminStats(username),
        this._fetchComments(username)
      ]);

      // Check if this is still the current request
      if (requestId !== this.currentLoadRequestId || !this.isOpen) {
        console.log('[AdminTokensModal] Skipping stale profile request');
        return;
      }

      this.comments = comments || [];

      // Render profile and stats immediately
      this._renderProfileSection(profileData);
      this._renderScoreSection(adminStats);

      // Update comments count and render comments
      this._updateCommentsCount();

      // Phase 2: Load tokens in background (slow - Google Sheets)
      // This runs non-blocking after profile is visible
      this._fetchAdminTokens(username).then(adminTokens => {
        // Check if this is still the current request and modal
        if (requestId !== this.currentLoadRequestId || !this.isOpen) {
          console.log('[AdminTokensModal] Skipping stale token request');
          return;
        }
        this._renderTokenList(adminTokens, adminStats);
      }).catch(err => {
        console.error('[AdminTokensModal] Failed to load tokens:', err);
        // Check if this is still the current request before rendering error state
        if (requestId === this.currentLoadRequestId && this.isOpen) {
          this._renderTokenList([], adminStats);
        }
      });

    } catch (error) {
      console.error('[AdminTokensModal] Failed to load profile/stats:', error);
      // Only render error if this is still the current request
      if (requestId === this.currentLoadRequestId) {
        this._renderError();
      }
    }
  }

  /**
   * Fetch profile data via background script
   * @private
   */
  async _fetchProfile(username) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: 'fetchUserProfile', username },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.success && response?.data) {
            resolve(response.data);
          } else {
            reject(new Error(response?.error || 'Fetch failed'));
          }
        }
      );
    });
  }

  /**
   * Fetch admin stats from SheetsData
   * @private
   */
  async _fetchAdminStats(username) {
    if (typeof SheetsData === 'undefined') return null;
    return await SheetsData.getAdminStats(username);
  }

  /**
   * Fetch admin tokens from SheetsData (fetched on-demand from Google Sheets)
   * @private
   */
  async _fetchAdminTokens(username) {
    if (typeof SheetsData === 'undefined') return [];

    // Note: Right panel keeps its initial skeleton loading state
    // No need to replace it here - skeleton looks cleaner than a spinner

    const tokens = await SheetsData.getAdminTokens(username);
    this.pagination.allTokens = tokens;
    return tokens;
  }

  /**
   * Fetch comments from CommentsData
   * @private
   */
  async _fetchComments(username) {
    if (typeof CommentsData === 'undefined') return [];
    return await CommentsData.getComments(username);
  }

  /**
   * Render profile section (left panel, top left)
   * @private
   */
  _renderProfileSection(data) {
    const profileSection = this.container.querySelector('.modal-profile-section');
    if (!profileSection || !data) return;

    const userData = data.data || data;

    profileSection.innerHTML = `
      <div class="modal-profile-banner" style="background-image: url('${userData.coverPicture || userData.profile_banner_url || ''}'); background-color: #1a1a2e;"></div>
      <div class="modal-profile-avatar" style="background-image: url('${userData.profilePicture || userData.profile_image_url_https || ''}');"></div>
      <div class="modal-profile-name">${this._escapeHtml(userData.name || userData.display_name || 'Unknown')}</div>
      <div class="modal-profile-username">@${this._escapeHtml(userData.userName || userData.screen_name || 'unknown')}</div>
      <div class="modal-profile-bio">${this._escapeHtml(userData.description || userData.bio || 'No bio available.')}</div>
      <div class="modal-profile-stats">
        <div class="modal-profile-stat">
          <span class="modal-profile-stat-value">${this._formatNumber(userData.friends_count || userData.following || 0)}</span>
          <span class="modal-profile-stat-label">Following</span>
        </div>
        <div class="modal-profile-stat">
          <span class="modal-profile-stat-value">${this._formatNumber(userData.followers_count || userData.followers || 0)}</span>
          <span class="modal-profile-stat-label">Followers</span>
        </div>
      </div>
    `;
  }

  /**
   * Render performance section (left panel, top right)
   * @private
   */
  _renderScoreSection(stats) {
    const performanceSection = this.container.querySelector('.modal-performance-section');
    if (!performanceSection) return;

    if (!stats) {
      performanceSection.innerHTML = `
        <div class="modal-panel-header">Performance</div>
        <div class="modal-empty-state">
          <div class="modal-empty-state-text">No stats available</div>
        </div>
      `;
      // Also render empty score distribution
      this._renderScoreDistributionSection(null);
      return;
    }

    const scoreData = SheetsData ? SheetsData.formatScore(stats.total_rating) : { formatted: stats.total_rating?.toFixed(1) || 'N/A', class: '', color: '#fff' };

    performanceSection.innerHTML = `
      <div class="modal-panel-header">Performance</div>
      <div class="modal-stats-grid">
        <div class="modal-stat-item">
          <span class="modal-stat-label">Rating</span>
          <span class="modal-stat-value ${scoreData.class}" style="color: ${scoreData.color}">${scoreData.formatted}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Tokens</span>
          <span class="modal-stat-value">${stats.total_tokens_created || 0}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Winrate</span>
          <span class="modal-stat-value">${((stats.winrate || 0) * 100).toFixed(0)}%</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Failed</span>
          <span class="modal-stat-value score-poor">${stats.tokens_score_6 || 0}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Avg Migrate</span>
          <span class="modal-stat-value">${stats.avg_migrate_time || '-'}</span>
        </div>
      </div>
    `;

    // Render score distribution at bottom (spans both columns)
    this._renderScoreDistributionSection(stats);
  }

  /**
   * Render score distribution section (left panel, bottom - spans both columns)
   * @private
   */
  _renderScoreDistributionSection(stats) {
    const scoreSection = this.container.querySelector('.modal-score-distribution-section');
    if (!scoreSection) return;

    if (!stats) {
      scoreSection.innerHTML = `
        <div class="modal-dist-label">Score Distribution</div>
        <div class="modal-empty-state">
          <div class="modal-empty-state-text">No stats available</div>
        </div>
      `;
      return;
    }

    scoreSection.innerHTML = `
      <div class="modal-dist-label">Score Distribution</div>
      <div class="modal-dist-grid">
        ${[0,1,2,3,4,5].map(score => {
          const count = stats[`tokens_score_${score}`] || 0;
          return `
            <div class="modal-dist-cell modal-dist-cell-${score}">
              <span class="modal-dist-cell-score">${score}</span>
              <div class="modal-dist-cell-divider"></div>
              <span class="modal-dist-cell-count">${count}</span>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  /**
   * Render token list (right panel) with pagination
   * @private
   */
  async _renderTokenList(tokens, stats) {
    const rightPanel = this.container.querySelector('.modal-right-panel');
    if (!rightPanel) return;

    if (!tokens || tokens.length === 0) {
      rightPanel.innerHTML = `
        <div class="modal-tokens-header">
          <div class="modal-tokens-title" data-count="0"></div>
          <button class="modal-comments-tab" id="modalCommentsTab" title="View Comments">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            <span class="modal-comments-count" id="modalCommentsCount"></span>
          </button>
        </div>
        <div class="modal-empty-state">
          <div class="modal-empty-state-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          </div>
          <div class="modal-empty-state-text">No tokens found</div>
          <div class="modal-empty-state-subtext">This admin hasn't created any tokens yet</div>
        </div>
      `;
      // Re-attach comments tab event listener for empty state
      const commentsTab = rightPanel.querySelector('#modalCommentsTab');
      if (commentsTab) {
        commentsTab.addEventListener('click', () => this._toggleCommentsPanel());
      }
      return;
    }

    // Sort by score first (lower is better), then by ATH market cap within each score
    const sortedTokens = [...tokens].sort((a, b) => {
      const scoreA = a.token_score || 0;
      const scoreB = b.token_score || 0;

      // First sort by score (lower scores first)
      if (scoreA !== scoreB) {
        return scoreA - scoreB;
      }

      // Within same score, sort by ATH market cap (descending)
      return (b.ath_market_cap || 0) - (a.ath_market_cap || 0);
    });

    // Update stored tokens with sorted order
    this.pagination.allTokens = sortedTokens;

    // Calculate pagination
    const totalPages = Math.ceil(sortedTokens.length / this.pagination.itemsPerPage);
    const { currentPage, itemsPerPage } = this.pagination;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageTokens = sortedTokens.slice(startIndex, endIndex);

    // Render header
    rightPanel.innerHTML = `
      <div class="modal-tokens-header">
        <div class="modal-tokens-title" data-count="${sortedTokens.length}"></div>
        <button class="modal-comments-tab" id="modalCommentsTab" title="View Comments">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          <span class="modal-comments-count" id="modalCommentsCount"></span>
        </button>
        <button class="modal-refresh-btn" id="modalRefreshBtn" title="Force refresh from spreadsheet">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 4v6h-6"></path>
            <path d="M1 20v-6h6"></path>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
          </svg>
          Refresh
        </button>
      </div>
      <div class="modal-token-list"></div>
      ${totalPages > 1 ? `
        <div class="modal-pagination-controls">
          <button class="modal-pagination-btn modal-pagination-prev" ${currentPage === 1 ? 'disabled' : ''} data-page="${currentPage - 1}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
            Previous
          </button>
          <span class="modal-pagination-info">Page ${currentPage} of ${totalPages}</span>
          <button class="modal-pagination-btn modal-pagination-next" ${currentPage === totalPages ? 'disabled' : ''} data-page="${currentPage + 1}">
            Next
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </button>
        </div>
      ` : ''}
    `;

    const tokenList = rightPanel.querySelector('.modal-token-list');

    // Use DocumentFragment for batch DOM insertion
    const fragment = document.createDocumentFragment();

    // Render token cards for current page only
    pageTokens.forEach((token, index) => {
      const card = this._createTokenCard(token, index);
      fragment.appendChild(card);
    });

    // Single DOM operation for all cards
    tokenList.appendChild(fragment);

    // Add event delegation for copy buttons
    tokenList.addEventListener('click', this._handleTokenListClick.bind(this));

    // Add refresh button handler
    const refreshBtn = rightPanel.querySelector('#modalRefreshBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', this._handleRefreshClick.bind(this));
    }

    // Add pagination button handlers
    const paginationContainer = rightPanel.querySelector('.modal-pagination-controls');
    if (paginationContainer) {
      paginationContainer.addEventListener('click', this._handlePaginationClick.bind(this));
    }

    // Re-attach comments tab event listener (it was lost when innerHTML was replaced)
    const commentsTab = rightPanel.querySelector('#modalCommentsTab');
    if (commentsTab) {
      commentsTab.addEventListener('click', () => this._toggleCommentsPanel());
    }

    // Update comments count badge (it was lost when innerHTML was replaced)
    this._updateCommentsCount();

    // Set up lazy loading for MEVX data using IntersectionObserver
    this._setupMevxLazyLoading();
  }

  /**
   * Set up IntersectionObserver for lazy loading MEVX data as tokens come into view
   * @private
   */
  _setupMevxLazyLoading() {
    // Disconnect existing observer if any
    if (this.mevxIntersectionObserver) {
      this.mevxIntersectionObserver.disconnect();
    }

    // Get the token list container to use as root for intersection detection
    const rightPanel = this.container?.querySelector('.modal-right-panel');
    const tokenList = rightPanel?.querySelector('.modal-token-list');

    // Create new IntersectionObserver with rootMargin to prefetch slightly before visible
    this.mevxIntersectionObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          const card = entry.target;
          const address = card.getAttribute('data-token-address');

          // Stop observing this card once it comes into view
          this.mevxIntersectionObserver.unobserve(card);

          // Mark card as loading to prevent duplicate fetches
          if (card.hasAttribute('data-mevx-loading')) continue;
          card.setAttribute('data-mevx-loading', 'true');

          // Fetch MEVX data for this token
          this._fetchSingleTokenMevxData(address, card);
        }
      }
    }, {
      // Use token list as root so overlay doesn't affect intersection detection
      root: tokenList || null,
      // Start loading when token is within 100px of visible area (more prefetch)
      rootMargin: '100px',
      // Trigger as soon as any part is visible
      threshold: 0
    });

    // Observe all token cards
    const tokenCards = this.container.querySelectorAll('.modal-token-card');
    tokenCards.forEach(card => {
      this.mevxIntersectionObserver.observe(card);
    });
  }

  /**
   * Fetch MEVX data for a single token card
   * @private
   */
  async _fetchSingleTokenMevxData(address, card) {
    if (!address || !card || !this.isOpen) return;

    try {
      const results = await this.mevxClient.fetchBatchTokens([address], () => {});

      // Check if modal is still open and card still exists
      if (!this.isOpen || !card.isConnected) return;

      const data = results.get(address);
      if (data) {
        this._updateTokenCardWithMevx(card, data);
      }

      // Remove loading flag
      card.removeAttribute('data-mevx-loading');

    } catch (error) {
      console.error('[AdminTokensModal] Failed to fetch MEVX data for token:', address, error);
      card.removeAttribute('data-mevx-loading');
    }
  }

  /**
   * Handle clicks on token list (event delegation)
   * @private
   */
  _handleTokenListClick(e) {
    const copyBtn = e.target.closest('.modal-token-copy-btn');
    if (copyBtn) {
      e.stopPropagation();
      const address = copyBtn.getAttribute('data-token-address');
      if (address) {
        navigator.clipboard.writeText(address).then(() => {
          const originalHTML = copyBtn.innerHTML;
          copyBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
          copyBtn.classList.add('copied');
          setTimeout(() => {
            copyBtn.innerHTML = originalHTML;
            copyBtn.classList.remove('copied');
          }, 1500);
        }).catch(err => {
          console.error('[AdminTokensModal] Failed to copy address:', err);
        });
      }
    }
  }

  /**
   * Handle pagination button clicks
   * @private
   */
  _handlePaginationClick(e) {
    const pageBtn = e.target.closest('.modal-pagination-btn');
    if (pageBtn && !pageBtn.disabled) {
      const newPage = parseInt(pageBtn.getAttribute('data-page'));
      if (newPage && newPage !== this.pagination.currentPage) {
        this.pagination.currentPage = newPage;
        // Re-render token list with new page
        this._renderTokenList(this.pagination.allTokens, null);
        // Scroll token list to top
        const tokenList = this.container.querySelector('.modal-right-panel');
        if (tokenList) {
          tokenList.scrollTop = 0;
        }
      }
    }
  }

  /**
   * Create token card element
   * @private
   */
  _createTokenCard(token, index) {
    const card = document.createElement('div');
    card.className = 'modal-token-card';
    if (token.is_failed_token) {
      card.classList.add('modal-token-card-failed');
    }
    card.setAttribute('data-token-address', token.base_token);

    const scoreClass = `score-${token.token_score || 0}`;
    const formattedATH = this._formatCurrency(token.ath_market_cap || 0);
    const formattedCurrent = this._formatCurrency(token.market_cap || 0);
    const failedBadge = token.is_failed_token ? '<span class="modal-token-failed-badge">FAILED</span>' : '';

    card.innerHTML = `
      <div class="modal-token-left">
        <div class="modal-token-logo">
          <div class="modal-token-logo-placeholder">?</div>
        </div>
        <div class="modal-token-age-display">${this._formatTokenAge(token.token_age)}</div>
      </div>
      <div class="modal-token-info">
        <div class="modal-token-header">
          <div class="modal-token-name-symbol">
            <span class="modal-token-name">${this._escapeHtml(token.token_name || 'Unknown')}</span>
            <span class="modal-token-symbol">${this._escapeHtml(token.token_symbol || '')}</span>
          </div>
          <div class="modal-token-badges">
            <span class="modal-token-score-badge ${scoreClass}">Score: ${token.token_score || 0}</span>
            ${failedBadge}
          </div>
        </div>
        <div class="modal-token-description">${this._escapeHtml(token.token_name || '')}</div>
        <div class="modal-token-metrics">
          <div class="modal-token-metric">
            <span class="modal-token-metric-label">ATH:</span>
            <span class="modal-token-metric-value">${formattedATH}</span>
          </div>
        </div>
        <div class="modal-token-address-row">
          <span class="modal-token-address">${this._escapeHtml(token.base_token || '')}</span>
          <button class="modal-token-copy-btn" data-token-address="${this._escapeHtml(token.base_token || '')}" title="Copy address">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
        </div>
        <div class="modal-token-socials">
          ${token.community_link ? `<a href="${this._escapeHtml(token.community_link)}" target="_blank" rel="noopener" class="modal-token-social-link" title="Community">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
          </a>` : ''}
        </div>
      </div>
    `;

    return card;
  }

  /**
   * Fetch MEVX data for tokens and update cards progressively
   * @private
   */
  async _fetchMevxData(tokens) {
    const tokenAddresses = tokens.map(t => t.base_token).filter(addr => addr);

    if (tokenAddresses.length === 0) return;

    // Check if modal was closed
    if (!this.isOpen || this.abortController?.signal.aborted) return;

    try {
      const results = await this.mevxClient.fetchBatchTokens(
        tokenAddresses,
        () => {} // Silent progress callback
      );

      // Check again if modal was closed during fetch
      if (!this.isOpen || this.abortController?.signal.aborted) return;

      // Update cards with MEVX data
      results.forEach((data, address) => {
        const card = this.container?.querySelector(`[data-token-address="${address}"]`);
        if (card && data) {
          this._updateTokenCardWithMevx(card, data);
        }
      });

    } catch (error) {
      // Only log if not aborted
      if (!this.abortController?.signal.aborted) {
        console.error('[AdminTokensModal] Failed to fetch MEVX data:', error);
      }
      // Cards will remain with spreadsheet data only
    }
  }

  /**
   * Update token card with MEVX data
   * @private
   */
  _updateTokenCardWithMevx(card, mevxData) {
    const logoContainer = card.querySelector('.modal-token-logo');
    const socialsContainer = card.querySelector('.modal-token-socials');

    // Update logo with better error handling
    if (mevxData.logo && logoContainer) {
      const img = document.createElement('img');
      img.src = mevxData.logo;
      img.alt = '';
      img.crossOrigin = 'anonymous';
      img.referrerPolicy = 'no-referrer';
      img.onerror = () => {
        logoContainer.innerHTML = '<div class="modal-token-logo-placeholder">?</div>';
      };
      logoContainer.innerHTML = '';
      logoContainer.appendChild(img);
    }

    // Update socials (replace existing links with MEVX data)
    if (socialsContainer && mevxData.socials) {
      let socialsHtml = '';

      if (mevxData.socials.twitter) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.twitter)}" target="_blank" rel="noopener" class="modal-token-social-link" title="Twitter">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
        </a>`;
      }

      if (mevxData.socials.website) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.website)}" target="_blank" rel="noopener" class="modal-token-social-link" title="Website">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        </a>`;
      }

      if (mevxData.socials.telegram) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.telegram)}" target="_blank" rel="noopener" class="modal-token-social-link" title="Telegram">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>
        </a>`;
      }

      socialsContainer.innerHTML = socialsHtml;
    }
  }

  /**
   * Render error state
   * @private
   */
  _renderError() {
    const content = this.container.querySelector('.admin-tokens-modal-content');
    if (!content) return;

    content.innerHTML = `
      <div style="grid-column: 1 / -1; padding: 40px;">
        <div class="modal-error-state">
          <div class="modal-error-state-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
          </div>
          <div class="modal-error-state-text">Failed to load admin data</div>
        </div>
      </div>
    `;
  }

  /**
   * Format number for display
   * @private
   */
  _formatNumber(num) {
    const number = parseInt(num) || 0;
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (number >= 1000) {
      return (number / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return number.toString();
  }

  /**
   * Format currency for display
   * @private
   */
  _formatCurrency(value) {
    const number = parseFloat(value) || 0;
    if (number >= 1000000) {
      return '$' + (number / 1000000).toFixed(2) + 'M';
    }
    if (number >= 1000) {
      return '$' + (number / 1000).toFixed(2) + 'K';
    }
    return '$' + number.toFixed(2);
  }

  /**
   * Format token age with detailed breakdown and date
   * @private
   * @param {string} ageString - Age string from sheet (e.g., "24d ago")
   * @returns {string} HTML for age display with badge and date
   */
  _formatTokenAge(ageString) {
    if (!ageString) return '';

    // Parse the age string (e.g., "24d ago", "3mo ago")
    const match = ageString.match(/(\d+)\s*([a-z]+)\s*ago/i);
    if (!match) return `<span class="modal-token-age-badge">${this._escapeHtml(ageString)}</span>`;

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    // Calculate the token creation date
    const now = new Date();
    let creationDate;

    switch (unit) {
      case 'd':
      case 'day':
      case 'days':
        creationDate = new Date(now);
        creationDate.setDate(now.getDate() - value);
        break;
      case 'mo':
      case 'month':
      case 'months':
        creationDate = new Date(now);
        creationDate.setMonth(now.getMonth() - value);
        break;
      case 'h':
      case 'hour':
      case 'hours':
        creationDate = new Date(now);
        creationDate.setHours(now.getHours() - value);
        break;
      default:
        return `<span class="modal-token-age-badge">${this._escapeHtml(ageString)}</span>`;
    }

    // Format the detailed age (e.g., "1mo/35d")
    let detailedAge = ageString.replace(/\s*ago/i, '');
    if (value >= 30 && (unit === 'd' || unit === 'day' || unit === 'days')) {
      const months = Math.floor(value / 30);
      detailedAge = `${months}mo/${value}d`;
    }

    // Format the date (e.g., "14th Jan")
    const day = creationDate.getDate();
    const month = creationDate.toLocaleString('default', { month: 'short' });
    const year = creationDate.getFullYear();
    const currentYear = now.getFullYear();

    let dateString = `${day}${this._getOrdinal(day)} ${month}`;
    if (year !== currentYear) {
      dateString += ` ${year}`;
    }

    return `
      <div class="modal-token-age-container">
        <span class="modal-token-age-badge">${this._escapeHtml(detailedAge)}</span>
        <span class="modal-token-date-badge">${dateString}</span>
      </div>
    `;
  }

  /**
   * Get ordinal suffix for day number
   * @private
   */
  _getOrdinal(day) {
    const j = day % 10;
    const k = day % 100;
    if (j === 1 && k !== 11) return 'st';
    if (j === 2 && k !== 12) return 'nd';
    if (j === 3 && k !== 13) return 'rd';
    return 'th';
  }

  /**
   * Escape HTML to prevent XSS (with caching for performance)
   * @private
   */
  _escapeHtml(text) {
    if (!text) return '';
    const str = String(text);

    // Check cache first
    if (this.escapeCache.has(str)) {
      return this.escapeCache.get(str);
    }

    // Escape HTML entities
    const escaped = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

    // Cache result with size limit
    if (this.escapeCache.size >= this.maxCacheSize) {
      // Clear oldest entries by deleting first few
      let count = 0;
      for (const key of this.escapeCache.keys()) {
        if (count++ > 50) break;
        this.escapeCache.delete(key);
      }
    }
    this.escapeCache.set(str, escaped);

    return escaped;
  }

  /**
   * Setup comments panel event listeners
   * @private
   */
  _setupCommentsPanelListeners() {
    // Comments tab button - toggle panel
    const commentsTab = this.container?.querySelector('#modalCommentsTab');
    if (commentsTab) {
      commentsTab.addEventListener('click', () => this._toggleCommentsPanel());
    }

    // Comments close button
    const commentsCloseBtn = this.container?.querySelector('#modalCommentsCloseBtn');
    if (commentsCloseBtn) {
      commentsCloseBtn.addEventListener('click', () => this._closeCommentsPanel());
    }

    // Comment input
    const commentInput = this.container?.querySelector('#modalCommentInput');
    if (commentInput) {
      commentInput.addEventListener('input', () => this._handleCommentInputChange());
    }

    // Submit button
    const submitBtn = this.container?.querySelector('#modalCommentSubmitBtn');
    if (submitBtn) {
      submitBtn.addEventListener('click', () => this._handleCommentSubmit());
    }

    // Cancel button
    const cancelBtn = this.container?.querySelector('#modalCommentCancelBtn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => this._handleCommentCancel());
    }
  }

  /**
   * Toggle comments panel
   * @private
   */
  _toggleCommentsPanel() {
    if (this.isCommentsPanelOpen) {
      this._closeCommentsPanel();
    } else {
      this._openCommentsPanel();
    }
  }

  /**
   * Open comments panel
   * @private
   */
  _openCommentsPanel() {
    this.isCommentsPanelOpen = true;
    const content = this.container?.querySelector('.admin-tokens-modal-content');
    const panel = this.container?.querySelector('#modalCommentsPanel');
    const commentsTab = this.container?.querySelector('#modalCommentsTab');

    if (content && panel) {
      content.classList.add('comments-panel-open');
      panel.classList.add('open');
    }

    if (commentsTab) {
      commentsTab.classList.add('active');
    }

    // Render comments if not already rendered
    this._renderComments();
  }

  /**
   * Close comments panel
   * @private
   */
  _closeCommentsPanel() {
    this.isCommentsPanelOpen = false;
    const content = this.container?.querySelector('.admin-tokens-modal-content');
    const panel = this.container?.querySelector('#modalCommentsPanel');
    const commentsTab = this.container?.querySelector('#modalCommentsTab');

    if (content && panel) {
      content.classList.remove('comments-panel-open');
      panel.classList.remove('open');
    }

    if (commentsTab) {
      commentsTab.classList.remove('active');
    }

    // Cancel any ongoing edit
    this._handleCommentCancel();
  }

  /**
   * Update comments count badge
   * @private
   */
  _updateCommentsCount() {
    const countBadge = this.container?.querySelector('#modalCommentsCount');
    if (countBadge) {
      const count = this.comments.length;
      countBadge.textContent = count > 0 ? `:${count}` : '';
      countBadge.style.display = count > 0 ? 'inline' : 'none';
    }
  }

  /**
   * Render comments list
   * @private
   */
  _renderComments() {
    const commentsList = this.container?.querySelector('#modalCommentsList');
    if (!commentsList) return;

    if (!this.comments || this.comments.length === 0) {
      commentsList.innerHTML = `
        <div class="modal-comments-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          <p>No comments yet</p>
          <p>Be the first to add a comment!</p>
        </div>
      `;
      return;
    }

    // Sort comments by timestamp (newest first)
    const sortedComments = [...this.comments].sort((a, b) =>
      new Date(b.timestamp) - new Date(a.timestamp)
    );

    const fragment = document.createDocumentFragment();

    sortedComments.forEach(comment => {
      const card = this._createCommentCard(comment);
      fragment.appendChild(card);
    });

    commentsList.innerHTML = '';
    commentsList.appendChild(fragment);
  }

  /**
   * Create a comment card element
   * @private
   */
  _createCommentCard(comment) {
    const card = document.createElement('div');
    card.className = 'modal-comment-card';
    card.setAttribute('data-comment-id', comment.comment_id);

    const formattedTime = CommentsData ? CommentsData.formatTimestamp(comment.timestamp) : '';
    const isEditing = this.editingCommentId === comment.comment_id;

    card.innerHTML = `
      <div class="modal-comment-header">
        <span class="modal-comment-author">${this._escapeHtml(comment.author || 'Unknown')}</span>
        <span class="modal-comment-time">${formattedTime}</span>
        <div class="modal-comment-actions">
          <button class="modal-comment-edit-btn" data-comment-id="${comment.comment_id}" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
          <button class="modal-comment-delete-btn" data-comment-id="${comment.comment_id}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      </div>
      <div class="modal-comment-content">${this._escapeHtml(comment.content)}</div>
    `;

    // Add event listeners for edit and delete buttons
    const editBtn = card.querySelector('.modal-comment-edit-btn');
    const deleteBtn = card.querySelector('.modal-comment-delete-btn');

    if (editBtn) {
      editBtn.addEventListener('click', () => this._handleCommentEdit(comment));
    }

    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => this._handleCommentDelete(comment));
    }

    return card;
  }

  /**
   * Handle comment input change - enable/disable submit button
   * @private
   */
  _handleCommentInputChange() {
    const input = this.container?.querySelector('#modalCommentInput');
    const submitBtn = this.container?.querySelector('#modalCommentSubmitBtn');

    if (input && submitBtn) {
      submitBtn.disabled = !input.value.trim();
    }
  }

  /**
   * Handle comment submit
   * @private
   */
  async _handleCommentSubmit() {
    const input = this.container?.querySelector('#modalCommentInput');
    const submitBtn = this.container?.querySelector('#modalCommentSubmitBtn');

    if (!input || !input.value.trim() || !submitBtn) return;

    const content = input.value.trim();
    const username = this.currentUsername;

    // Show loading state
    submitBtn.disabled = true;
    submitBtn.textContent = 'Posting...';

    try {
      if (this.editingCommentId) {
        // Update existing comment
        await CommentsData.updateComment(this.editingCommentId, content);
      } else {
        // Add new comment - get author name from user or use 'Anonymous'
        const author = 'Anonymous'; // Could be enhanced with user settings
        await CommentsData.addComment(username, content, author);
      }

      // Clear input
      input.value = '';
      this.editingCommentId = null;

      // Update cancel button visibility
      const cancelBtn = this.container?.querySelector('#modalCommentCancelBtn');
      if (cancelBtn) {
        cancelBtn.style.display = 'none';
      }

      // Reset submit button
      submitBtn.textContent = 'Post';

      // Re-fetch comments to get updated list
      this.comments = await this._fetchComments(username);
      this._updateCommentsCount();
      this._renderComments();

    } catch (error) {
      console.error('[AdminTokensModal] Failed to submit comment:', error);
      submitBtn.textContent = 'Failed';
      setTimeout(() => {
        if (submitBtn && this.isOpen) {
          submitBtn.textContent = 'Post';
          submitBtn.disabled = !input.value.trim();
        }
      }, 2000);
    }
  }

  /**
   * Handle comment edit
   * @private
   */
  _handleCommentEdit(comment) {
    const input = this.container?.querySelector('#modalCommentInput');
    const submitBtn = this.container?.querySelector('#modalCommentSubmitBtn');
    const cancelBtn = this.container?.querySelector('#modalCommentCancelBtn');

    if (!input) return;

    // Set input value to existing comment
    input.value = comment.content;
    input.focus();

    // Set editing state
    this.editingCommentId = comment.comment_id;

    // Update submit button
    if (submitBtn) {
      submitBtn.textContent = 'Update';
      submitBtn.disabled = false;
    }

    // Show cancel button
    if (cancelBtn) {
      cancelBtn.style.display = 'inline-block';
    }

    // Scroll to input
    input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /**
   * Handle comment cancel (cancel edit)
   * @private
   */
  _handleCommentCancel() {
    const input = this.container?.querySelector('#modalCommentInput');
    const submitBtn = this.container?.querySelector('#modalCommentSubmitBtn');
    const cancelBtn = this.container?.querySelector('#modalCommentCancelBtn');

    if (input) {
      input.value = '';
    }

    this.editingCommentId = null;

    if (submitBtn) {
      submitBtn.textContent = 'Post';
      submitBtn.disabled = true;
    }

    if (cancelBtn) {
      cancelBtn.style.display = 'none';
    }
  }

  /**
   * Handle comment delete
   * @private
   */
  async _handleCommentDelete(comment) {
    if (!confirm(`Delete this comment by ${comment.author}?`)) return;

    try {
      await CommentsData.deleteComment(comment.comment_id);

      // Re-fetch comments to get updated list
      this.comments = await this._fetchComments(this.currentUsername);
      this._updateCommentsCount();
      this._renderComments();

    } catch (error) {
      console.error('[AdminTokensModal] Failed to delete comment:', error);
      alert('Failed to delete comment. Please try again.');
    }
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.AdminTokensModal = AdminTokensModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AdminTokensModal;
}

} // End of duplicate load guard
