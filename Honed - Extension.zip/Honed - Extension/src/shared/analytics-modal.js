/**
 * Analytics Dashboard Modal
 * Displays tracked admin performance with key metrics
 */

// Guard against duplicate script loading
if (typeof window.AnalyticsModal !== 'undefined') {
  console.log('[AnalyticsModal] Already loaded, skipping...');
} else {

class AnalyticsModal {
  constructor() {
    this.backdrop = null;
    this.container = null;
    this.isOpen = false;
    this.allAdminsData = []; // Store all data for filtering
    this.filteredAdminsData = []; // Store filtered data
    this.currentPage = 1;
    this.itemsPerPage = 20;

    // View state
    this.currentView = 'leaderboard'; // 'leaderboard' or 'calendar'
    this.calendarCurrentMonth = new Date();

    // Filter state
    this.filters = {
      search: '',
      minWinRate: null,
      maxWinRate: null,
      minTokens: null,
      maxTokens: null,
      minScore: null,
      maxScore: null
    };
  }

  /**
   * Show modal
   */
  async show() {
    if (this.isOpen) {
      this.hide();
    }

    this.isOpen = true;

    // Create modal structure
    this._createModal();

    // Add to DOM
    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Listen for storage changes to auto-refresh when sheet data updates
    this.storageListenerBound = this._handleStorageChange.bind(this);
    chrome.storage.onChanged.addListener(this.storageListenerBound);

    // Load and render data
    await this._loadData();
  }

  /**
   * Hide modal
   */
  hide() {
    if (!this.isOpen) return;

    // Immediately disable pointer events on backdrop to prevent any further interactions
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
    }

    // Remove modal from DOM
    if (this.backdrop && this.backdrop.parentNode) {
      this.backdrop.parentNode.removeChild(this.backdrop);
    }

    document.body.classList.remove('modal-open');
    this.isOpen = false;
    this.backdrop = null;
    this.container = null;

    // Remove storage change listener
    if (this.storageListenerBound) {
      chrome.storage.onChanged.removeListener(this.storageListenerBound);
      this.storageListenerBound = null;
    }

    // Remove escape listener
    document.removeEventListener('keydown', this._handleEscape);
  }

  /**
   * Handle storage changes - refresh modal data when sheet data updates
   * @private
   */
  _handleStorageChange(changes, areaName) {
    // Only care about local storage changes
    if (areaName !== 'local' || !this.isOpen) return;

    // Check if sheet data was updated
    if (changes.sheetsTokens || changes.sheetsAdmins) {
      // Refresh the data with current filters
      this._loadData().catch(err => {
        console.error('[AnalyticsModal] Failed to refresh data:', err);
      });
    }
  }

  /**
   * Create modal DOM structure
   * @private
   */
  _createModal() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'analytics-modal-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'analytics-modal-container';

    // Store element reference for tab switching
    this.element = this.container;

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'analytics-modal-close-button';
    closeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
    closeButton.addEventListener('click', () => this.hide());

    // Create header
    const header = document.createElement('div');
    header.className = 'analytics-modal-header';
    header.innerHTML = `
      <div class="analytics-modal-title">📊 Tracked Admins Analytics
        <div class="analytics-tabs">
          <button class="analytics-tab ${this.currentView === 'leaderboard' ? 'active' : ''}" data-view="leaderboard">Leaderboard</button>
          <button class="analytics-tab ${this.currentView === 'calendar' ? 'active' : ''}" data-view="calendar">Calendar</button>
        </div>
      </div>`;

    // Create content area with loading state
    const content = document.createElement('div');
    content.className = 'analytics-modal-content';
    content.innerHTML = `
      <div class="analytics-loading">
        <div class="analytics-spinner"></div>
        <div class="analytics-loading-text">Loading analytics...</div>
      </div>
    `;

    // Assemble modal
    this.container.appendChild(closeButton);
    this.container.appendChild(header);
    this.container.appendChild(content);
    this.backdrop.appendChild(this.container);

    // Add event listeners
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });

    document.addEventListener('keydown', this._handleEscape);
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape = (e) => {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  };

  /**
   * Load and render data
   * @private
   */
  async _loadData() {
    const content = this.container.querySelector('.analytics-modal-content');
    if (!content) return;

    try {
      // Fetch tracked admins and their stats
      const trackedAdmins = await this._getTrackedAdmins();
      this.allAdminsData = await this._getAdminsData(trackedAdmins);

      if (this.allAdminsData.length === 0) {
        this._renderEmptyState(content);
        return;
      }

      // Apply initial filters and render
      this._applyFilters();
      this._renderAnalytics(content, this.filteredAdminsData);

    } catch (error) {
      console.error('[AnalyticsModal] Failed to load data:', error);
      this._renderError(content, error);
    }
  }

  /**
   * Get tracked admins from storage
   * @private
   */
  async _getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  /**
   * Get admins data with stats from sheets
   * @private
   */
  async _getAdminsData(trackedAdmins) {
    if (typeof SheetsData === 'undefined') return [];

    const adminsData = [];

    for (const admin of trackedAdmins) {
      const username = admin.username || admin.userName || admin.screen_name;
      if (!username) continue;

      const stats = await SheetsData.getAdminStats(username);
      if (stats) {
        adminsData.push({
          username,
          name: admin.name,
          profileImage: admin.profileImage,
          ...stats
        });
      }
    }

    // Sort by total rating (lower is better)
    return adminsData.sort((a, b) => (a.total_rating || 999) - (b.total_rating || 999));
  }

  /**
   * Apply filters to admin data
   * @private
   */
  _applyFilters() {
    let filtered = [...this.allAdminsData];

    // Search by username
    if (this.filters.search) {
      const searchLower = this.filters.search.toLowerCase();
      filtered = filtered.filter(admin =>
        admin.username.toLowerCase().includes(searchLower) ||
        (admin.name && admin.name.toLowerCase().includes(searchLower))
      );
    }

    // Min/Max Win Rate
    if (this.filters.minWinRate !== null && this.filters.minWinRate !== '') {
      const minRate = parseFloat(this.filters.minWinRate) / 100;
      filtered = filtered.filter(admin => (admin.winrate || 0) >= minRate);
    }
    if (this.filters.maxWinRate !== null && this.filters.maxWinRate !== '') {
      const maxRate = parseFloat(this.filters.maxWinRate) / 100;
      filtered = filtered.filter(admin => (admin.winrate || 0) <= maxRate);
    }

    // Min/Max Tokens
    if (this.filters.minTokens !== null && this.filters.minTokens !== '') {
      const minTokens = parseInt(this.filters.minTokens);
      filtered = filtered.filter(admin => (admin.total_tokens_created || 0) >= minTokens);
    }
    if (this.filters.maxTokens !== null && this.filters.maxTokens !== '') {
      const maxTokens = parseInt(this.filters.maxTokens);
      filtered = filtered.filter(admin => (admin.total_tokens_created || 0) <= maxTokens);
    }

    // Min/Max Score
    if (this.filters.minScore !== null && this.filters.minScore !== '') {
      const minScore = parseFloat(this.filters.minScore);
      filtered = filtered.filter(admin => (admin.total_rating || 999) >= minScore);
    }
    if (this.filters.maxScore !== null && this.filters.maxScore !== '') {
      const maxScore = parseFloat(this.filters.maxScore);
      filtered = filtered.filter(admin => (admin.total_rating || 0) <= maxScore);
    }

    this.filteredAdminsData = filtered;
    this.currentPage = 1; // Reset to first page when filters change
  }

  /**
   * Calculate aggregate statistics
   * @private
   */
  _calculateStats(adminsData) {
    const totalAdmins = adminsData.length;
    const totalTokens = adminsData.reduce((sum, a) => sum + (a.total_tokens_created || 0), 0);

    // Average rating
    const avgRating = adminsData.reduce((sum, a) => sum + (a.total_rating || 0), 0) / totalAdmins;

    // Average winrate
    const avgWinrate = adminsData.reduce((sum, a) => sum + (a.winrate || 0), 0) / totalAdmins;

    // Success rate (tokens with score 0-1)
    const score0Tokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_0 || 0), 0);
    const score1Tokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_1 || 0), 0);
    const successTokens = score0Tokens + score1Tokens;
    const successRate = totalTokens > 0 ? successTokens / totalTokens : 0;

    // Failed tokens (Score 6) from Admin sheet
    const failedTokens = adminsData.reduce((sum, a) => sum + (a.tokens_score_6 || 0), 0);

    // Best and worst admins
    const bestAdmin = adminsData[0];
    const worstAdmin = adminsData[adminsData.length - 1];

    return {
      totalAdmins,
      totalTokens,
      avgRating,
      avgWinrate,
      successRate,
      successTokens,
      failedTokens,
      bestAdmin,
      worstAdmin
    };
  }

  /**
   * Render analytics content
   * @private
   */
  _renderAnalytics(content, adminsData) {
    const stats = this._calculateStats(adminsData);

    const avgRatingColor = this._getRatingColor(stats.avgRating);
    const avgWinrateColor = stats.avgWinrate >= 0.5 ? '#10b981' : stats.avgWinrate >= 0.3 ? '#fbbf24' : '#ef4444';
    const successRateColor = stats.successRate >= 0.5 ? '#10b981' : stats.successRate >= 0.3 ? '#fbbf24' : '#ef4444';

    content.innerHTML = `
      <!-- Leaderboard View -->
      <div class="analytics-content analytics-leaderboard-view ${this.currentView === 'leaderboard' ? 'active' : ''}">
        <!-- Key Metrics Grid -->
        <div class="analytics-key-metrics">
          <div class="analytics-metric-card analytics-metric-primary">
            <div class="analytics-metric-label">Average Score</div>
            <div class="analytics-metric-value" style="color: ${avgRatingColor}">${stats.avgRating.toFixed(2)}</div>
            <div class="analytics-metric-desc">Across ${stats.totalAdmins} tracked admins</div>
          </div>

          <div class="analytics-metric-card analytics-metric-primary">
            <div class="analytics-metric-label">Average Win Rate</div>
            <div class="analytics-metric-value" style="color: ${avgWinrateColor}">${(stats.avgWinrate * 100).toFixed(1)}%</div>
            <div class="analytics-metric-desc">Success rate across all tokens</div>
          </div>

          <div class="analytics-metric-card analytics-metric-secondary">
            <div class="analytics-metric-label">Success Rate</div>
            <div class="analytics-metric-value" style="color: ${successRateColor}">${(stats.successRate * 100).toFixed(1)}%</div>
            <div class="analytics-metric-desc">Tokens with score 0-1 (${stats.successTokens}/${stats.totalTokens})</div>
          </div>

          <div class="analytics-metric-card analytics-metric-secondary">
            <div class="analytics-metric-label">Total Tokens</div>
            <div class="analytics-metric-value">${this._formatNumber(stats.totalTokens)}</div>
            <div class="analytics-metric-desc">From tracked admins</div>
          </div>
        </div>

        <!-- Filter Section -->
        <div class="analytics-filter-section">
          <div class="analytics-filter-title">🔍 Admin Leaderboard Filters</div>
          <div class="analytics-filter-grid">
            <!-- Search -->
            <div class="analytics-filter-group">
              <label class="analytics-filter-label">Search Username</label>
              <input type="text" class="analytics-filter-input" id="analytics-filter-search" placeholder="Search..." value="${this._escapeHtml(this.filters.search)}">
            </div>

            <!-- Win Rate Range -->
            <div class="analytics-filter-group analytics-filter-range">
              <label class="analytics-filter-label">Win Rate (%)</label>
              <div class="analytics-filter-range-inputs">
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-min-winrate" placeholder="Min" min="0" max="100" value="${this.filters.minWinRate !== null ? this.filters.minWinRate : ''}">
                <span class="analytics-filter-range-separator">-</span>
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-max-winrate" placeholder="Max" min="0" max="100" value="${this.filters.maxWinRate !== null ? this.filters.maxWinRate : ''}">
              </div>
            </div>

            <!-- Tokens Range -->
            <div class="analytics-filter-group analytics-filter-range">
              <label class="analytics-filter-label">Total Tokens</label>
              <div class="analytics-filter-range-inputs">
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-min-tokens" placeholder="Min" min="0" value="${this.filters.minTokens !== null ? this.filters.minTokens : ''}">
                <span class="analytics-filter-range-separator">-</span>
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-max-tokens" placeholder="Max" min="0" value="${this.filters.maxTokens !== null ? this.filters.maxTokens : ''}">
              </div>
            </div>

            <!-- Score Range -->
            <div class="analytics-filter-group analytics-filter-range">
              <label class="analytics-filter-label">Score Range</label>
              <div class="analytics-filter-range-inputs">
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-min-score" placeholder="Min" min="0" max="5" step="0.1" value="${this.filters.minScore !== null ? this.filters.minScore : ''}">
                <span class="analytics-filter-range-separator">-</span>
                <input type="number" class="analytics-filter-input analytics-filter-mini" id="analytics-filter-max-score" placeholder="Max" min="0" max="5" step="0.1" value="${this.filters.maxScore !== null ? this.filters.maxScore : ''}">
              </div>
            </div>

            <!-- Actions -->
            <div class="analytics-filter-actions">
              <button class="analytics-filter-btn analytics-filter-btn-apply" id="analytics-filter-apply">Apply Filters</button>
              <button class="analytics-filter-btn analytics-filter-btn-reset" id="analytics-filter-reset">Reset</button>
            </div>
          </div>

          <!-- Results Count -->
          <div class="analytics-filter-results">
            Showing <strong id="analytics-filtered-count">${this.filteredAdminsData.length}</strong> of <strong>${this.allAdminsData.length}</strong> admins
          </div>
        </div>

        <!-- Filterable Leaderboard -->
        <div class="analytics-full-ranking">
          <div class="analytics-ranking-title">📊 Admin Leaderboard</div>
          <div class="analytics-ranking-table" id="analytics-leaderboard-table">
            ${this._renderLeaderboardRows()}
          </div>
          ${this._renderPagination()}
        </div>
      </div>

      <!-- Calendar View -->
      <div class="analytics-content analytics-calendar-view ${this.currentView === 'calendar' ? 'active' : ''}">
        ${this._createCalendarView()}
      </div>
    `;

    // Attach event listeners
    this._attachFilterListeners();
  }

  /**
   * Render leaderboard rows for current page
   * @private
   */
  _renderLeaderboardRows() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    const pageData = this.filteredAdminsData.slice(startIndex, endIndex);

    return `
      <div class="analytics-ranking-header">
        <div class="analytics-ranking-rank">#</div>
        <div class="analytics-ranking-admin">Admin</div>
        <div class="analytics-rating-distribution">Score Distribution</div>
        <div class="analytics-rating-total">Total</div>
        <div class="analytics-rating-winrate">Win Rate</div>
        <div class="analytics-rating-score">Score</div>
      </div>
      ${pageData.map((admin, index) => {
        const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating) : { formatted: 'N/A', class: '', color: '#888' };
        const globalRank = startIndex + index + 1;
        return `
          <div class="analytics-ranking-row analytics-ranking-row-clickable" data-username="${this._escapeHtml(admin.username)}" data-name="${this._escapeHtml(admin.name || '')}">
            <div class="analytics-ranking-rank">${globalRank}</div>
            <div class="analytics-ranking-admin">
              <img class="analytics-ranking-avatar" src="${admin.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'">
              <span>@${this._escapeHtml(admin.username)}</span>
            </div>
            <div class="analytics-rating-distribution">
              ${this._createScoreDistributionBars(admin)}
            </div>
            <div class="analytics-rating-total">${admin.total_tokens_created || 0}</div>
            <div class="analytics-rating-winrate">${(admin.winrate * 100).toFixed(0)}%</div>
            <div class="analytics-rating-score" style="color: ${scoreData.color}">${scoreData.formatted}</div>
          </div>
        `;
      }).join('')}
    `;
  }

  /**
   * Render pagination controls
   * @private
   */
  _renderPagination() {
    const totalPages = Math.ceil(this.filteredAdminsData.length / this.itemsPerPage);

    if (totalPages <= 1) return '';

    return `
      <div class="analytics-pagination">
        <button class="analytics-pagination-btn" id="analytics-pagination-prev" ${this.currentPage === 1 ? 'disabled' : ''}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
          Previous
        </button>
        <div class="analytics-pagination-info">
          Page <strong>${this.currentPage}</strong> of <strong>${totalPages}</strong>
        </div>
        <button class="analytics-pagination-btn" id="analytics-pagination-next" ${this.currentPage === totalPages ? 'disabled' : ''}>
          Next
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>
      </div>
    `;
  }

  /**
   * Attach event listeners for filters and pagination
   * @private
   */
  _attachFilterListeners() {
    const content = this.container.querySelector('.analytics-modal-content');
    if (!content) return;

    // Filter inputs
    const searchInput = content.querySelector('#analytics-filter-search');
    const minWinRateInput = content.querySelector('#analytics-filter-min-winrate');
    const maxWinRateInput = content.querySelector('#analytics-filter-max-winrate');
    const minTokensInput = content.querySelector('#analytics-filter-min-tokens');
    const maxTokensInput = content.querySelector('#analytics-filter-max-tokens');
    const minScoreInput = content.querySelector('#analytics-filter-min-score');
    const maxScoreInput = content.querySelector('#analytics-filter-max-score');

    // Apply button
    const applyBtn = content.querySelector('#analytics-filter-apply');
    if (applyBtn) {
      applyBtn.addEventListener('click', () => {
        this.filters.search = searchInput.value;
        this.filters.minWinRate = minWinRateInput.value;
        this.filters.maxWinRate = maxWinRateInput.value;
        this.filters.minTokens = minTokensInput.value;
        this.filters.maxTokens = maxTokensInput.value;
        this.filters.minScore = minScoreInput.value;
        this.filters.maxScore = maxScoreInput.value;

        this._applyFilters();
        this._refreshLeaderboard();
      });
    }

    // Reset button
    const resetBtn = content.querySelector('#analytics-filter-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this.filters = {
          search: '',
          minWinRate: null,
          maxWinRate: null,
          minTokens: null,
          maxTokens: null,
          minScore: null,
          maxScore: null
        };

        searchInput.value = '';
        minWinRateInput.value = '';
        maxWinRateInput.value = '';
        minTokensInput.value = '';
        maxTokensInput.value = '';
        minScoreInput.value = '';
        maxScoreInput.value = '';

        this._applyFilters();
        this._refreshLeaderboard();
      });
    }

    // Pagination buttons
    const prevBtn = content.querySelector('#analytics-pagination-prev');
    const nextBtn = content.querySelector('#analytics-pagination-next');

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        if (this.currentPage > 1) {
          this.currentPage--;
          this._refreshLeaderboard();
        }
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(this.filteredAdminsData.length / this.itemsPerPage);
        if (this.currentPage < totalPages) {
          this.currentPage++;
          this._refreshLeaderboard();
        }
      });
    }

    // Row click - show profile modal
    const rows = content.querySelectorAll('.analytics-ranking-row-clickable');
    rows.forEach(row => {
      row.addEventListener('click', () => {
        const username = row.dataset.username;
        const name = row.dataset.name;
        this._showProfileModal(username, name);
      });
    });

    // Tab switching
    const tabs = this.element.querySelectorAll('.analytics-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        this._switchView(tab.dataset.view);
      });
    });

    // Calendar navigation and day click
    this._attachCalendarListeners();
  }

  /**
   * Attach calendar event listeners
   * @private
   */
  _attachCalendarListeners() {
    const container = this.container;
    if (!container) return;

    // Calendar navigation buttons
    const navButtons = container.querySelectorAll('.analytics-calendar-nav-btn');
    navButtons.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const nav = e.target.dataset.nav;
        if (nav === 'prev') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() - 1, 1);
        } else if (nav === 'next') {
          this.calendarCurrentMonth = new Date(this.calendarCurrentMonth.getFullYear(), this.calendarCurrentMonth.getMonth() + 1, 1);
        } else if (nav === 'today') {
          this.calendarCurrentMonth = new Date();
        }
        await this._renderCalendar();
      });
    });

    // Calendar day click
    const dayCells = container.querySelectorAll('.analytics-calendar-day:not(.empty)');
    dayCells.forEach(cell => {
      cell.addEventListener('click', async (e) => {
        const date = cell.dataset.date;
        if (date) {
          const stat = await DailyStatsData.getStatsForDate(date);
          this._showDayDetail(date, stat, e);
        }
      });
    });
  }

  /**
   * Refresh leaderboard after filter/page change
   * @private
   */
  _refreshLeaderboard() {
    const content = this.container.querySelector('.analytics-modal-content');
    if (!content) return;

    // Update filtered count
    const countEl = content.querySelector('#analytics-filtered-count');
    if (countEl) {
      countEl.textContent = this.filteredAdminsData.length;
    }

    // Update table
    const tableEl = content.querySelector('#analytics-leaderboard-table');
    if (tableEl) {
      tableEl.outerHTML = this._renderLeaderboardRows().replace('id="analytics-leaderboard-table"', 'id="analytics-leaderboard-table"');
    }

    // Update pagination
    const parentEl = content.querySelector('.analytics-full-ranking');
    if (parentEl) {
      const existingPagination = parentEl.querySelector('.analytics-pagination');
      if (existingPagination) {
        existingPagination.remove();
      }
      parentEl.insertAdjacentHTML('beforeend', this._renderPagination());
    }

    // Re-attach listeners
    this._attachFilterListeners();
  }

  /**
   * Show profile modal for clicked admin
   * @private
   */
  _showProfileModal(username, name) {
    // Create a simple inline profile card
    const existingModal = document.querySelector('.analytics-profile-modal');
    if (existingModal) {
      existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.className = 'analytics-profile-modal';
    modal.innerHTML = `
      <div class="analytics-profile-backdrop"></div>
      <div class="analytics-profile-card">
        <button class="analytics-profile-close">&times;</button>
        <div class="analytics-profile-header">
          <img class="analytics-profile-avatar" src="">
          <div class="analytics-profile-info">
            <div class="analytics-profile-name">${name || '@' + username}</div>
            <div class="analytics-profile-username">@${username}</div>
          </div>
        </div>
        <div class="analytics-profile-stats">
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Total Tokens</div>
            <div class="analytics-profile-stat-value" id="profile-tokens">-</div>
          </div>
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Win Rate</div>
            <div class="analytics-profile-stat-value" id="profile-winrate">-</div>
          </div>
          <div class="analytics-profile-stat">
            <div class="analytics-profile-stat-label">Score</div>
            <div class="analytics-profile-stat-value" id="profile-score">-</div>
          </div>
        </div>
        <div class="analytics-profile-scores">
          <div class="analytics-profile-scores-title">Score Distribution</div>
          <div class="analytics-profile-scores-grid" id="profile-scores-grid"></div>
        </div>
        <div class="analytics-profile-actions">
          <a href="https://twitter.com/${username}" target="_blank" class="analytics-profile-btn">Open Twitter Profile</a>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Find admin data
    const admin = this.allAdminsData.find(a => a.username.toLowerCase() === username.toLowerCase());

    if (admin) {
      const avatar = modal.querySelector('.analytics-profile-avatar');
      avatar.src = admin.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>';

      modal.querySelector('#profile-tokens').textContent = admin.total_tokens_created || 0;
      modal.querySelector('#profile-winrate').textContent = (admin.winrate * 100).toFixed(0) + '%';

      const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating) : { formatted: 'N/A', color: '#888' };
      const scoreEl = modal.querySelector('#profile-score');
      scoreEl.textContent = scoreData.formatted;
      scoreEl.style.color = scoreData.color;

      // Score distribution
      const scoresGrid = modal.querySelector('#profile-scores-grid');
      scoresGrid.innerHTML = `
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          if (count === 0) return '';
          return `<div class="profile-score-item profile-score-${score}"><span class="profile-score-num">${score}</span><span class="profile-score-count">${count}</span></div>`;
        }).join('')}
      `;
    }

    // Close handlers
    const closeBtn = modal.querySelector('.analytics-profile-close');
    const backdrop = modal.querySelector('.analytics-profile-backdrop');

    const close = () => modal.remove();
    closeBtn.addEventListener('click', close);
    backdrop.addEventListener('click', close);
  }

  /**
   * Switch between leaderboard and calendar view
   * @private
   */
  _switchView(view) {
    this.currentView = view;

    // Update tab buttons
    const tabs = this.element.querySelectorAll('.analytics-tab');
    tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.view === view);
    });

    // Update view containers
    const contentDivs = this.container.querySelectorAll('.analytics-content');
    contentDivs.forEach(content => {
      content.classList.remove('active');
    });

    if (view === 'leaderboard') {
      this.container.querySelector('.analytics-leaderboard-view').classList.add('active');
    } else if (view === 'calendar') {
      this.container.querySelector('.analytics-calendar-view').classList.add('active');
      this._renderCalendar();
    }
  }

  /**
   * Create calendar view HTML
   * @private
   */
  _createCalendarView() {
    return `
      <div class="analytics-calendar-header">
        <div class="analytics-calendar-title">
          <span id="calendarTitle">January 2025</span>
        </div>
        <div class="analytics-calendar-nav">
          <button class="analytics-calendar-nav-btn" data-nav="prev">← Previous</button>
          <button class="analytics-calendar-nav-btn" data-nav="today">Today</button>
          <button class="analytics-calendar-nav-btn" data-nav="next">Next →</button>
        </div>
      </div>

      <div class="analytics-calendar-day-headers">
        <div class="analytics-calendar-day-header">Sun</div>
        <div class="analytics-calendar-day-header">Mon</div>
        <div class="analytics-calendar-day-header">Tue</div>
        <div class="analytics-calendar-day-header">Wed</div>
        <div class="analytics-calendar-day-header">Thu</div>
        <div class="analytics-calendar-day-header">Fri</div>
        <div class="analytics-calendar-day-header">Sat</div>
      </div>

      <div class="analytics-calendar-grid" id="calendarGrid">
        <!-- Calendar days will be rendered here -->
      </div>

      <div class="analytics-calendar-legend">
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color excellent"></div>
          <span>Excellent (0-1.0)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color good"></div>
          <span>Good (1.0-1.8)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color fair"></div>
          <span>Fair (1.8-2.6)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color mixed"></div>
          <span>Mixed (2.6-3.4)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color poor"></div>
          <span>Poor (3.4-4.2)</span>
        </div>
        <div class="analytics-calendar-legend-item">
          <div class="analytics-calendar-legend-color bad"></div>
          <span>Bad (4.2+)</span>
        </div>
      </div>

      <div class="analytics-calendar-day-detail" id="dayDetail">
        <!-- Day detail popup will be rendered here -->
      </div>
    `;
  }

  /**
   * Render calendar for current month
   * @private
   */
  async _renderCalendar() {
    const dailyStats = await DailyStatsData.getAllStats();
    const statsByDate = {};
    dailyStats.forEach(stat => {
      statsByDate[stat.date] = stat;
    });

    const year = this.calendarCurrentMonth.getFullYear();
    const month = this.calendarCurrentMonth.getMonth();

    // Update title
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                        'July', 'August', 'September', 'October', 'November', 'December'];
    const titleEl = document.getElementById('calendarTitle');
    if (titleEl) {
      titleEl.textContent = `${monthNames[month]} ${year}`;
    }

    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Build calendar grid
    const grid = document.getElementById('calendarGrid');
    if (!grid) return;

    grid.innerHTML = '';

    // Empty cells for days before first of month
    for (let i = 0; i < firstDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'analytics-calendar-day empty';
      grid.appendChild(emptyCell);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const stat = statsByDate[date];

      const dayCell = document.createElement('div');
      dayCell.className = 'analytics-calendar-day';
      dayCell.dataset.date = date;

      if (stat) {
        const colorInfo = DailyStatsData.getScoreColor(stat.avg_score);
        dayCell.classList.add(colorInfo.class);

        dayCell.innerHTML = `
          <div class="analytics-calendar-day-number">${day}</div>
          <div class="analytics-calendar-day-stats">
            <div class="analytics-calendar-day-tokens">${stat.tokens_created} tokens</div>
            <div class="analytics-calendar-day-avg">${stat.avg_score.toFixed(1)} avg</div>
          </div>
          <div class="analytics-calendar-day-score"></div>
        `;
      } else {
        dayCell.innerHTML = `
          <div class="analytics-calendar-day-number">${day}</div>
          <div class="analytics-calendar-day-stats">No data</div>
        `;
      }

      grid.appendChild(dayCell);
    }

    // Re-attach calendar listeners
    this._attachCalendarListeners();
  }

  /**
   * Show day detail popup
   * @private
   */
  async _showDayDetail(date, stat, clickEvent) {
    const detailEl = document.getElementById('dayDetail');
    if (!detailEl || !stat) {
      if (detailEl) detailEl.classList.remove('visible');
      return;
    }

    const colorInfo = DailyStatsData.getScoreColor(stat.avg_score);
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dateObj = new Date(date);
    const formattedDate = `${monthNames[dateObj.getMonth()]} ${dateObj.getDate()}, ${dateObj.getFullYear()}`;

    // Build top tokens HTML
    const topTokens = [];
    for (let i = 1; i <= 3; i++) {
      const address = stat[`token_${i}_address`];
      const score = stat[`token_${i}_score`];
      const ath = stat[`token_${i}_ath`];
      if (address) {
        topTokens.push(`
          <div class="analytics-day-detail-token">
            <span class="analytics-day-detail-token-address" title="${address}">${address.substring(0, 16)}...</span>
            <span class="analytics-day-detail-token-score" style="color: ${colorInfo.color}">${score}</span>
            <span class="analytics-day-detail-token-ath">$${ath.toLocaleString()}</span>
          </div>
        `);
      }
    }

    detailEl.innerHTML = `
      <div class="analytics-day-detail-header">
        <div class="analytics-day-detail-date">${formattedDate}</div>
        <button class="analytics-day-detail-close">&times;</button>
      </div>

      <div class="analytics-day-detail-metrics">
        <div class="analytics-day-detail-metric">
          <div class="analytics-day-detail-metric-label">Tokens Created</div>
          <div class="analytics-day-detail-metric-value">${stat.tokens_created}</div>
        </div>
        <div class="analytics-day-detail-metric">
          <div class="analytics-day-detail-metric-label">Avg Score</div>
          <div class="analytics-day-detail-metric-value" style="color: ${colorInfo.color}">${stat.avg_score.toFixed(2)}</div>
        </div>
        <div class="analytics-day-detail-metric">
          <div class="analytics-day-detail-metric-label">Win Rate</div>
          <div class="analytics-day-detail-metric-value">${(stat.win_rate * 100).toFixed(1)}%</div>
        </div>
        <div class="analytics-day-detail-metric">
          <div class="analytics-day-detail-metric-label">Good Tokens (0-2)</div>
          <div class="analytics-day-detail-metric-value">${stat.good_tokens_0_2}</div>
        </div>
      </div>

      ${stat.top_admin ? `
        <div class="analytics-day-detail-admin">
          <div class="analytics-day-detail-admin-label">Top Performer</div>
          <div class="analytics-day-detail-admin-name">${stat.top_admin}</div>
          <div class="analytics-day-detail-admin-stats">
            ${stat.top_admin_avg_score.toFixed(2)} avg score · ${stat.top_admin_tokens} tokens
          </div>
        </div>
      ` : ''}

      ${topTokens.length > 0 ? `
        <div class="analytics-day-detail-tokens">
          <div class="analytics-day-detail-tokens-label">Top 3 Tokens</div>
          ${topTokens.join('')}
        </div>
      ` : ''}

      <div class="analytics-day-detail-actions">
        <button class="analytics-day-detail-btn" data-action="viewTokens" data-date="${date}">
          View All Tokens from ${date}
        </button>
      </div>
    `;

    // Position detail popup
    const rect = clickEvent.target.closest('.analytics-calendar-day').getBoundingClientRect();
    const modalRect = this.container.querySelector('.analytics-modal-content').getBoundingClientRect();

    let left = rect.left - modalRect.left + rect.width / 2 - 160;
    let top = rect.bottom - modalRect.top + 8;

    // Keep within bounds
    left = Math.max(8, Math.min(left, modalRect.width - 328));
    top = Math.max(8, Math.min(top, modalRect.height - 200));

    detailEl.style.left = `${left}px`;
    detailEl.style.top = `${top}px`;
    detailEl.classList.add('visible');

    // Attach close handler
    detailEl.querySelector('.analytics-day-detail-close').addEventListener('click', () => {
      detailEl.classList.remove('visible');
    });

    // Attach view tokens handler
    detailEl.querySelector('.analytics-day-detail-btn').addEventListener('click', () => {
      this._viewTokensForDate(date);
    });
  }

  /**
   * View all tokens created on a specific date
   * @private
   */
  _viewTokensForDate(date) {
    // This would open a filtered view showing only tokens created on this date
    // For now, we show an alert
    alert(`Viewing all tokens from ${date}\n\nThis feature will show all tokens created on ${date}.`);
    // TODO: Implement token filtering by date
    // Could reuse AdminTokensModal with date filtering
  }

  /**
   * Get color for rating value
   * @private
   */
  _getRatingColor(rating) {
    const r = parseFloat(rating) || 0;
    if (r <= 1.5) return '#10b981';
    if (r <= 2.5) return '#22d3ee';
    if (r <= 3.5) return '#fbbf24';
    return '#ef4444';
  }

  /**
   * Create score distribution bars for ranking table
   * @private
   */
  _createScoreDistributionBars(admin) {
    const totalTokens = (admin.tokens_score_0 || 0) + (admin.tokens_score_1 || 0) +
                        (admin.tokens_score_2 || 0) + (admin.tokens_score_3 || 0) +
                        (admin.tokens_score_4 || 0) + (admin.tokens_score_5 || 0) +
                        (admin.tokens_score_6 || 0);

    if (totalTokens === 0) return '<span class="analytics-no-data">-</span>';

    return `
      <div class="dist-grid">
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          return `
            <div class="dist-cell dist-cell-${score}">
              <span class="dist-cell-score">${score}</span>
              <div class="dist-cell-divider"></div>
              <span class="dist-cell-count">${count}</span>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  /**
   * Render empty state
   * @private
   */
  _renderEmptyState(content) {
    content.innerHTML = `
      <div class="analytics-empty">
        <div class="analytics-empty-icon">📊</div>
        <div class="analytics-empty-title">No Tracked Admins</div>
        <div class="analytics-empty-desc">Start tracking admins to see analytics here.<br>Click the star icon on any admin card to track them.</div>
      </div>
    `;
  }

  /**
   * Render error state
   * @private
   */
  _renderError(content, error) {
    content.innerHTML = `
      <div class="analytics-error">
        <div class="analytics-error-icon">⚠️</div>
        <div class="analytics-error-title">Failed to Load Analytics</div>
        <div class="analytics-error-desc">${this._escapeHtml(error.message)}</div>
      </div>
    `;
  }

  /**
   * Format number for display
   * @private
   */
  _formatNumber(num) {
    const number = parseInt(num) || 0;
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (number >= 1000) {
      return (number / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return number.toString();
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   */
  _escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.AnalyticsModal = AnalyticsModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AnalyticsModal;
}

} // End of duplicate load guard
