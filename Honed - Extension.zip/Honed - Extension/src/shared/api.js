/**
 * Unified API Client
 * Centralized API access with automatic caching and request deduplication
 * Uses IndexedDB for caching (no quota limits)
 */

class ApiClient {
  constructor() {
    // Use Vercel APIs to hide the API key
    this.baseUrl = 'https://n1921n8rn25781nr1.vercel.app/api/twitter';
    this.communityBaseUrl = 'https://n1921n8rn25781nr1.vercel.app/api/community';
    // Direct API URL for fallback (key is exposed but Vercel API preferred)
    this.directBaseUrl = 'https://api.twitterapi.io/twitter';
    this.apiKey = 'new1_899820ce8857459c942560025f491007'; // Fallback

    // In-flight request deduplication
    this.pendingRequests = new Map();

    // Cache statistics
    this.stats = {
      community: { hits: 0, misses: 0 },
      user: { hits: 0, misses: 0 },
      deduplicated: 0
    };

    // IndexedDB storage reference (set when available)
    this.db = null;

    // Try to get the global indexedDBStorage (window for content scripts, self for service workers)
    const globalStorage = typeof window !== 'undefined' && window.indexedDBStorage
                        || typeof self !== 'undefined' && self.indexedDBStorage;

    if (globalStorage) {
      this.db = globalStorage;
    }
  }

  /**
   * Ensure DB is initialized before use
   */
  async _ensureDB() {
    if (!this.db) {
      // Try to get the global indexedDBStorage
      const globalStorage = typeof window !== 'undefined' && window.indexedDBStorage
                          || typeof self !== 'undefined' && self.indexedDBStorage;
      if (globalStorage) {
        this.db = globalStorage;
      }
    }
    if (this.db && !this.db.db) {
      await this.db.init();
    }
  }

  /**
   * Get auth token from license validator for API requests
   * @private
   */
  async _getAuthToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseToken', 'licenseTokenExpiry'], (result) => {
        const token = result.licenseToken;
        const expiry = result.licenseTokenExpiry || 0;
        const now = Date.now();

        if (token && expiry > now) {
          resolve(token);
        } else {
          resolve(null);
        }
      });
    });
  }

  /**
   * Fetch community information with caching
   * @param {string} communityId - The community ID to fetch
   * @returns {Promise<Object>} Community data
   */
  async getCommunity(communityId) {
    await this._ensureDB();
    const cacheKey = `community_cache_${communityId}`;

    // Check cache first (IndexedDB)
    const cached = this.db ? await this.db.getCache(cacheKey) : null;
    if (cached) {
      this.stats.community.hits++;
      return cached;
    }

    this.stats.community.misses++;

    // Check for in-flight request
    const pendingKey = `community_${communityId}`;
    if (this.pendingRequests.has(pendingKey)) {
      this.stats.deduplicated++;
      return this.pendingRequests.get(pendingKey);
    }

    // Make new request using Vercel API
    const request = this._fetchCommunityFromVercel(communityId)
      .then(async data => {
        if (this.db) {
          await this.db.setCache(cacheKey, data, null, 'community');
        }
        this.pendingRequests.delete(pendingKey);
        return data;
      })
      .catch(error => {
        this.pendingRequests.delete(pendingKey);
        throw error;
      });

    this.pendingRequests.set(pendingKey, request);
    return request;
  }

  /**
   * Fetch user profile with caching
   * @param {string} username - The username to fetch
   * @returns {Promise<Object>} User profile data
   */
  async getUserProfile(username) {
    await this._ensureDB();
    const cacheKey = `user_profile_${username.toLowerCase()}`;

    // Check cache first (IndexedDB)
    const cached = this.db ? await this.db.getCache(cacheKey) : null;
    if (cached) {
      this.stats.user.hits++;
      return cached;
    }

    this.stats.user.misses++;

    // Check for in-flight request
    const pendingKey = `user_${username}`;
    if (this.pendingRequests.has(pendingKey)) {
      this.stats.deduplicated++;
      return this.pendingRequests.get(pendingKey);
    }

    // Make new request using Vercel API
    const request = this._fetchUserFromVercel(username)
      .then(async data => {
        // API returns {status: "success", data: {...}}
        const userData = data.data || data;
        if (this.db) {
          await this.db.setCache(cacheKey, userData, null, 'user_profile');
        }
        this.pendingRequests.delete(pendingKey);
        return userData;
      })
      .catch(error => {
        this.pendingRequests.delete(pendingKey);
        throw error;
      });

    this.pendingRequests.set(pendingKey, request);
    return request;
  }

  /**
   * Fetch user profile from Vercel API (simplified endpoint)
   * @private
   */
  async _fetchUserFromVercel(username) {
    // Try Vercel API first (hides the API key)
    try {
      // Get auth token from license validator
      const token = await this._getAuthToken();

      const vercelUrl = `${this.baseUrl}?userName=${encodeURIComponent(username)}`;
      const headers = {
        'Content-Type': 'application/json'
      };

      // Add Authorization header if we have a valid token
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch(vercelUrl, { headers });
      const data = await response.json();

      if (response.ok && data && !data.error) {
        return data;
      }
      throw new Error(data.error || 'Vercel API error');
    } catch (vercelError) {
      // Fallback to direct API (key is exposed, but ensures functionality)
      console.warn('[ApiClient] Vercel API failed, falling back to direct API:', vercelError.message);
      return this._fetchDirect(`/user/info?userName=${username}`);
    }
  }

  /**
   * Fetch community from Vercel API (simplified endpoint)
   * @private
   */
  async _fetchCommunityFromVercel(communityId) {
    // Try Vercel API first (hides the API key)
    try {
      // Get auth token from license validator
      const token = await this._getAuthToken();

      const vercelUrl = `${this.communityBaseUrl}?communityId=${encodeURIComponent(communityId)}`;
      const headers = {
        'Content-Type': 'application/json'
      };

      // Add Authorization header if we have a valid token
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch(vercelUrl, { headers });
      const data = await response.json();

      if (response.ok && data && !data.error) {
        return data;
      }
      throw new Error(data.error || 'Vercel API error');
    } catch (vercelError) {
      // Fallback to direct API (key is exposed, but ensures functionality)
      console.warn('[ApiClient] Vercel API failed, falling back to direct API:', vercelError.message);
      return this._fetchDirect(`/community/info?community_id=${communityId}`);
    }
  }

  /**
   * Direct API call with API key (fallback)
   * @private
   */
  async _fetchDirect(endpoint) {
    const url = `${this.directBaseUrl}${endpoint}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-API-Key': this.apiKey,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  /**
   * Clear all API caches (community, user profile, and MEVX token cache)
   */
  async clearCache() {
    await this._ensureDB();
    if (this.db) {
      // Clear by type: community, user_profile, mevx_token
      await this.db.clearCache('community');
      await this.db.clearCache('user_profile');
      await this.db.clearCache('mevx_token');
    }
    // Fallback to chrome.storage for any legacy data
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (items) => {
        const keysToRemove = Object.keys(items).filter(key =>
          key.startsWith('community_cache_') ||
          key.startsWith('user_profile_') ||
          key.startsWith('mevx_token_')
        );

        if (keysToRemove.length > 0) {
          chrome.storage.local.remove(keysToRemove, () => {
            resolve();
          });
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Clear specific cache entry
   */
  async clearKey(key) {
    await this._ensureDB();
    if (this.db) {
      await this.db.deleteCache(key);
    }
    // Also clear from chrome.storage for legacy support
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => {
        resolve();
      });
    });
  }

  /**
   * Get cache statistics
   */
  getStats() {
    return {
      ...this.stats,
      pendingRequests: this.pendingRequests.size
    };
  }

  /**
   * Log cache statistics
   */
  logStats() {
    const stats = this.getStats();
    const communityTotal = stats.community.hits + stats.community.misses;
    const userTotal = stats.user.hits + stats.user.misses;
  }
}

// Export singleton instance
const api = new ApiClient();

// ES module export for use in service workers and other modules
export { api, ApiClient };

// Make available globally for content scripts
if (typeof window !== 'undefined') {
  window.ApiClient = ApiClient;
  window.api = api;
}
