/**
 * Google Sheets Comments Data Access Layer
 * Shared utilities for accessing and managing admin comments from Google Sheets
 * Uses IndexedDB for storage (no quota limits)
 */

// Guard against duplicate script loading
if (typeof window.CommentsData !== 'undefined') {
  console.log('[CommentsData] Already loaded, skipping...');
} else {

class CommentsData {
  /**
   * Get comments for a specific admin username
   * @param {string} username - Admin username
   * @returns {Promise<Array>} Array of comment objects
   */
  static async getComments(username) {
    const usernameLower = username.toLowerCase().trim();

    // Use message passing to get comments from background script's IndexedDB
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getAdminComments', username: usernameLower },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[CommentsData] Message error:', chrome.runtime.lastError);
            resolve([]);
            return;
          }

          if (response?.success && response.comments) {
            resolve(response.comments);
          } else {
            resolve([]);
          }
        }
      );
    });
  }

  /**
   * Check if admin has any comments (for indicator dot)
   * @param {string} username - Admin username
   * @returns {Promise<boolean>} True if admin has comments
   */
  static async hasComments(username) {
    const comments = await this.getComments(username);
    return comments && comments.length > 0;
  }

  /**
   * Get all comments data
   * @returns {Promise<Object>} All comments keyed by username
   */
  static async getAllComments() {
    // Use message passing to get all comments from background script's IndexedDB
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getAllComments' },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[CommentsData] Message error:', chrome.runtime.lastError);
            resolve({});
            return;
          }

          if (response?.success && response.comments) {
            resolve(response.comments);
          } else {
            resolve({});
          }
        }
      );
    });
  }

  /**
   * Add a new comment
   * @param {string} username - Admin username
   * @param {string} content - Comment content
   * @param {string} author - Comment author name
   * @returns {Promise<Object>} Result with success/error
   */
  static async addComment(username, content, author) {
    return new Promise((resolve, reject) => {
      // Generate unique comment ID
      const commentId = this.generateCommentId();
      const timestamp = new Date().toISOString();

      chrome.runtime.sendMessage(
        {
          action: 'addComment',
          commentId: commentId,
          username: username.toLowerCase().trim(),
          content: content.trim(),
          author: author.trim(),
          timestamp: timestamp
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.success) {
            resolve(response);
          } else {
            reject(new Error(response?.error || 'Failed to add comment'));
          }
        }
      );
    });
  }

  /**
   * Update an existing comment
   * @param {string} commentId - Comment ID to update
   * @param {string} content - New comment content
   * @returns {Promise<Object>} Result with success/error
   */
  static async updateComment(commentId, content) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          action: 'updateComment',
          commentId: commentId,
          content: content.trim(),
          updatedAt: new Date().toISOString()
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.success) {
            resolve(response);
          } else {
            reject(new Error(response?.error || 'Failed to update comment'));
          }
        }
      );
    });
  }

  /**
   * Delete a comment
   * @param {string} commentId - Comment ID to delete
   * @returns {Promise<Object>} Result with success/error
   */
  static async deleteComment(commentId) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          action: 'deleteComment',
          commentId: commentId
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.success) {
            resolve(response);
          } else {
            reject(new Error(response?.error || 'Failed to delete comment'));
          }
        }
      );
    });
  }

  /**
   * Generate a unique comment ID
   * @returns {string} UUID v4
   */
  static generateCommentId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * Format timestamp for display
   * @param {string} isoTimestamp - ISO timestamp string
   * @returns {string} Formatted relative time (e.g., "2 hours ago")
   */
  static formatTimestamp(isoTimestamp) {
    const now = new Date();
    const timestamp = new Date(isoTimestamp);
    const diffMs = now - timestamp;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return timestamp.toLocaleDateString();
  }

  /**
   * Escape HTML to prevent XSS
   * @param {string} text - Text to escape
   * @returns {string} Escaped text
   */
  static escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.CommentsData = CommentsData;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CommentsData;
}

} // End of duplicate load guard
