/**
 * Community API Core - Shared Module
 * Common logic for fetching community and admin information via background script
 * Used by both pump.fun (content.js) and axiom.trade (axiom.js)
 */

/**
 * Fetch community information from background script
 * @param {string} communityId - Community ID to fetch
 * @returns {Promise<Object|null>} Community data or null
 */
async function fetchCommunityInfo(communityId) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(
        { action: 'fetchCommunityInfo', communityId },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('[CommunityAPI] Error:', chrome.runtime.lastError);
            resolve(null);
            return;
          }
          if (response?.success && response?.data) {
            resolve(response.data);
          } else {
            resolve(null);
          }
        }
      );
    } catch (e) {
      console.error('[CommunityAPI] Exception:', e);
      resolve(null);
    }
  });
}

/**
 * Register and verify community ownership
 * @param {string} communityName - Community name
 * @param {string} adminUsername - Admin username
 * @returns {Promise<Object>} Verification result
 */
async function registerAndVerifyCommunity(communityName, adminUsername) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({
        action: 'registerCommunityOwner',
        communityName: communityName,
        adminUsername: adminUsername
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[CommunityAPI] Error registering community:', chrome.runtime.lastError);
          resolve({ isFirstOwner: true, isVerified: true });
          return;
        }
        if (response && response.success) {
          resolve(response.data);
        } else {
          resolve({ isFirstOwner: true, isVerified: true });
        }
      });
    } catch (e) {
      console.error('[CommunityAPI] Exception:', e);
      resolve({ isFirstOwner: true, isVerified: true });
    }
  });
}

/**
 * Extract community ID from URL (supports both x.com and twitter.com)
 * @param {string} url - URL to extract from
 * @returns {string|null} Community ID or null
 */
function extractCommunityId(url) {
  const match = url.match(/(?:x\.com|twitter\.com)\/i\/communities\/(\d+)/);
  return match ? match[1] : null;
}

/**
 * Create verification badge element
 * @param {Object} verificationResult - Result from registerAndVerifyCommunity
 * @returns {HTMLElement|null} Badge element or null
 */
function createVerificationBadge(verificationResult) {
  if (!verificationResult) {
    return null;
  }

  const badge = document.createElement('span');
  badge.className = 'verification-badge';

  if (verificationResult.isVerified) {
    // Green checkmark
    badge.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>`;
    badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #10b981 !important; flex-shrink: 0 !important;';
  } else if (verificationResult.realOwner) {
    // Red X with tooltip showing real owner
    badge.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>`;
    badge.title = `Fake! Real owner: @${verificationResult.realOwner}`;
    badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #ef4444 !important; flex-shrink: 0 !important;';
  } else {
    return null;
  }

  return badge;
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.CommunityAPICore = {
    fetchCommunityInfo,
    registerAndVerifyCommunity,
    extractCommunityId,
    createVerificationBadge
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    fetchCommunityInfo,
    registerAndVerifyCommunity,
    extractCommunityId,
    createVerificationBadge
  };
}
