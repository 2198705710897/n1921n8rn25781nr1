/**
 * IndexedDB Storage Layer for Honed Extension
 * Replaces chrome.storage.local for large datasets with no quota limits
 *
 * Stores:
 * - admin_stats (from Google Sheets Admins)
 * - comments (from Google Sheets Comments)
 * - api_cache (Twitter API cache: community, user profiles, MEVX tokens)
 */

const DB_NAME = 'HonedExtensionDB';
const DB_VERSION = 3;

// Store names
const STORES = {
  ADMIN_STATS: 'admin_stats',
  COMMENTS: 'comments',
  TOKENS: 'tokens',
  API_CACHE: 'api_cache',
  METADATA: 'metadata',
  DAILY_STATS: 'daily_stats'
};

/**
 * IndexedDB wrapper class
 */
class IndexedDBStorage {
  constructor() {
    this.db = null;
    this.initPromise = null;
  }

  /**
   * Initialize the database
   */
  async init() {
    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = this._initInternal();
    return this.initPromise;
  }

  async _initInternal() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => {
        console.error('[IndexedDB] Open failed:', request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        console.log('[IndexedDB] Initialized successfully');
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Create admin_stats store (keyed by username)
        if (!db.objectStoreNames.contains(STORES.ADMIN_STATS)) {
          const adminStatsStore = db.createObjectStore(STORES.ADMIN_STATS, { keyPath: 'username' });
          adminStatsStore.createIndex('admin_username', 'admin_username', { unique: false });
        }

        // Create comments store (keyed by comment_id)
        if (!db.objectStoreNames.contains(STORES.COMMENTS)) {
          const commentsStore = db.createObjectStore(STORES.COMMENTS, { keyPath: 'comment_id' });
          commentsStore.createIndex('admin_username', 'admin_username', { unique: false });
        }

        // Create tokens store (keyed by composite key: username_tokenSymbol)
        if (!db.objectStoreNames.contains(STORES.TOKENS)) {
          const tokensStore = db.createObjectStore(STORES.TOKENS, { keyPath: 'id', autoIncrement: true });
          tokensStore.createIndex('admin_username', 'admin_username', { unique: false });
          tokensStore.createIndex('token_symbol', 'token_symbol', { unique: false });
          tokensStore.createIndex('base_token', 'base_token', { unique: false });
        }

        // Create api_cache store (keyed by cache_key)
        if (!db.objectStoreNames.contains(STORES.API_CACHE)) {
          const cacheStore = db.createObjectStore(STORES.API_CACHE, { keyPath: 'cache_key' });
          cacheStore.createIndex('cache_type', 'cache_type', { unique: false });
          cacheStore.createIndex('expires_at', 'expires_at', { unique: false });
        }

        // Create metadata store
        if (!db.objectStoreNames.contains(STORES.METADATA)) {
          db.createObjectStore(STORES.METADATA, { keyPath: 'key' });
        }

        // Create daily_stats store (keyed by date)
        if (!db.objectStoreNames.contains(STORES.DAILY_STATS)) {
          const dailyStatsStore = db.createObjectStore(STORES.DAILY_STATS, { keyPath: 'date' });
          dailyStatsStore.createIndex('tokens_created', 'tokens_created', { unique: false });
          dailyStatsStore.createIndex('avg_score', 'avg_score', { unique: false });
          dailyStatsStore.createIndex('win_rate', 'win_rate', { unique: false });
        }

        console.log('[IndexedDB] Schema created');
      };
    });
  }

  /**
   * Helper to get a transaction and store
   */
  _getStore(storeName, mode = 'readonly') {
    if (!this.db) {
      throw new Error('Database not initialized. Call init() first.');
    }
    const transaction = this.db.transaction([storeName], mode);
    return transaction.objectStore(storeName);
  }

  /**
   * Helper to promisify a request
   */
  _promisify(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // =========================================================================
  // Admin Stats Operations (replaces sheetsAdmins)
  // =========================================================================

  /**
   * Batch upsert admin stats
   * @param {Object} admins - Object mapping username -> admin data
   */
  async setAdminStats(admins) {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS, 'readwrite');

    // Use a single transaction for all operations
    const promises = [];

    for (const [username, data] of Object.entries(admins)) {
      const record = {
        username: username.toLowerCase(),
        ...data,
        updated_at: Date.now()
      };
      const request = store.put(record);
      promises.push(this._promisify(request));
    }

    await Promise.all(promises);
    console.log(`[IndexedDB] Set ${Object.keys(admins).length} admin stats`);
  }

  /**
   * Get single admin stats by username
   */
  async getAdminStats(username) {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS);
    const request = store.get(username.toLowerCase());
    return await this._promisify(request);
  }

  /**
   * Get all admin stats
   * Returns object keyed by username (for compatibility with existing code)
   */
  async getAllAdminStats() {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS);
    const request = store.getAll();
    const results = await this._promisify(request);

    // Convert array to object keyed by username
    const admins = {};
    for (const row of results) {
      admins[row.username] = row;
    }
    return admins;
  }

  /**
   * Clear all admin stats
   */
  async clearAdminStats() {
    await this.init();
    const store = this._getStore(STORES.ADMIN_STATS, 'readwrite');
    const request = store.clear();
    await this._promisify(request);
    console.log('[IndexedDB] Cleared admin stats');
  }

  // =========================================================================
  // Comments Operations (replaces sheetsComments)
  // =========================================================================

  /**
   * Batch upsert comments
   * @param {Object} comments - Object mapping username -> array of comments
   */
  async setComments(comments) {
    await this.init();
    const store = this._getStore(STORES.COMMENTS, 'readwrite');

    const promises = [];

    for (const [username, commentList] of Object.entries(comments)) {
      for (const comment of commentList) {
        const record = {
          ...comment,
          admin_username: comment.admin_username || username
        };
        const request = store.put(record);
        promises.push(this._promisify(request));
      }
    }

    await Promise.all(promises);
    console.log(`[IndexedDB] Set comments for ${Object.keys(comments).length} admins`);
  }

  /**
   * Get comments for a specific admin
   */
  async getComments(username) {
    await this.init();
    const store = this._getStore(STORES.COMMENTS);
    const index = store.index('admin_username');
    const request = index.getAll(username.toLowerCase());
    return await this._promisify(request);
  }

  /**
   * Get all comments keyed by username (for compatibility)
   */
  async getAllComments() {
    await this.init();
    const store = this._getStore(STORES.COMMENTS);
    const request = store.getAll();
    const results = await this._promisify(request);

    // Convert to object keyed by username
    const comments = {};
    for (const row of results) {
      const username = row.admin_username.toLowerCase();
      if (!comments[username]) {
        comments[username] = [];
      }
      comments[username].push(row);
    }
    return comments;
  }

  /**
   * Add a single comment
   */
  async addComment(comment) {
    await this.init();
    const store = this._getStore(STORES.COMMENTS, 'readwrite');
    const request = store.put(comment);
    await this._promisify(request);
  }

  /**
   * Update a comment
   */
  async updateComment(commentId, updates) {
    await this.init();
    const store = this._getStore(STORES.COMMENTS, 'readwrite');

    // First get the existing comment
    const getRequest = store.get(commentId);
    const existing = await this._promisify(getRequest);

    if (existing) {
      const updated = { ...existing, ...updates };
      const putRequest = store.put(updated);
      await this._promisify(putRequest);
    }
  }

  /**
   * Delete a comment
   */
  async deleteComment(commentId) {
    await this.init();
    const store = this._getStore(STORES.COMMENTS, 'readwrite');
    const request = store.delete(commentId);
    await this._promisify(request);
  }

  /**
   * Clear all comments
   */
  async clearComments() {
    await this.init();
    const store = this._getStore(STORES.COMMENTS, 'readwrite');
    const request = store.clear();
    await this._promisify(request);
    console.log('[IndexedDB] Cleared comments');
  }

  // =========================================================================
  // Tokens Operations (stores all tokens from Google Sheets)
  // =========================================================================

  /**
   * Set tokens for admins (clears existing and replaces)
   * @param {Object} tokens - Object mapping username -> array of tokens
   */
  async setTokens(tokens) {
    await this.init();

    // Use a single transaction for both clear and add operations
    const transaction = this.db.transaction([STORES.TOKENS], 'readwrite');
    const store = transaction.objectStore(STORES.TOKENS);

    // Clear existing tokens first (within the same transaction)
    const clearRequest = store.clear();
    await this._promisify(clearRequest);

    // Insert all tokens (within the same transaction)
    const promises = [];
    for (const [username, tokenList] of Object.entries(tokens)) {
      for (const token of tokenList) {
        const record = {
          ...token,
          admin_username: (token.admin_username || username).toLowerCase()
        };
        const request = store.add(record);
        promises.push(this._promisify(request));
      }
    }

    // Wait for all add operations to complete
    await Promise.all(promises);

    // Wait for transaction to complete
    await new Promise((resolve, reject) => {
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });

    console.log(`[IndexedDB] Set tokens for ${Object.keys(tokens).length} admins`);
  }

  /**
   * Get tokens for a specific admin
   */
  async getTokens(username) {
    await this.init();
    const store = this._getStore(STORES.TOKENS);
    const index = store.index('admin_username');
    const request = index.getAll(username.toLowerCase());
    const results = await this._promisify(request);

    // Debug logging to help identify issues
    console.log(`[IndexedDB] getTokens for "${username.toLowerCase()}": found ${results?.length || 0} tokens`);

    return results;
  }

  /**
   * Get all tokens keyed by username (for compatibility)
   */
  async getAllTokens() {
    await this.init();
    const store = this._getStore(STORES.TOKENS);
    const request = store.getAll();
    const results = await this._promisify(request);

    // Convert to object keyed by username
    const tokens = {};
    for (const row of results) {
      const username = row.admin_username.toLowerCase();
      if (!tokens[username]) {
        tokens[username] = [];
      }
      tokens[username].push(row);
    }
    return tokens;
  }

  /**
   * Clear all tokens
   */
  async clearTokens() {
    await this.init();
    const store = this._getStore(STORES.TOKENS, 'readwrite');
    const request = store.clear();
    await this._promisify(request);
    console.log('[IndexedDB] Cleared tokens');
  }

  // =========================================================================
  // Daily Stats Operations
  // =========================================================================

  /**
   * Set daily stats (clears existing and replaces)
   * @param {Array} dailyStats - Array of daily stats objects
   */
  async setDailyStats(dailyStats) {
    await this.init();
    const transaction = this.db.transaction([STORES.DAILY_STATS], 'readwrite');
    const store = transaction.objectStore(STORES.DAILY_STATS);

    const clearRequest = store.clear();
    await this._promisify(clearRequest);

    const promises = [];
    for (const stat of dailyStats) {
      const request = store.put(stat);
      promises.push(this._promisify(request));
    }

    await Promise.all(promises);
    console.log(`[IndexedDB] Set ${dailyStats.length} daily stats`);
  }

  /**
   * Get daily stats for a specific date
   * @param {string} date - Date in YYYY-MM-DD format
   */
  async getDailyStats(date) {
    await this.init();
    const store = this._getStore(STORES.DAILY_STATS);
    const request = store.get(date);
    return await this._promisify(request);
  }

  /**
   * Get all daily stats
   * @returns {Array} Array of daily stats objects
   */
  async getAllDailyStats() {
    await this.init();
    const store = this._getStore(STORES.DAILY_STATS);
    const request = store.getAll();
    return await this._promisify(request);
  }

  // =========================================================================
  // API Cache Operations (replaces chrome.storage.local cache)
  // =========================================================================

  /**
   * Set cache value with optional expiration
   * @param {string} key - Cache key
   * @param {any} value - Value to cache
   * @param {number} ttlSeconds - Time to live in seconds (null = no expiration)
   * @param {string} cacheType - Type of cache (community, user_profile, mevx_token, etc.)
   */
  async setCache(key, value, ttlSeconds = null, cacheType = 'default') {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');

    const record = {
      cache_key: key,
      cache_type: cacheType,
      value: JSON.stringify(value),
      expires_at: ttlSeconds ? Date.now() + (ttlSeconds * 1000) : null,
      created_at: Date.now()
    };

    const request = store.put(record);
    await this._promisify(request);
  }

  /**
   * Get cache value
   */
  async getCache(key) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE);
    const request = store.get(key);
    const result = await this._promisify(request);

    if (!result) return null;

    // Check expiration
    if (result.expires_at && result.expires_at < Date.now()) {
      // Expired, delete and return null
      await this.deleteCache(key);
      return null;
    }

    return JSON.parse(result.value);
  }

  /**
   * Delete cache entry
   */
  async deleteCache(key) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');
    const request = store.delete(key);
    await this._promisify(request);
  }

  /**
   * Clear expired cache entries
   */
  async clearExpiredCache() {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');
    const index = store.index('expires_at');
    const request = index.openCursor(IDBKeyRange.upperBound(Date.now()));

    const deletes = [];
    await new Promise((resolve, reject) => {
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          deletes.push(cursor.delete());
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });

    await Promise.all(deletes);
    console.log(`[IndexedDB] Cleared ${deletes.length} expired cache entries`);
  }

  /**
   * Clear all cache entries (or by type)
   */
  async clearCache(cacheType = null) {
    await this.init();
    const store = this._getStore(STORES.API_CACHE, 'readwrite');

    if (cacheType) {
      const index = store.index('cache_type');
      const request = index.openCursor(IDBKeyRange.only(cacheType));

      const deletes = [];
      await new Promise((resolve, reject) => {
        request.onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor) {
            deletes.push(cursor.delete());
            cursor.continue();
          } else {
            resolve();
          }
        };
        request.onerror = () => reject(request.error);
      });

      await Promise.all(deletes);
      console.log(`[IndexedDB] Cleared ${deletes.length} cache entries (type: ${cacheType})`);
    } else {
      const request = store.clear();
      await this._promisify(request);
      console.log('[IndexedDB] Cleared all cache');
    }
  }

  // =========================================================================
  // Metadata Operations
  // =========================================================================

  /**
   * Set metadata value
   */
  async setMetadata(key, value) {
    await this.init();
    const store = this._getStore(STORES.METADATA, 'readwrite');
    const request = store.put({ key, value });
    await this._promisify(request);
  }

  /**
   * Get metadata value
   */
  async getMetadata(key) {
    await this.init();
    const store = this._getStore(STORES.METADATA);
    const request = store.get(key);
    const result = await this._promisify(request);
    return result ? result.value : null;
  }

  /**
   * Set last sync timestamp
   */
  async setLastSyncTime(timestamp = Date.now()) {
    await this.setMetadata('sheetsLastSync', timestamp);
  }

  /**
   * Get last sync timestamp
   */
  async getLastSyncTime() {
    return await this.getMetadata('sheetsLastSync');
  }

  // =========================================================================
  // Utility Methods
  // =========================================================================

  /**
   * Get database statistics
   */
  async getStats() {
    await this.init();

    const stats = {
      admin_stats: 0,
      comments: 0,
      tokens: 0,
      api_cache: 0,
      daily_stats: 0
    };

    stats.admin_stats = await this._countStore(STORES.ADMIN_STATS);
    stats.comments = await this._countStore(STORES.COMMENTS);
    stats.tokens = await this._countStore(STORES.TOKENS);
    stats.api_cache = await this._countStore(STORES.API_CACHE);
    stats.daily_stats = await this._countStore(STORES.DAILY_STATS);

    return stats;
  }

  /**
   * Count records in a store
   */
  async _countStore(storeName) {
    const store = this._getStore(storeName);
    const request = store.count();
    return await this._promisify(request);
  }

  /**
   * Clear all data (for testing/debugging)
   */
  async clearAll() {
    await this.init();

    for (const storeName of Object.values(STORES)) {
      const store = this._getStore(storeName, 'readwrite');
      const request = store.clear();
      await this._promisify(request);
    }

    console.log('[IndexedDB] Cleared all data');
  }

  /**
   * Close database connection
   */
  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
      this.initPromise = null;
    }
  }
}

// Export singleton instance
const storage = new IndexedDBStorage();

// ES module export
export { storage, IndexedDBStorage, STORES };

// Make available globally for non-module scripts
if (typeof window !== 'undefined') {
  window.IndexedDBStorage = IndexedDBStorage;
  window.indexedDBStorage = storage;

  // Simple debug function that logs stats
  window.honedDebug = async () => {
    try {
      await storage.init();
      const stats = await storage.getStats();
      console.log('%c[Honed Debug] IndexedDB Stats:', 'color: #4ade80; font-weight: bold');
      console.table(stats);
      console.log('%cAdmin stats sample (first 3):', 'color: #60a5fa');
      const admins = await storage.getAllAdminStats();
      const sampleAdmins = Object.values(admins).slice(0, 3);
      console.table(sampleAdmins);
      return stats;
    } catch (err) {
      console.error('Honed debug error:', err);
    }
  };
  console.log('%c[Honed] Type honedDebug() to see IndexedDB stats', 'color: #fbbf24');
}
