/**
 * Admin Leaderboard Modal
 * Filterable and paginated leaderboard for tracked admins
 */

// Guard against duplicate script loading
if (typeof window.LeaderboardModal !== 'undefined') {
  console.log('[LeaderboardModal] Already loaded, skipping...');
} else {

class LeaderboardModal {
  constructor() {
    this.backdrop = null;
    this.container = null;
    this.isOpen = false;
    this.allAdminsData = []; // Store all data for filtering
    this.filteredAdminsData = []; // Store filtered data
    this.currentPage = 1;
    this.itemsPerPage = 20;

    // Filter state
    this.filters = {
      search: '',
      minWinRate: null,
      maxWinRate: null,
      minTokens: null,
      maxTokens: null,
      minScore: null,
      maxScore: null
    };
  }

  /**
   * Show modal
   */
  async show() {
    if (this.isOpen) {
      this.hide();
    }

    this.isOpen = true;

    // Reset filters and pagination
    this.filters = {
      search: '',
      minWinRate: null,
      maxWinRate: null,
      minTokens: null,
      maxTokens: null,
      minScore: null,
      maxScore: null
    };
    this.currentPage = 1;

    // Create modal structure
    this._createModal();

    // Add to DOM
    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Load and render data
    await this._loadData();
  }

  /**
   * Hide modal
   */
  hide() {
    if (!this.isOpen) return;

    // Immediately disable pointer events on backdrop to prevent any further interactions
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
    }

    // Remove modal from DOM
    if (this.backdrop && this.backdrop.parentNode) {
      this.backdrop.parentNode.removeChild(this.backdrop);
    }

    document.body.classList.remove('modal-open');
    this.isOpen = false;
    this.backdrop = null;
    this.container = null;

    // Remove escape listener
    document.removeEventListener('keydown', this._handleEscape);
  }

  /**
   * Create modal DOM structure
   * @private
   */
  _createModal() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'leaderboard-modal-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'leaderboard-modal-container';

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'leaderboard-modal-close-button';
    closeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
    closeButton.addEventListener('click', () => this.hide());

    // Create header
    const header = document.createElement('div');
    header.className = 'leaderboard-modal-header';
    header.innerHTML = `<div class="leaderboard-modal-title">🏆 Admin Leaderboard</div>`;

    // Create content area with loading state
    const content = document.createElement('div');
    content.className = 'leaderboard-modal-content';
    content.innerHTML = `
      <div class="leaderboard-loading">
        <div class="leaderboard-spinner"></div>
        <div class="leaderboard-loading-text">Loading leaderboard...</div>
      </div>
    `;

    // Assemble modal
    this.container.appendChild(closeButton);
    this.container.appendChild(header);
    this.container.appendChild(content);
    this.backdrop.appendChild(this.container);

    // Add event listeners
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });

    document.addEventListener('keydown', this._handleEscape);
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape = (e) => {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  };

  /**
   * Load and render data
   * @private
   */
  async _loadData() {
    const content = this.container.querySelector('.leaderboard-modal-content');
    if (!content) return;

    try {
      // Fetch tracked admins and their stats
      const trackedAdmins = await this._getTrackedAdmins();
      this.allAdminsData = await this._getAdminsData(trackedAdmins);

      if (this.allAdminsData.length === 0) {
        this._renderEmptyState(content);
        return;
      }

      // Apply initial filters and render
      this._applyFilters();
      this._renderLeaderboard(content);

    } catch (error) {
      console.error('[LeaderboardModal] Failed to load data:', error);
      this._renderError(content, error);
    }
  }

  /**
   * Get tracked admins from storage
   * @private
   */
  async _getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  /**
   * Get admins data with stats from sheets
   * @private
   */
  async _getAdminsData(trackedAdmins) {
    if (typeof SheetsData === 'undefined') return [];

    const adminsData = [];

    for (const admin of trackedAdmins) {
      const username = admin.username || admin.userName || admin.screen_name;
      if (!username) continue;

      const stats = await SheetsData.getAdminStats(username);
      if (stats) {
        adminsData.push({
          username,
          name: admin.name,
          profileImage: admin.profileImage,
          ...stats
        });
      }
    }

    // Sort by total rating (lower is better)
    return adminsData.sort((a, b) => (a.total_rating || 999) - (b.total_rating || 999));
  }

  /**
   * Apply filters to admin data
   * @private
   */
  _applyFilters() {
    let filtered = [...this.allAdminsData];

    // Search by username
    if (this.filters.search) {
      const searchLower = this.filters.search.toLowerCase();
      filtered = filtered.filter(admin =>
        admin.username.toLowerCase().includes(searchLower) ||
        (admin.name && admin.name.toLowerCase().includes(searchLower))
      );
    }

    // Min/Max Win Rate
    if (this.filters.minWinRate !== null && this.filters.minWinRate !== '') {
      const minRate = parseFloat(this.filters.minWinRate) / 100;
      filtered = filtered.filter(admin => (admin.winrate || 0) >= minRate);
    }
    if (this.filters.maxWinRate !== null && this.filters.maxWinRate !== '') {
      const maxRate = parseFloat(this.filters.maxWinRate) / 100;
      filtered = filtered.filter(admin => (admin.winrate || 0) <= maxRate);
    }

    // Min/Max Tokens
    if (this.filters.minTokens !== null && this.filters.minTokens !== '') {
      const minTokens = parseInt(this.filters.minTokens);
      filtered = filtered.filter(admin => (admin.total_tokens_created || 0) >= minTokens);
    }
    if (this.filters.maxTokens !== null && this.filters.maxTokens !== '') {
      const maxTokens = parseInt(this.filters.maxTokens);
      filtered = filtered.filter(admin => (admin.total_tokens_created || 0) <= maxTokens);
    }

    // Min/Max Score
    if (this.filters.minScore !== null && this.filters.minScore !== '') {
      const minScore = parseFloat(this.filters.minScore);
      filtered = filtered.filter(admin => (admin.total_rating || 999) >= minScore);
    }
    if (this.filters.maxScore !== null && this.filters.maxScore !== '') {
      const maxScore = parseFloat(this.filters.maxScore);
      filtered = filtered.filter(admin => (admin.total_rating || 0) <= maxScore);
    }

    this.filteredAdminsData = filtered;
    this.currentPage = 1; // Reset to first page when filters change
  }

  /**
   * Render leaderboard content
   * @private
   */
  _renderLeaderboard(content) {
    content.innerHTML = `
      <div class="leaderboard-content">
        <!-- Filter Section -->
        <div class="leaderboard-filter-section">
          <div class="leaderboard-filter-title">🔍 Filters</div>
          <div class="leaderboard-filter-grid">
            <!-- Search -->
            <div class="leaderboard-filter-group">
              <label class="leaderboard-filter-label">Search Username</label>
              <input type="text" class="leaderboard-filter-input" id="leaderboard-filter-search" placeholder="Search..." value="${this._escapeHtml(this.filters.search)}">
            </div>

            <!-- Win Rate Range -->
            <div class="leaderboard-filter-group leaderboard-filter-range">
              <label class="leaderboard-filter-label">Win Rate (%)</label>
              <div class="leaderboard-filter-range-inputs">
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-min-winrate" placeholder="Min" min="0" max="100" value="${this.filters.minWinRate !== null ? this.filters.minWinRate : ''}">
                <span class="leaderboard-filter-range-separator">-</span>
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-max-winrate" placeholder="Max" min="0" max="100" value="${this.filters.maxWinRate !== null ? this.filters.maxWinRate : ''}">
              </div>
            </div>

            <!-- Tokens Range -->
            <div class="leaderboard-filter-group leaderboard-filter-range">
              <label class="leaderboard-filter-label">Total Tokens</label>
              <div class="leaderboard-filter-range-inputs">
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-min-tokens" placeholder="Min" min="0" value="${this.filters.minTokens !== null ? this.filters.minTokens : ''}">
                <span class="leaderboard-filter-range-separator">-</span>
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-max-tokens" placeholder="Max" min="0" value="${this.filters.maxTokens !== null ? this.filters.maxTokens : ''}">
              </div>
            </div>

            <!-- Score Range -->
            <div class="leaderboard-filter-group leaderboard-filter-range">
              <label class="leaderboard-filter-label">Score Range</label>
              <div class="leaderboard-filter-range-inputs">
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-min-score" placeholder="Min" min="0" max="5" step="0.1" value="${this.filters.minScore !== null ? this.filters.minScore : ''}">
                <span class="leaderboard-filter-range-separator">-</span>
                <input type="number" class="leaderboard-filter-input leaderboard-filter-mini" id="leaderboard-filter-max-score" placeholder="Max" min="0" max="5" step="0.1" value="${this.filters.maxScore !== null ? this.filters.maxScore : ''}">
              </div>
            </div>

            <!-- Actions -->
            <div class="leaderboard-filter-actions">
              <button class="leaderboard-filter-btn leaderboard-filter-btn-apply" id="leaderboard-filter-apply">Apply</button>
              <button class="leaderboard-filter-btn leaderboard-filter-btn-reset" id="leaderboard-filter-reset">Reset</button>
            </div>
          </div>

          <!-- Results Count -->
          <div class="leaderboard-filter-results">
            Showing <strong id="leaderboard-filtered-count">${this.filteredAdminsData.length}</strong> of <strong>${this.allAdminsData.length}</strong> admins
          </div>
        </div>

        <!-- Leaderboard Table -->
        <div class="leaderboard-table-section">
          <div class="leaderboard-table" id="leaderboard-table">
            ${this._renderLeaderboardRows()}
          </div>
          ${this._renderPagination()}
        </div>
      </div>
    `;

    // Attach event listeners
    this._attachListeners();
  }

  /**
   * Render leaderboard rows for current page
   * @private
   */
  _renderLeaderboardRows() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    const pageData = this.filteredAdminsData.slice(startIndex, endIndex);

    return `
      <div class="leaderboard-header">
        <div class="leaderboard-rank">#</div>
        <div class="leaderboard-admin">Admin</div>
        <div class="leaderboard-distribution">Score Distribution</div>
        <div class="leaderboard-total">Total</div>
        <div class="leaderboard-winrate">Win Rate</div>
        <div class="leaderboard-score">Score</div>
      </div>
      ${pageData.map((admin, index) => {
        const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating) : { formatted: 'N/A', class: '', color: '#888' };
        const globalRank = startIndex + index + 1;
        return `
          <div class="leaderboard-row leaderboard-row-clickable" data-username="${this._escapeHtml(admin.username)}" data-name="${this._escapeHtml(admin.name || '')}">
            <div class="leaderboard-rank">${globalRank}</div>
            <div class="leaderboard-admin">
              <img class="leaderboard-avatar" src="${admin.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>'">
              <span>@${this._escapeHtml(admin.username)}</span>
            </div>
            <div class="leaderboard-distribution">
              ${this._createScoreDistributionBars(admin)}
            </div>
            <div class="leaderboard-total">${admin.total_tokens_created || 0}</div>
            <div class="leaderboard-winrate">${(admin.winrate * 100).toFixed(0)}%</div>
            <div class="leaderboard-score" style="color: ${scoreData.color}">${scoreData.formatted}</div>
          </div>
        `;
      }).join('')}
    `;
  }

  /**
   * Render pagination controls
   * @private
   */
  _renderPagination() {
    const totalPages = Math.ceil(this.filteredAdminsData.length / this.itemsPerPage);

    if (totalPages <= 1) return '';

    return `
      <div class="leaderboard-pagination">
        <button class="leaderboard-pagination-btn" id="leaderboard-pagination-prev" ${this.currentPage === 1 ? 'disabled' : ''}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
          Previous
        </button>
        <div class="leaderboard-pagination-info">
          Page <strong>${this.currentPage}</strong> of <strong>${totalPages}</strong>
        </div>
        <button class="leaderboard-pagination-btn" id="leaderboard-pagination-next" ${this.currentPage === totalPages ? 'disabled' : ''}>
          Next
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>
      </div>
    `;
  }

  /**
   * Attach event listeners for filters and pagination
   * @private
   */
  _attachListeners() {
    const content = this.container.querySelector('.leaderboard-modal-content');
    if (!content) return;

    // Filter inputs
    const searchInput = content.querySelector('#leaderboard-filter-search');
    const minWinRateInput = content.querySelector('#leaderboard-filter-min-winrate');
    const maxWinRateInput = content.querySelector('#leaderboard-filter-max-winrate');
    const minTokensInput = content.querySelector('#leaderboard-filter-min-tokens');
    const maxTokensInput = content.querySelector('#leaderboard-filter-max-tokens');
    const minScoreInput = content.querySelector('#leaderboard-filter-min-score');
    const maxScoreInput = content.querySelector('#leaderboard-filter-max-score');

    // Apply button
    const applyBtn = content.querySelector('#leaderboard-filter-apply');
    if (applyBtn) {
      applyBtn.addEventListener('click', () => {
        this.filters.search = searchInput.value;
        this.filters.minWinRate = minWinRateInput.value;
        this.filters.maxWinRate = maxWinRateInput.value;
        this.filters.minTokens = minTokensInput.value;
        this.filters.maxTokens = maxTokensInput.value;
        this.filters.minScore = minScoreInput.value;
        this.filters.maxScore = maxScoreInput.value;

        this._applyFilters();
        this._refreshLeaderboard();
      });
    }

    // Reset button
    const resetBtn = content.querySelector('#leaderboard-filter-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this.filters = {
          search: '',
          minWinRate: null,
          maxWinRate: null,
          minTokens: null,
          maxTokens: null,
          minScore: null,
          maxScore: null
        };

        searchInput.value = '';
        minWinRateInput.value = '';
        maxWinRateInput.value = '';
        minTokensInput.value = '';
        maxTokensInput.value = '';
        minScoreInput.value = '';
        maxScoreInput.value = '';

        this._applyFilters();
        this._refreshLeaderboard();
      });
    }

    // Pagination buttons
    const prevBtn = content.querySelector('#leaderboard-pagination-prev');
    const nextBtn = content.querySelector('#leaderboard-pagination-next');

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        if (this.currentPage > 1) {
          this.currentPage--;
          this._refreshLeaderboard();
        }
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(this.filteredAdminsData.length / this.itemsPerPage);
        if (this.currentPage < totalPages) {
          this.currentPage++;
          this._refreshLeaderboard();
        }
      });
    }

    // Row click - show profile modal
    const rows = content.querySelectorAll('.leaderboard-row-clickable');
    rows.forEach(row => {
      row.addEventListener('click', () => {
        const username = row.dataset.username;
        const name = row.dataset.name;
        this._showProfileModal(username, name);
      });
    });
  }

  /**
   * Refresh leaderboard after filter/page change
   * @private
   */
  _refreshLeaderboard() {
    const content = this.container.querySelector('.leaderboard-modal-content');
    if (!content) return;

    // Update filtered count
    const countEl = content.querySelector('#leaderboard-filtered-count');
    if (countEl) {
      countEl.textContent = this.filteredAdminsData.length;
    }

    // Update table
    const tableEl = content.querySelector('#leaderboard-table');
    if (tableEl) {
      tableEl.outerHTML = this._renderLeaderboardRows().replace('id="leaderboard-table"', 'id="leaderboard-table"');
    }

    // Update pagination
    const parentEl = content.querySelector('.leaderboard-table-section');
    if (parentEl) {
      const existingPagination = parentEl.querySelector('.leaderboard-pagination');
      if (existingPagination) {
        existingPagination.remove();
      }
      parentEl.insertAdjacentHTML('beforeend', this._renderPagination());
    }

    // Re-attach listeners
    this._attachListeners();
  }

  /**
   * Show profile modal for clicked admin
   * @private
   */
  _showProfileModal(username, name) {
    // Create a simple inline profile card
    const existingModal = document.querySelector('.leaderboard-profile-modal');
    if (existingModal) {
      existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.className = 'leaderboard-profile-modal';
    modal.innerHTML = `
      <div class="leaderboard-profile-backdrop"></div>
      <div class="leaderboard-profile-card">
        <button class="leaderboard-profile-close">&times;</button>
        <div class="leaderboard-profile-header">
          <img class="leaderboard-profile-avatar" src="">
          <div class="leaderboard-profile-info">
            <div class="leaderboard-profile-name">${name || '@' + username}</div>
            <div class="leaderboard-profile-username">@${username}</div>
          </div>
        </div>
        <div class="leaderboard-profile-stats">
          <div class="leaderboard-profile-stat">
            <div class="leaderboard-profile-stat-label">Total Tokens</div>
            <div class="leaderboard-profile-stat-value" id="profile-tokens">-</div>
          </div>
          <div class="leaderboard-profile-stat">
            <div class="leaderboard-profile-stat-label">Win Rate</div>
            <div class="leaderboard-profile-stat-value" id="profile-winrate">-</div>
          </div>
          <div class="leaderboard-profile-stat">
            <div class="leaderboard-profile-stat-label">Score</div>
            <div class="leaderboard-profile-stat-value" id="profile-score">-</div>
          </div>
        </div>
        <div class="leaderboard-profile-scores">
          <div class="leaderboard-profile-scores-title">Score Distribution</div>
          <div class="leaderboard-profile-scores-grid" id="profile-scores-grid"></div>
        </div>
        <div class="leaderboard-profile-actions">
          <a href="https://twitter.com/${username}" target="_blank" class="leaderboard-profile-btn">Open Twitter Profile</a>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Find admin data
    const admin = this.allAdminsData.find(a => a.username.toLowerCase() === username.toLowerCase());

    if (admin) {
      const avatar = modal.querySelector('.leaderboard-profile-avatar');
      avatar.src = admin.profileImage || 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23666%22><circle cx=%2212%22 cy=%228%22 r=%224%22/><path d=%22M12 14c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4z%22/></svg>';

      modal.querySelector('#profile-tokens').textContent = admin.total_tokens_created || 0;
      modal.querySelector('#profile-winrate').textContent = (admin.winrate * 100).toFixed(0) + '%';

      const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating) : { formatted: 'N/A', color: '#888' };
      const scoreEl = modal.querySelector('#profile-score');
      scoreEl.textContent = scoreData.formatted;
      scoreEl.style.color = scoreData.color;

      // Score distribution
      const scoresGrid = modal.querySelector('#profile-scores-grid');
      scoresGrid.innerHTML = `
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          if (count === 0) return '';
          return `<div class="leaderboard-profile-score-item leaderboard-profile-score-${score}"><span class="leaderboard-profile-score-num">${score}</span><span class="leaderboard-profile-score-count">${count}</span></div>`;
        }).join('')}
      `;
    }

    // Close handlers
    const closeBtn = modal.querySelector('.leaderboard-profile-close');
    const backdrop = modal.querySelector('.leaderboard-profile-backdrop');

    const close = () => modal.remove();
    closeBtn.addEventListener('click', close);
    backdrop.addEventListener('click', close);
  }

  /**
   * Create score distribution bars for table
   * @private
   */
  _createScoreDistributionBars(admin) {
    const totalTokens = (admin.tokens_score_0 || 0) + (admin.tokens_score_1 || 0) +
                        (admin.tokens_score_2 || 0) + (admin.tokens_score_3 || 0) +
                        (admin.tokens_score_4 || 0) + (admin.tokens_score_5 || 0) +
                        (admin.tokens_score_6 || 0);

    if (totalTokens === 0) return '<span class="leaderboard-no-data">-</span>';

    return `
      <div class="leaderboard-dist-grid">
        ${[0,1,2,3,4,5].map(score => {
          const count = admin[`tokens_score_${score}`] || 0;
          return `
            <div class="leaderboard-dist-cell leaderboard-dist-cell-${score}">
              <span class="leaderboard-dist-cell-score">${score}</span>
              <div class="leaderboard-dist-cell-divider"></div>
              <span class="leaderboard-dist-cell-count">${count}</span>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  /**
   * Render empty state
   * @private
   */
  _renderEmptyState(content) {
    content.innerHTML = `
      <div class="leaderboard-empty">
        <div class="leaderboard-empty-icon">🏆</div>
        <div class="leaderboard-empty-title">No Tracked Admins</div>
        <div class="leaderboard-empty-desc">Start tracking admins to see the leaderboard.<br>Click the star icon on any admin card to track them.</div>
      </div>
    `;
  }

  /**
   * Render error state
   * @private
   */
  _renderError(content, error) {
    content.innerHTML = `
      <div class="leaderboard-error">
        <div class="leaderboard-error-icon">⚠️</div>
        <div class="leaderboard-error-title">Failed to Load Leaderboard</div>
        <div class="leaderboard-error-desc">${this._escapeHtml(error.message)}</div>
      </div>
    `;
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   */
  _escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.LeaderboardModal = LeaderboardModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = LeaderboardModal;
}

} // End of duplicate load guard
