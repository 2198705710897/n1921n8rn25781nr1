class LicenseValidator {
  constructor() {
    this.validationUrl = 'https://n1921n8rn25781nr1.vercel.app/api/validate';
    this.checkInterval = 5 * 60 * 1000;
    this.checkTimer = null;
    this.isValid = false;
    this.lastReason = null;
    this.listeners = [];
    this.initialized = false;
    this.deviceId = null;
    this.authToken = null;
  }

  async getDeviceId() {
    if (this.deviceId) return this.deviceId;

    return new Promise((resolve) => {
      chrome.storage.local.get(['honedDeviceId'], (result) => {
        if (result.honedDeviceId) {
          this.deviceId = result.honedDeviceId;
          resolve(this.deviceId);
        } else {
          const extensionId = chrome.runtime.id.substring(0, 8);
          const randomPart = Math.random().toString(36).substring(2, 8);
          const newDeviceId = `${extensionId}-${randomPart}`;

          chrome.storage.local.set({ honedDeviceId: newDeviceId }, () => {
            this.deviceId = newDeviceId;
            console.log('[LicenseValidator] Generated new device ID:', newDeviceId);
            resolve(newDeviceId);
          });
        }
      });
    });
  }

  async init() {
    if (this.initialized) return;

    console.log('[LicenseValidator] Initializing...');

    await this.getDeviceId();

    const storedKey = await this.getLicenseKey();

    if (storedKey) {
      await this.validate(storedKey);
    } else {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
    }

    this.startPeriodicCheck();
    this.initialized = true;

    console.log('[LicenseValidator] Initialized. Valid:', this.isValid, 'Reason:', this.lastReason);
  }

  async getLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey'], (result) => {
        resolve(result.licenseKey || null);
      });
    });
  }

  async saveLicenseKey(key) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ licenseKey: key }, () => {
        console.log('[LicenseValidator] License key saved');
        resolve();
      });
    });
  }

  async clearLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(['licenseKey'], () => {
        console.log('[LicenseValidator] License key cleared');
        resolve();
      });
    });
  }

  async validate(key = null) {
    const keyToCheck = key || await this.getLicenseKey();

    if (!keyToCheck) {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
      return false;
    }

    try {
      const deviceId = await this.getDeviceId();

      console.log('[LicenseValidator] Validating license key for device:', deviceId);
      const response = await fetch(`${this.validationUrl}?key=${encodeURIComponent(keyToCheck)}&deviceId=${encodeURIComponent(deviceId)}`);
      const data = await response.json();

      console.log('[LicenseValidator] Validation response:', data);

      this.isValid = data.valid;
      this.lastReason = data.reason;

      if (data.token) {
        this.authToken = data.token;
        await this._storeToken(data.token);
      }

      // Check for update notification
      if (data.updateNotification && data.updateNotification.active) {
        await this._handleUpdateNotification(data.updateNotification);
      }

      await this._updateStorage(this.isValid);

      this.notifyListeners();

      if (this.isValid) {
        console.log('[LicenseValidator] ✅ License valid');
      } else {
        console.warn('[LicenseValidator] ❌ License invalid:', data.message);
      }

      return this.isValid;

    } catch (error) {
      console.error('[LicenseValidator] Validation error:', error);
      console.warn('[LicenseValidator] Network error, allowing continued use');
      await this._updateStorage(true);
      return true;
    }
  }

  // Removed: No longer storing licenseValid/validUntil in storage
  // Always validate with server instead of trusting client-side storage
  async _updateStorage(isValid) {
    // Storage update removed - validation state now comes from server only
    return Promise.resolve();
  }

  async _storeToken(token) {
    return new Promise((resolve) => {
      const tokenExpiry = Date.now() + (5 * 60 * 1000);

      chrome.storage.local.set({
        licenseToken: token,
        licenseTokenExpiry: tokenExpiry
      }, () => {
        console.log('[LicenseValidator] Token stored');
        resolve();
      });
    });
  }

  async getAuthToken() {
    if (this.authToken && this.isValid) {
      return this.authToken;
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseToken', 'licenseTokenExpiry'], (result) => {
        const token = result.licenseToken;
        const expiry = result.licenseTokenExpiry || 0;
        const now = Date.now();

        if (token && expiry > now) {
          this.authToken = token;
          resolve(token);
        } else {
          resolve(null);
        }
      });
    });
  }

  startPeriodicCheck() {
    if (this.checkTimer) clearInterval(this.checkTimer);

    this.checkTimer = setInterval(async () => {
      console.log('[LicenseValidator] Periodic validation check...');
      await this.validate();
    }, this.checkInterval);

    console.log('[LicenseValidator] Periodic checks started');
  }

  stopPeriodicCheck() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
      console.log('[LicenseValidator] Periodic checks stopped');
    }
  }

  isLicenseValid() {
    return this.isValid;
  }

  getValidationReason() {
    return this.lastReason;
  }

  onValidationChange(callback) {
    this.listeners.push(callback);
  }

  removeValidationListener(callback) {
    this.listeners = this.listeners.filter(cb => cb !== callback);
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      try {
        callback(this.isValid, this.lastReason);
      } catch (error) {
        console.error('[LicenseValidator] Listener error:', error);
      }
    });
  }

  getErrorMessage() {
    switch (this.lastReason) {
      case 'NO_KEY':
        return 'Please enter your license key to use this extension.';
      case 'INVALID':
        return 'Invalid license key. Please purchase a license to use this extension.';
      case 'REVOKED':
        return 'Your license has been revoked. Please contact support.';
      case 'MAINTENANCE':
        return 'Extension is temporarily disabled for maintenance. Please check back later.';
      case 'DEVICE_MISMATCH':
        return 'This license key is already bound to another device. Each key can only be used on one device.';
      default:
        return 'License validation failed. Please try again later.';
    }
  }

  checkFeature(featureName = 'feature') {
    if (!this.isValid) {
      console.warn(`[LicenseValidator] Feature "${featureName}" blocked - license invalid`);
      return false;
    }
    return true;
  }

  async _handleUpdateNotification(notification) {
    const storage = await this._getNotificationStorage();
    const notificationHash = await this._hashNotification(notification.message);

    if (storage.lastShownHash !== notificationHash) {
      console.log('[LicenseValidator] 📢 Update notification:', notification.message);

      // Store in chrome.storage for popup to access
      await new Promise((resolve) => {
        chrome.storage.local.set({
          pendingUpdateNotification: {
            message: notification.message,
            timestamp: Date.now()
          }
        }, resolve);
      });

      await this._setNotificationStorage(notificationHash);
    }
  }

  async _getNotificationStorage() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['updateNotificationStorage'], (result) => {
        resolve(result.updateNotificationStorage || { lastShownHash: null });
      });
    });
  }

  async _setNotificationStorage(hash) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        updateNotificationStorage: {
          lastShownHash: hash,
          updatedAt: Date.now()
        }
      }, resolve);
    });
  }

  async _hashNotification(message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
}

const licenseValidator = new LicenseValidator();

if (typeof window !== 'undefined') {
  window.LicenseValidator = LicenseValidator;
  window.licenseValidator = licenseValidator;
}

export { licenseValidator, LicenseValidator };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { licenseValidator, LicenseValidator };
}
