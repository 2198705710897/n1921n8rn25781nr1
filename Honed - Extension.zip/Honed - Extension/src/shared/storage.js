/**
 * Storage Helper Module
 * Abstraction layer for chrome.storage with typed access
 */

/**
 * Default settings values
 */
const DEFAULT_SETTINGS = {
  xCommunityEnabled: true,
  tweetTrackingEnabled: true,
  showAdminInfo: true,
  showMemberPreview: true,
  showFollowerCount: true,
  adminBackgroundEnabled: true,
  normalAdminColor: '#1a1a2e',
  trackedGradientEnabled: true,
  trackedBorderColor: '#22d3ee',
  trackedGradientColor: '#22d3ee',
  trackedGradientOpacity: 20,
  adminAlertEnabled: false,
  adminAlertVolume: 50,
  adminAlertCustomSound: null,
  communityVerificationEnabled: true
};

/**
 * Storage client for settings (chrome.storage.sync)
 */
class SettingsStorage {
  /**
   * Get all settings
   * @returns {Promise<Object>} Settings object
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
        resolve(settings);
      });
    });
  }

  /**
   * Get a single setting
   * @param {string} key - Setting key
   * @returns {Promise<any>} Setting value
   */
  static async get(key) {
    const settings = await this.getAll();
    return settings[key];
  }

  /**
   * Set a single setting
   * @param {string} key - Setting key
   * @param {any} value - New value
   */
  static async set(key, value) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ [key]: value }, () => {
        resolve();
      });
    });
  }

  /**
   * Set multiple settings
   * @param {Object} settings - Settings object
   */
  static async setMultiple(settings) {
    return new Promise((resolve) => {
      chrome.storage.sync.set(settings, () => {
        resolve();
      });
    });
  }

  /**
   * Listen for settings changes
   * @param {Function} callback - Callback(changes, areaName)
   */
  static onChanged(callback) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        callback(changes, areaName);
      }
    });
  }
}

/**
 * Storage client for local data (chrome.storage.local)
 */
class LocalStorage {
  /**
   * Get value by key
   * @param {string} key - Storage key
   * @returns {Promise<any>} Stored value
   */
  static async get(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        resolve(result[key] || null);
      });
    });
  }

  /**
   * Set value by key
   * @param {string} key - Storage key
   * @param {any} value - Value to store
   */
  static async set(key, value) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => {
        resolve();
      });
    });
  }

  /**
   * Remove value by key
   * @param {string} key - Storage key
   */
  static async remove(key) {
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => {
        resolve();
      });
    });
  }

  /**
   * Clear all local storage
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.clear(() => {
        resolve();
      });
    });
  }

  /**
   * Get all keys matching a pattern
   * @param {string} pattern - RegExp pattern string
   * @returns {Promise<Array<string>>} Matching keys
   */
  static async getKeysByPattern(pattern) {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (items) => {
        const regex = new RegExp(pattern);
        const keys = Object.keys(items).filter(key => regex.test(key));
        resolve(keys);
      });
    });
  }

  /**
   * Clear all keys matching a pattern
   * @param {string} pattern - RegExp pattern string
   */
  static async clearByPattern(pattern) {
    const keys = await this.getKeysByPattern(pattern);
    if (keys.length > 0) {
      return new Promise((resolve) => {
        chrome.storage.local.remove(keys, () => {
          resolve();
        });
      });
    }
  }

  /**
   * Listen for local storage changes
   * @param {Function} callback - Callback(changes, areaName)
   */
  static onChanged(callback) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        callback(changes, areaName);
      }
    });
  }
}

/**
 * Core admins storage helper
 */
class CoreAdminsStorage {
  static STORAGE_KEY = 'coreAdmins';

  /**
   * Get all core admins
   * @returns {Promise<Array>} Array of admin objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a core admin
   * @param {Object} admin - Admin object
   */
  static async add(admin) {
    const admins = await this.getAll();
    admins.push(admin);
    return this.setAll(admins);
  }

  /**
   * Remove a core admin by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const admins = await this.getAll();
    const filtered = admins.filter(a => {
      const adminUsername = a.username || a.userName || a.screen_name;
      return adminUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all core admins
   * @param {Array} admins - Array of admin objects
   */
  static async setAll(admins) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: admins }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all core admins
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is in core list
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if in core list
   */
  static async isCore(username) {
    const admins = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return admins.some(a => {
      const adminUsername = (a.username || a.userName || a.screen_name || '').toLowerCase();
      return adminUsername === normalizedUsername;
    });
  }
}

/**
 * Tracked admins storage helper
 */
class TrackedAdminsStorage {
  static STORAGE_KEY = 'trackedAdmins';

  /**
   * Get all tracked admins
   * @returns {Promise<Array>} Array of admin objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a tracked admin
   * @param {Object} admin - Admin object
   */
  static async add(admin) {
    const admins = await this.getAll();
    admins.push(admin);
    return this.setAll(admins);
  }

  /**
   * Remove a tracked admin by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const admins = await this.getAll();
    const filtered = admins.filter(a => {
      const adminUsername = a.username || a.userName || a.screen_name;
      return adminUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all tracked admins
   * @param {Array} admins - Array of admin objects
   */
  static async setAll(admins) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: admins }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all tracked admins
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is tracked
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if tracked
   */
  static async isTracked(username) {
    const admins = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return admins.some(a => {
      const adminUsername = (a.username || a.userName || a.screen_name || '').toLowerCase();
      return adminUsername === normalizedUsername;
    });
  }
}

/**
 * Tracked tweets storage helper
 */
class TrackedTweetsStorage {
  static STORAGE_KEY = 'trackedTweets';

  /**
   * Get all tracked tweets
   * @returns {Promise<Array>} Array of tweet username objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a tracked tweet username
   * @param {Object} tweet - Tweet username object
   */
  static async add(tweet) {
    const tweets = await this.getAll();
    tweets.push(tweet);
    return this.setAll(tweets);
  }

  /**
   * Remove a tracked tweet by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const tweets = await this.getAll();
    const filtered = tweets.filter(t => {
      const tweetUsername = t.username || t.userName || t.screen_name;
      return tweetUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all tracked tweets
   * @param {Array} tweets - Array of tweet username objects
   */
  static async setAll(tweets) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: tweets }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all tracked tweets
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is tracked
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if tracked
   */
  static async isTracked(username) {
    const tweets = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return tweets.some(t => {
      const tweetUsername = (t.username || t.userName || t.screen_name || '').toLowerCase();
      return tweetUsername === normalizedUsername;
    });
  }
}

/**
 * Blacklisted tweets storage helper
 */
class BlacklistedTweetsStorage {
  static STORAGE_KEY = 'blacklistedTweets';

  /**
   * Get all blacklisted tweets
   * @returns {Promise<Array>} Array of blacklisted tweet username objects
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  /**
   * Add a blacklisted tweet username
   * @param {Object} tweet - Tweet username object
   */
  static async add(tweet) {
    const tweets = await this.getAll();
    tweets.push(tweet);
    return this.setAll(tweets);
  }

  /**
   * Remove a blacklisted tweet by username
   * @param {string} username - Username to remove
   */
  static async remove(username) {
    const tweets = await this.getAll();
    const filtered = tweets.filter(t => {
      const tweetUsername = t.username || t.userName || t.screen_name;
      return tweetUsername !== username;
    });
    return this.setAll(filtered);
  }

  /**
   * Set all blacklisted tweets
   * @param {Array} tweets - Array of blacklisted tweet username objects
   */
  static async setAll(tweets) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: tweets }, () => {
        resolve();
      });
    });
  }

  /**
   * Clear all blacklisted tweets
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: [] }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if username is blacklisted
   * @param {string} username - Username to check
   * @returns {Promise<boolean>} True if blacklisted
   */
  static async isBlacklisted(username) {
    const tweets = await this.getAll();
    const normalizedUsername = username.toLowerCase().replace('@', '');
    return tweets.some(t => {
      const tweetUsername = (t.username || t.userName || t.screen_name || '').toLowerCase();
      return tweetUsername === normalizedUsername;
    });
  }
}

/**
 * Community ownership verification storage helper
 * Tracks which admin owns each community to detect fake tokens
 */
class CommunityOwnersStorage {
  static STORAGE_KEY = 'communityOwners';

  /**
   * Get all community owners mapping
   * @returns {Promise<Object>} Map of community name -> admin username
   */
  static async getAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || {});
      });
    });
  }

  /**
   * Get owner for a specific community
   * @param {string} communityName - Community name
   * @returns {Promise<string|null>} Admin username or null
   */
  static async getOwner(communityName) {
    const allOwners = await this.getAll();
    return allOwners[communityName] || null;
  }

  /**
   * Set owner for a community (first come, first served)
   * @param {string} communityName - Community name
   * @param {string} adminUsername - Admin username
   */
  static async setOwner(communityName, adminUsername) {
    const allOwners = await this.getAll();
    allOwners[communityName] = adminUsername;
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: allOwners }, () => {
        resolve();
      });
    });
  }

  /**
   * Check if admin is the legitimate owner of a community
   * @param {string} communityName - Community name
   * @param {string} adminUsername - Admin username to verify
   * @returns {Promise<boolean>} True if admin is the legitimate owner
   */
  static async verifyOwnership(communityName, adminUsername) {
    const owner = await this.getOwner(communityName);
    if (!owner) {
      return null;
    }
    return owner.toLowerCase() === adminUsername.toLowerCase();
  }

  /**
   * Register a community if not already owned
   * @param {string} communityName - Community name
   * @param {string} adminUsername - Admin username
   * @returns {Promise<Object>} { registered: boolean, isFirstOwner: boolean, isVerified: boolean }
   */
  static async registerCommunity(communityName, adminUsername) {
    const allOwners = await this.getAll();
    const existingOwner = allOwners[communityName];
    const normalizedAdmin = adminUsername.toLowerCase();

    if (!existingOwner) {
      allOwners[communityName] = adminUsername;
      await new Promise((resolve) => {
        chrome.storage.local.set({ [this.STORAGE_KEY]: allOwners }, () => {
          resolve();
        });
      });
      return { registered: true, isFirstOwner: true, isVerified: true };
    }

    const isVerified = existingOwner.toLowerCase() === normalizedAdmin;
    return { registered: false, isFirstOwner: false, isVerified: isVerified, realOwner: existingOwner };
  }

  /**
   * Clear all community owners
   */
  static async clear() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: {} }, () => {
        resolve();
      });
    });
  }

  /**
   * Get all community owners as array
   * @returns {Promise<Array>} Array of { communityName, adminUsername }
   */
  static async getAllAsArray() {
    const allOwners = await this.getAll();
    return Object.entries(allOwners).map(([communityName, adminUsername]) => ({
      communityName,
      adminUsername
    }));
  }

  /**
   * Set all community owners from array
   * @param {Array} owners - Array of { communityName, adminUsername }
   */
  static async setAllFromArray(owners) {
    const allOwners = {};
    owners.forEach(({ communityName, adminUsername }) => {
      allOwners[communityName] = adminUsername;
    });
    return new Promise((resolve) => {
      chrome.storage.local.set({ [this.STORAGE_KEY]: allOwners }, () => {
        resolve();
      });
    });
  }
}

// Export for use in scripts
if (typeof window !== 'undefined') {
  window.SettingsStorage = SettingsStorage;
  window.LocalStorage = LocalStorage;
  window.CoreAdminsStorage = CoreAdminsStorage;
  window.TrackedAdminsStorage = TrackedAdminsStorage;
  window.TrackedTweetsStorage = TrackedTweetsStorage;
  window.BlacklistedTweetsStorage = BlacklistedTweetsStorage;
  window.CommunityOwnersStorage = CommunityOwnersStorage;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DEFAULT_SETTINGS,
    SettingsStorage,
    LocalStorage,
    CoreAdminsStorage,
    TrackedAdminsStorage,
    TrackedTweetsStorage,
    BlacklistedTweetsStorage,
    CommunityOwnersStorage
  };
}
