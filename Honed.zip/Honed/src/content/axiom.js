// Axiom.trade Content Script
// Uses borderOverlay pattern for visual styling on token cards

(async function() {
  'use strict';

  // ============================================
  // LICENSE CHECK - Cached validation with 15s interval
  // ============================================
  let licenseCheckInterval = null;
  let isLicenseValid = false;
  let failureCount = 0;
  const CACHE_TTL = 300000; // 5 minutes cache TTL

  // Initial license check (with server)
  isLicenseValid = await checkLicense();
  if (!isLicenseValid) {
    console.log('[Honed] License invalid - content script disabled');
    return; // Stop all execution
  }

  // Start periodic license validation (every 15 seconds)
  licenseCheckInterval = setInterval(async () => {
    const valid = await checkLicense();
    if (!valid) {
      failureCount++;
      console.log(`[Honed] License validation failed (${failureCount}/3)`);
      if (failureCount >= 3) {
        console.log('[Honed] License invalidated after 3 failures - reloading page');
        clearInterval(licenseCheckInterval);
        window.location.reload();
      }
    } else {
      failureCount = 0; // Reset on success
    }
  }, 15000); // 15 seconds

  // Cleanup interval on page unload
  window.addEventListener('beforeunload', () => {
    if (licenseCheckInterval) {
      clearInterval(licenseCheckInterval);
    }
  });

  async function checkLicense() {
    // Get license key from storage and device ID from background (ensures fingerprint is generated)
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey', 'lastLicenseCheck', 'cachedLicenseValidity', 'updateRequired'], async (result) => {
        const key = result.licenseKey;

        if (!key) {
          resolve(false);
          return;
        }

        // Get device ID from background script (ensures fingerprint generation)
        const deviceResult = await chrome.runtime.sendMessage({ action: 'getDeviceId' });
        if (!deviceResult?.success || !deviceResult.deviceId) {
          console.log('[Honed] Failed to get device ID');
          resolve(false);
          return;
        }
        const deviceId = deviceResult.deviceId;

        // Check 5-minute cache first
        const lastCheck = result.lastLicenseCheck || 0;
        const cached = result.cachedLicenseValidity;
        const cacheAge = Date.now() - lastCheck;

        if (cached !== undefined && cacheAge < CACHE_TTL) {
          console.log(`[Honed] Using cached license validity (${Math.round(cacheAge / 1000)}s old)`);
          // Check if update is cached as required
          if (result.updateRequired) {
            showUpdateRequiredBanner();
            resolve(false);
            return;
          }
          resolve(cached);
          return;
        }

        // Cache miss or expired - validate with server
        try {
          console.log('[Honed] Cache miss - validating with server');
          const response = await fetch('https://n1921n8rn25781nr1.vercel.app/api/validate?key=' + encodeURIComponent(key) + '&deviceId=' + encodeURIComponent(deviceId));
          const data = await response.json();

          // Check for required update
          if (data.updateNotification && data.updateNotification.active) {
            console.log('[Honed] ⚠️ Update required - extension disabled');
            // Store update requirement
            chrome.storage.local.set({
              updateRequired: true,
              updateInfo: {
                message: data.updateNotification.message,
                downloadUrl: data.updateNotification.downloadUrl,
                timestamp: Date.now()
              },
              cachedLicenseValidity: false,
              lastLicenseCheck: Date.now()
            });
            showUpdateRequiredBanner(data.updateNotification);
            resolve(false);
            return;
          }

          // Clear any previous update requirement
          chrome.storage.local.remove(['updateRequired', 'updateInfo']);

          // Cache the result
          chrome.storage.local.set({
            cachedLicenseValidity: data.valid,
            lastLicenseCheck: Date.now()
          });

          if (data.valid) {
            console.log('[Honed] Server validation: valid (cached)');
            resolve(true);
          } else {
            console.log('[Honed] Server validation: invalid -', data.reason);
            resolve(false);
          }
        } catch (error) {
          console.error('[Honed] Validation error:', error);
          // On network error, use cached value if available
          if (cached !== undefined) {
            console.log('[Honed] Network error - using stale cached value');
            resolve(cached);
          } else {
            // No cache available - deny access (fail-closed)
            resolve(false);
          }
        }
      });
    });
  }

  // Show in-page update required banner
  function showUpdateRequiredBanner(updateInfo = null) {
    // Check if banner already exists
    if (document.getElementById('honed-update-required-banner')) return;

    const message = updateInfo?.message || 'An update is required to continue using Honed.';
    const downloadUrl = updateInfo?.downloadUrl;

    const banner = document.createElement('div');
    banner.id = 'honed-update-required-banner';
    banner.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      border-bottom: 2px solid #e94560;
      padding: 16px 24px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      box-shadow: 0 4px 20px rgba(233, 69, 96, 0.3);
    `;

    const iconSvg = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#e94560" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
        <path d="M2 17l10 5 10-5"></path>
        <path d="M2 12l10 5 10-5"></path>
      </svg>
    `;

    const contentHtml = `
      <div style="display: flex; align-items: center; gap: 12px;">
        ${iconSvg}
        <div>
          <div style="color: #fff; font-weight: 600; font-size: 14px;">Update Required</div>
          <div style="color: #a0a0a0; font-size: 13px; max-width: 500px;">${message}</div>
        </div>
      </div>
      ${downloadUrl ? `
        <a href="${downloadUrl}" target="_blank" style="
          background: #e94560;
          color: #fff;
          padding: 8px 20px;
          border-radius: 6px;
          text-decoration: none;
          font-weight: 600;
          font-size: 13px;
          white-space: nowrap;
          transition: background 0.2s;
        " onmouseover="this.style.background='#d63850'" onmouseout="this.style.background='#e94560'">
          Download Update
        </a>
      ` : ''}
    `;

    banner.innerHTML = contentHtml;
    document.body.appendChild(banner);

    // Adjust body padding to prevent content from being hidden
    document.body.style.paddingTop = '72px';

    console.log('[Honed] Update required banner shown');
  }

  // Helper to safely call Chrome APIs
  function safeChromeAPI(apiCall, fallback) {
    try {
      return apiCall();
    } catch (e) {
      if (e.message.includes('Extension context invalidated')) {
        return fallback;
      }
      throw e;
    }
  }

  // In-memory cache for community data
  const communityDataCache = new Map();
  const processedCards = new Set();

  // Track verification results per community for current page session
  // This ensures consistent results even if page re-renders
  const communityVerificationCache = new Map();

  // Track tokens that have already played their admin alert (persists across page navigations)
  let playedAlertTokens = new Set();
  let playedAlertsLoaded = false;

  // Load played alerts from storage on init (returns Promise)
  function loadPlayedAlerts() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['playedAdminAlerts'], (result) => {
        if (result.playedAdminAlerts && Array.isArray(result.playedAdminAlerts)) {
          playedAlertTokens = new Set(result.playedAdminAlerts);
          console.log('[AdminAlert] Loaded', playedAlertTokens.size, 'played alerts from storage');
        }
        playedAlertsLoaded = true;
        resolve();
      });
    });
  }

  // Check if token has already played alert
  function hasPlayedAlert(tokenAlertId) {
    return playedAlertTokens.has(tokenAlertId);
  }

  // Mark token as having played alert and persist to storage
  function markAlertPlayed(tokenAlertId) {
    playedAlertTokens.add(tokenAlertId);
    chrome.storage.local.set({ playedAdminAlerts: Array.from(playedAlertTokens) });
  }

  // Settings cache
  let cachedSettings = {
    xCommunityEnabled: true,
    trackedBorderColor: '#22d3ee',
    trackedGradientColor: '#22d3ee',
    normalAdminColor: '#1a1a2e',
    trackedGradientOpacity: 20,
    showAdminInfo: true,
    showMemberPreview: true,
    showFollowerCount: true,
    showTrackBlacklistButtons: true,
    communityVerificationEnabled: true,
    showSheetScores: true
  };

  let cachedTrackedAdmins = [];
  let cachedBlacklistedAdmins = [];
  let trackedUsernamesSet = new Set();
  let blacklistedUsernamesSet = new Set();

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      safeChromeAPI(() => {
        chrome.storage.sync.get({
          xCommunityEnabled: true,
          trackedBorderColor: '#22d3ee',
          trackedGradientColor: '#22d3ee',
          normalAdminColor: '#1a1a2e',
          trackedGradientOpacity: 20,
          showAdminInfo: true,
          showMemberPreview: true,
          showFollowerCount: true,
          showTrackBlacklistButtons: true,
          communityVerificationEnabled: true,
          showSheetScores: true,
          showChartScoreDistro: true
        }, (settings) => {
          resolve(settings);
        });
      }, () => resolve({
        xCommunityEnabled: true,
        trackedBorderColor: '#22d3ee',
        trackedGradientColor: '#22d3ee',
        normalAdminColor: '#1a1a2e',
        trackedGradientOpacity: 20,
        showAdminInfo: true,
        showMemberPreview: true,
        showFollowerCount: true,
        showTrackBlacklistButtons: true,
        communityVerificationEnabled: true,
        showSheetScores: true,
        showChartScoreDistro: true
      }));
    });
  }

  // Get tracked admins from storage
  async function getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  // Get blacklisted admins from storage
  async function getBlacklistedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['blacklistedAdmins'], (result) => {
        resolve(result.blacklistedAdmins || []);
      });
    });
  }

  // Update cached tracked admins
  function updateCachedTrackedAdmins(admins) {
    cachedTrackedAdmins = admins;
    trackedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Update cached blacklisted admins
  function updateCachedBlacklistedAdmins(admins) {
    cachedBlacklistedAdmins = admins;
    blacklistedUsernamesSet = new Set(
      admins.map(a => {
        const username = a.username || a.userName || a.screen_name;
        return username ? username.toLowerCase() : null;
      }).filter(Boolean)
    );
  }

  // Extract community ID from URL
  function extractCommunityId(url) {
    const match = url.match(/(?:x\.com|twitter\.com)\/i\/communities\/(\d+)/);
    return match ? match[1] : null;
  }

  // Fetch community information from background worker
  async function fetchCommunityInfo(communityId) {
    if (communityDataCache.has(communityId)) {
      return communityDataCache.get(communityId);
    }

    const data = await new Promise((resolve, reject) => {
      safeChromeAPI(() => {
        chrome.runtime.sendMessage({
          action: 'fetchCommunityInfo',
          communityId: communityId
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response?.error || 'Failed to fetch community info'));
          }
        });
      }, () => reject(new Error('Extension context invalidated')));
    });

    communityDataCache.set(communityId, data);
    return data;
  }

  // Format follower count
  function formatNumber(count) {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    }
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  }

  // ============================================
  // ProfileTooltip - Cursor-following hover tooltip
  // Extends ProfileTooltipCore with sheet stats functionality
  // ============================================
  class ProfileTooltip extends ProfileTooltipCore {
    constructor() {
      super();
    }

    async _loadAndShow() {
      if (!this.tooltip) {
        this.tooltip = this._createTooltip();
      }

      this._setLoading();
      this.tooltip.style.display = 'block';
      this.tooltip.style.pointerEvents = 'auto'; // Ensure it can receive events when shown
      this.isActive = true;

      // Initial position near target element with viewport boundary checking
      const rect = this.targetElement.getBoundingClientRect();
      const offset = 8;
      const tooltipRect = this.tooltip.getBoundingClientRect();

      // Calculate initial position (right of target)
      let left = rect.right + offset;
      let top = rect.top;

      // Prevent right edge overflow - show to the left instead
      if (left + tooltipRect.width > window.innerWidth) {
        left = rect.left - tooltipRect.width - offset;
      }

      // Prevent bottom edge overflow
      if (top + tooltipRect.height > window.innerHeight) {
        top = window.innerHeight - tooltipRect.height - offset;
      }

      // Also prevent top overflow
      if (top < offset) {
        top = offset;
      }

      // Prevent left overflow
      if (left < offset) {
        left = offset;
      }

      this.tooltip.style.left = `${left}px`;
      this.tooltip.style.top = `${top}px`;

      try {
        const data = await this._fetchProfile(this.currentUsername);
        this._populate(data);

        // Re-check boundaries after content loads (dimensions may have changed)
        const newRect = this.tooltip.getBoundingClientRect();
        let newLeft = parseFloat(this.tooltip.style.left);
        let newTop = parseFloat(this.tooltip.style.top);

        if (newLeft + newRect.width > window.innerWidth) {
          newLeft = window.innerWidth - newRect.width - offset;
        }
        if (newLeft < offset) {
          newLeft = offset;
        }
        if (newTop + newRect.height > window.innerHeight) {
          newTop = window.innerHeight - newRect.height - offset;
        }
        if (newTop < offset) {
          newTop = offset;
        }

        this.tooltip.style.left = `${newLeft}px`;
        this.tooltip.style.top = `${newTop}px`;
      } catch (err) {
        console.error('[ProfileTooltip] Failed to fetch profile:', err);
        this._setError();
      }
    }

    async _fetchProfile(username) {
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'fetchUserProfile', username },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (response?.success && response?.data) {
              resolve(response.data);
            } else {
              reject(new Error(response?.error || 'Fetch failed'));
            }
          }
        );
      });
    }

    async _populate(data) {
      // Use core's populate method for basic profile data
      this._populateData(data);

      // Add sheet stats section - use the original Community API username
      // NOT the profile API username, as they may differ in casing/format
      await this._addSheetStatsSection(this.currentUsername);
    }

    // Add sheet stats section to tooltip
    async _addSheetStatsSection(username) {
      if (typeof SheetsData === 'undefined') return;

      const stats = await SheetsData.getAdminStats(username);
      if (!stats) return;

      const tooltip = this.tooltip;

      // Remove ALL existing stats sections (for when hovering over different admins)
      const existingSections = tooltip.querySelectorAll('.tooltip-sheet-stats');
      existingSections.forEach(section => section.remove());

      const contentArea = tooltip.querySelector('.tooltip-content');
      if (!contentArea) return;

      const scoreData = SheetsData.formatScore(stats.total_rating);

      // Create score section
      const scoreSection = document.createElement('div');
      scoreSection.className = 'tooltip-sheet-stats';

      scoreSection.innerHTML = `
        <div class="sheet-stats-divider"></div>
        <div class="sheet-stats-header">Admin Performance</div>
        <div class="sheet-stats-grid">
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Rating</span>
            <span class="sheet-stat-value ${scoreData.class}" style="color: ${scoreData.color}">
              ${scoreData.formatted}
            </span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Tokens</span>
            <span class="sheet-stat-value">${stats.total_tokens_created || 0}</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Winrate</span>
            <span class="sheet-stat-value">${((stats.winrate || 0) * 100).toFixed(0)}%</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Failed</span>
            <span class="sheet-stat-value score-poor">${stats.tokens_score_6 || 0}</span>
          </div>
        </div>
        <div class="score-distribution">
          <div class="dist-label">Score Distribution</div>
          <div class="dist-grid">
            ${[0,1,2,3,4,5].map(score => {
              const count = stats[`tokens_score_${score}`] || 0;
              return `
                <div class="dist-cell dist-cell-${score}">
                  <span class="dist-cell-score">${score}</span>
                  <div class="dist-cell-divider"></div>
                  <span class="dist-cell-count">${count}</span>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;

      contentArea.appendChild(scoreSection);
    }
  }

  // Create singleton tooltip instance
  const profileTooltip = new ProfileTooltip();

  // Create singleton modal instances
  const adminTokensModal = typeof AdminTokensModal !== 'undefined' ? new AdminTokensModal(profileTooltip) : null;
  const analyticsModal = typeof AnalyticsModal !== 'undefined' ? new AnalyticsModal() : null;


  // Initialize hot reload manager for admin scores
  if (typeof AdminDisplayHotReload !== 'undefined' && typeof SheetsData !== 'undefined') {
    const adminDisplayHotReload = new AdminDisplayHotReload(SheetsData);
    adminDisplayHotReload.start();
  }

  // ============================================
  // Button Injection Functions for Axiom Toolbar
  // ============================================

  // Inject Analytics button into axiom.trade toolbar
  function injectAnalyticsButton() {
    // Look for the toolbar container directly
    const toolbars = document.querySelectorAll('.flex.flex-row.items-center.gap-4');

    for (const toolbar of toolbars) {
      // Check if analytics button already exists
      if (toolbar.querySelector('.axiom-analytics-trigger-button')) continue;

      // Find the first button in the toolbar (usually the help/question button)
      const firstButton = toolbar.querySelector('button');
      if (!firstButton) continue;

      // Create analytics button matching Axiom's styling
      const analyticsButton = document.createElement('button');
      analyticsButton.type = 'button';
      analyticsButton.className = 'group relative flex h-8 w-8 items-center justify-center rounded-full bg-background transition-colors hover:bg-primaryStroke/60 axiom-analytics-trigger-button';
      analyticsButton.innerHTML = `<i class="ri-bar-chart-box-line text-[16px] text-textSecondary group-hover:text-textPrimary"></i>`;
      analyticsButton.title = 'Analytics';

      // Add click handler to open analytics modal
      analyticsButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (analyticsModal) {
          analyticsModal.show();
        } else {
          console.error('Analytics modal not available');
        }
      });

      // Insert after the first button
      if (firstButton.nextSibling) {
        toolbar.insertBefore(analyticsButton, firstButton.nextSibling);
      } else {
        toolbar.appendChild(analyticsButton);
      }

      console.log('[Axiom] Injected Analytics button');
      // Only inject once per toolbar
      break;
    }
  }



  // Inject Admin Search button into axiom.trade toolbar
  function injectAdminSearchButton() {
    // Look for the toolbar container directly
    const toolbars = document.querySelectorAll('.flex.flex-row.items-center.gap-4');

    for (const toolbar of toolbars) {
      // Check if admin search button already exists
      if (toolbar.querySelector('.axiom-admin-search-trigger-button')) continue;

      // Find the analytics button we injected
      const analyticsBtn = toolbar.querySelector('.axiom-analytics-trigger-button');
      if (!analyticsBtn) continue;

      // Create admin search button matching Axiom's styling
      const adminSearchButton = document.createElement('button');
      adminSearchButton.type = 'button';
      adminSearchButton.className = 'group relative flex h-8 w-8 items-center justify-center rounded-full bg-background transition-colors hover:bg-primaryStroke/60 axiom-admin-search-trigger-button';
      adminSearchButton.innerHTML = `<i class="ri-search-line text-[16px] text-textSecondary group-hover:text-textPrimary"></i>`;
      adminSearchButton.title = 'Admin Search';

      // Add click handler to open admin search modal
      adminSearchButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openAdminSearchModal();
      });

      // Insert after the analytics button
      if (analyticsBtn.nextSibling) {
        toolbar.insertBefore(adminSearchButton, analyticsBtn.nextSibling);
      } else {
        toolbar.appendChild(adminSearchButton);
      }

      console.log('[Axiom] Injected Admin Search button');
      // Only inject once per toolbar
      break;
    }
  }

  // Open admin search modal
  function openAdminSearchModal() {
    // Create modal backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'analytics-modal-backdrop admin-search-modal-backdrop';
    backdrop.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.9);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: analytics-backdrop-fade-in 0.15s ease-out;
    `;

    // Create modal container
    const modal = document.createElement('div');
    modal.className = 'analytics-modal-container admin-search-modal-container';
    modal.style.cssText = `
      position: relative;
      width: 500px;
      max-width: 95vw;
      background: #111;
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      overflow: hidden;
      animation: analytics-scale-in 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      flex-direction: column;
    `;

    modal.innerHTML = `
      <button class="analytics-modal-close-button admin-search-close-button" style="
        position: absolute;
        top: 16px;
        right: 16px;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        cursor: pointer;
        z-index: 10;
        transition: all 0.2s ease;
        color: #888;
      ">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <div class="analytics-modal-header" style="
        padding: 20px 24px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      ">
        <div class="analytics-modal-title" style="font-size: 18px; font-weight: 700; color: #fff;">🔍 Admin Search</div>
      </div>

      <div class="analytics-modal-content" style="
        padding: 24px;
        overflow-y: auto;
        max-height: 70vh;
      ">
        <div style="margin-bottom: 12px;">
          <p style="margin: 0; font-size: 13px; color: #888;">Search for tracked admins from the spreadsheet</p>
        </div>

        <div class="admin-search-input-wrapper" style="position: relative;">
          <input type="text" id="adminSearchUsername" class="admin-search-input" placeholder="Type to search admins..." style="
            width: 100%;
            padding: 14px 16px;
            padding-left: 44px;
            background: #1a1a1a;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #e0e0e0;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            box-sizing: border-box;
          ">
          <svg style="
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px;
            height: 18px;
            color: #666;
            pointer-events: none;
          " viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </div>

        <div id="adminSearchSuggestions" class="admin-search-suggestions" style="
          margin-top: 8px;
          display: none;
        "></div>

        <div id="adminSearchStatus" class="admin-search-status" style="
          margin-top: 16px;
          padding: 12px 16px;
          border-radius: 10px;
          font-size: 13px;
          text-align: center;
          display: none;
        "></div>
      </div>
    `;

    // Add CSS styles
    const style = document.createElement('style');
    style.textContent = `
      @keyframes analytics-backdrop-fade-in {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes analytics-scale-in {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }
      @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
      }

      .admin-search-input:focus {
        border-color: #22d3ee !important;
        box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.1);
      }

      .admin-search-close-button:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(255, 255, 255, 0.2) !important;
        color: #fff !important;
      }

      .admin-search-suggestions {
        display: block !important;
      }

      .admin-search-suggestion-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        background: #1a1a1a;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        margin-bottom: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .admin-search-suggestion-item:hover {
        background: #252525;
        border-color: rgba(34, 211, 238, 0.3);
        transform: translateX(4px);
      }

      .admin-search-suggestion-item:last-child {
        margin-bottom: 0;
      }

      .admin-search-suggestion-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #2a2a2a;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
        color: #888;
        flex-shrink: 0;
        overflow: hidden;
      }

      .admin-search-suggestion-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .admin-search-suggestion-info {
        flex: 1;
        min-width: 0;
      }

      .admin-search-suggestion-username {
        font-size: 14px;
        font-weight: 600;
        color: #e0e0e0;
      }

      .admin-search-suggestion-last-active {
        font-size: 12px;
        color: #888;
        margin-top: 2px;
      }

      .admin-search-suggestion-score {
        font-size: 13px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 6px;
        flex-shrink: 0;
      }

      .admin-search-suggestion-score.score-excellent {
        background: rgba(16, 185, 129, 0.15);
        color: #10b981;
      }

      .admin-search-suggestion-score.score-good {
        background: rgba(34, 211, 238, 0.15);
        color: #22d3ee;
      }

      .admin-search-suggestion-score.score-fair {
        background: rgba(251, 191, 36, 0.15);
        color: #fbbf24;
      }

      .admin-search-suggestion-score.score-poor {
        background: rgba(239, 68, 68, 0.15);
        color: #ef4444;
      }

      .admin-search-status.show {
        display: block !important;
      }

      .admin-search-status.loading {
        background: rgba(34, 211, 238, 0.1);
        color: #22d3ee;
        border: 1px solid rgba(34, 211, 238, 0.2);
      }

      .admin-search-status.error {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
      }

      .admin-search-suggestions-empty {
        text-align: center;
        padding: 32px 20px;
        color: #666;
        font-size: 14px;
      }
    `;
    document.head.appendChild(style);

    // Add modal to backdrop
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // Get references
    const input = modal.querySelector('#adminSearchUsername');
    const suggestionsEl = modal.querySelector('#adminSearchSuggestions');
    const statusEl = modal.querySelector('#adminSearchStatus');
    const closeBtn = modal.querySelector('.admin-search-close-button');

    // State
    let allAdmins = [];
    let searchTimeout = null;

    // Load admins from spreadsheet
    async function loadAdmins() {
      try {
        if (typeof SheetsData !== 'undefined') {
          const adminsData = await SheetsData.getAllAdmins();
          allAdmins = Object.entries(adminsData).map(([username, data]) => ({
            username,
            ...data
          }));
        }
      } catch (error) {
        console.error('[Admin Search] Failed to load admins:', error);
      }
    }

    // Focus input and load admins
    setTimeout(() => {
      input.focus();
      loadAdmins();
    }, 100);

    // Debounced search function
    function performSearch(query) {
      const trimmedQuery = query.toLowerCase().trim();

      // Clear previous timeout
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }

      if (!trimmedQuery) {
        suggestionsEl.style.display = 'none';
        suggestionsEl.innerHTML = '';
        statusEl.style.display = 'none';
        return;
      }

      // Debounce the search
      searchTimeout = setTimeout(() => {
        // Filter admins by username
        const matches = allAdmins.filter(admin => {
          return admin.username && admin.username.toLowerCase().includes(trimmedQuery);
        });

        // Show first 5 results
        const topMatches = matches.slice(0, 5);

        if (topMatches.length === 0) {
          suggestionsEl.innerHTML = '<div class="admin-search-suggestions-empty">No matching admins found in spreadsheet</div>';
        } else {
          suggestionsEl.innerHTML = topMatches.map(admin => {
            const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating || 0) : { formatted: 'N/A', class: 'score-poor' };
            const initials = (admin.username || '?').substring(0, 2).toUpperCase();

            return `
              <div class="admin-search-suggestion-item" data-username="${escapeHtml(admin.username)}">
                <div class="admin-search-suggestion-avatar">
                  <img src="https://unavatar.io/twitter/${admin.username}" alt="" onerror="this.style.display='none';this.parentNode.innerHTML='${escapeHtml(initials)}'">
                </div>
                <div class="admin-search-suggestion-info">
                  <div class="admin-search-suggestion-username">@${escapeHtml(admin.username)}</div>
                  ${admin.last_active ? `<div class="admin-search-suggestion-last-active">Last active ${escapeHtml(admin.last_active)}</div>` : ''}
                </div>
                <div class="admin-search-suggestion-score ${scoreData.class}">${scoreData.formatted}</div>
              </div>
            `;
          }).join('');

          // Add click handlers to suggestions
          suggestionsEl.querySelectorAll('.admin-search-suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
              const username = item.getAttribute('data-username');
              openAdminModal(username);
            });
          });
        }

        suggestionsEl.style.display = 'block';
      }, 150);
    }

    // Open admin modal
    async function openAdminModal(username) {
      closeModal();

      // Open admin tokens modal
      if (adminTokensModal) {
        await adminTokensModal.show(username);
      }
    }

    // Escape HTML
    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    // Close modal
    function closeModal() {
      if (backdrop.parentNode) {
        backdrop.style.animation = 'fadeOut 0.15s ease';
        setTimeout(() => {
          if (backdrop.parentNode) {
            backdrop.parentNode.removeChild(backdrop);
          }
          if (style.parentNode) {
            style.parentNode.removeChild(style);
          }
        }, 150);
      }
    }

    // Event listeners
    input.addEventListener('input', (e) => performSearch(e.target.value));

    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        const trimmedQuery = input.value.toLowerCase().trim();
        if (trimmedQuery) {
          // Find exact match or first match
          const match = allAdmins.find(admin => admin.username.toLowerCase() === trimmedQuery);
          if (match) {
            openAdminModal(match.username);
          } else {
            const partialMatch = allAdmins.find(admin => admin.username.toLowerCase().includes(trimmedQuery));
            if (partialMatch) {
              openAdminModal(partialMatch.username);
            }
          }
        }
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });

    closeBtn.addEventListener('click', closeModal);

    // Close on backdrop click
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) closeModal();
    });

    // Close on ESC key (global)
    const escHandler = (e) => {
      if (e.key === 'Escape') closeModal();
    };
    document.addEventListener('keydown', escHandler);

    // Cleanup when modal is removed
    backdrop.addEventListener('DOMNodeRemoved', function() {
      document.removeEventListener('keydown', escHandler);
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    });
  }

  // Find token cards on axiom.trade
  function findTokenCards() {
    // Look for elements containing community links
    const communityLinks = document.querySelectorAll('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    const cards = [];

    communityLinks.forEach((link) => {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) return;

      // Skip X community popup/preview cards (fixed positioned elements)
      const fixedPopup = link.closest('.fixed, [class*="z-[9999"], [class*="z-\\[9999\\]"]');
      if (fixedPopup) return;

      // Walk up from the community link to find the card element
      // The card is the .group div that contains all the card content
      let current = link;
      let cardFound = null;

      for (let i = 0; i < 15; i++) {
        // Skip known non-card UI elements during traversal (modals, popovers, etc.)
        // Only stop if we hit a parent with these classes within first few levels
        if (i < 3 && current.classList &&
            (current.classList.contains('padre-no-scroll') ||
             current.classList.contains('css-xek4ag') ||
             current.classList.contains('MuiModal-root') ||
             current.classList.contains('MuiBackdrop-root') ||
             current.getAttribute('tabindex') === '-1')) {
          break;
        }

        // Check if current element looks like the card (has 'group' class and the structure)
        if (current.classList && current.classList.contains('group')) {
          // Verify it has the card structure (should have a relative parent or specific classes)
          const hasCardStructure = current.querySelector('.flex.flex-col') ||
                                  current.querySelector('[class*="h-"]');
          if (hasCardStructure) {
            // Additional check: skip if inside a modal
            if (current.closest('.MuiModal-root')) break;

            cardFound = current;
            break;
          }
        }
        const parent = current.parentElement;
        if (!parent) break;
        current = parent;
      }

      if (cardFound && !cards.includes(cardFound)) {
        cards.push(cardFound);
      }
    });

    return cards;
  }

  // Get X community link from a card
  function getXCommunityLink(card) {
    const link = card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    return link ? link.href : null;
  }

  // Detect platform type
  function detectPlatform(card) {
    const xLink = card.querySelector('a[href*="x.com/i/communities"]');
    if (xLink) return 'x-community';

    const twitterLink = card.querySelector('a[href*="twitter.com/i/communities"]');
    if (twitterLink) return 'twitter';

    return 'x-community'; // Default
  }

  // Create admin display element (full padre feature parity, centered in card)
  async function createAdminDisplay(admin, settings, verificationBadge = null) {
    const container = document.createElement('div');
    container.className = 'admin-display honed-admin-info x-community-admin-info no-hover-effect';
    // Position on the left side, vertically centered
    container.style.cssText = `
      position: absolute !important;
      top: calc(50% + 3px) !important;
      left: 91px !important;
      transform: translateY(-50%) !important;
      z-index: 50 !important;
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      gap: 4px !important;
    `;

    // Admin avatar
    const avatar = document.createElement('img');
    const fallbackIcon = chrome.runtime?.getURL?.('icons/icon48.png') || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="10"/></svg>';
    avatar.src = admin.profile_image_url_https || fallbackIcon;
    avatar.alt = admin.screen_name || 'Admin';
    avatar.className = 'admin-avatar';
    avatar.style.cssText = 'width: 18px !important; height: 18px !important; border-radius: 50% !important; flex-shrink: 0 !important; position: relative !important;';
    avatar.onerror = () => {
      avatar.src = fallbackIcon;
    };

    // Admin info container
    const infoContainer = document.createElement('div');
    infoContainer.className = 'admin-username-container';
    infoContainer.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important;';

    // Username label
    const usernameLabel = document.createElement('span');
    usernameLabel.className = 'admin-username';
    usernameLabel.textContent = '@' + (admin.screen_name || 'unknown');
    usernameLabel.style.cssText = 'font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important; cursor: pointer !important;';

    // Add hover event listeners for profile tooltip
    usernameLabel.addEventListener('mouseenter', (e) => {
      profileTooltip.show(e.target, admin.screen_name || 'unknown');
    });

    usernameLabel.addEventListener('mousemove', (e) => {
      profileTooltip.updatePosition(e.clientX, e.clientY);
    });

    usernameLabel.addEventListener('mouseleave', () => {
      profileTooltip.hide();
    });

    // Add click event listener to open modal
    usernameLabel.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const username = admin.screen_name || 'unknown';
      if (adminTokensModal) {
        adminTokensModal.show(username);
      }
    });

    infoContainer.appendChild(usernameLabel);

    // Follower count (if enabled and available)
    if (settings.showFollowerCount && admin.followers_count) {
      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' • ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const followerCount = document.createElement('span');
      followerCount.className = 'admin-follower-count';
      followerCount.textContent = formatNumber(admin.followers_count);
      followerCount.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      infoContainer.appendChild(separator);
      infoContainer.appendChild(followerCount);
    }

    // Sheet score (if enabled) - ALWAYS create element, will be updated by hot reload
    if (settings.showSheetScores && typeof SheetsData !== 'undefined') {
      const adminUsername = admin.screen_name || admin.userName;
      if (!adminUsername) {
        console.warn('[Axiom] Admin has no username:', admin);
        return container;
      }
      const stats = await SheetsData.getAdminStats(adminUsername);

      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' - ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const scoreSpan = document.createElement('span');
      scoreSpan.className = `admin-sheet-score`;
      scoreSpan.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');

      // Set initial state based on available data
      if (stats && stats.total_rating >= 0) {
        const scoreData = SheetsData.formatScore(stats.total_rating);
        scoreSpan.className = `admin-sheet-score ${scoreData.class}`;
        scoreSpan.textContent = scoreData.formatted;
        scoreSpan.style.cssText = `font-size: 12px !important; color: ${scoreData.color} !important; font-weight: 600 !important;`;
      } else {
        // Show loading state - will be updated by hot reload when data arrives
        scoreSpan.textContent = '...';
        scoreSpan.style.cssText = 'font-size: 12px !important; color: #64748b !important; font-weight: 400 !important;';
      }

      infoContainer.appendChild(separator);
      infoContainer.appendChild(scoreSpan);
    }

    container.appendChild(avatar);
    container.appendChild(infoContainer);

    // Add verification badge if available
    if (verificationBadge && settings.communityVerificationEnabled) {
      const verificationBadgeContainer = document.createElement('div');
      verificationBadgeContainer.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; padding: 2px !important;';
      verificationBadgeContainer.appendChild(verificationBadge);
      container.appendChild(verificationBadgeContainer);
    }

    // Add track and blacklist buttons (if enabled)
    if (settings.showTrackBlacklistButtons) {
      // Track button
      const trackBtn = document.createElement('button');
      trackBtn.className = 'admin-track-btn';
      trackBtn.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');
      trackBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      // Check if admin is tracked
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        const tracked = result.trackedAdmins || [];
        const existing = tracked.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === (admin.screen_name || '').toLowerCase();
        });

        const updateTrackButtonState = (isTracked) => {
          if (isTracked) {
            trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>`;
            trackBtn.title = `Untrack @${admin.screen_name}`;
            trackBtn.style.color = '#fbbf24';
          } else {
            trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>`;
            trackBtn.title = `Track @${admin.screen_name}`;
            trackBtn.style.color = '#22d3ee';
          }
        };

        updateTrackButtonState(!!existing);

        // Handle click
        trackBtn.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();

          const username = admin.screen_name;
          if (!username) return;

          // Check if already tracked
          const result = await chrome.storage.local.get(['trackedAdmins']);
          const tracked = result.trackedAdmins || [];
          const existingIndex = tracked.findIndex(a => {
            const adminUsername = a.username || a.userName || a.screen_name;
            return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
          });

          if (existingIndex >= 0) {
            // Untrack
            tracked.splice(existingIndex, 1);
            await chrome.storage.local.set({ trackedAdmins: tracked });
            updateCachedTrackedAdmins(tracked);
            updateTrackButtonState(false);
          } else {
            // Track - fetch full profile
            try {
              const response = await chrome.runtime.sendMessage({
                action: 'fetchUserProfile',
                username: username
              });

              if (response && response.success) {
                const userData = response.data?.data || response.data;
                if (userData && (userData.userName || userData.screen_name)) {
                  const newAdmin = {
                    username: userData.userName || userData.screen_name,
                    profileImage: userData.profilePicture || userData.profile_image_url_https,
                    followersCount: userData.followers || userData.followers_count,
                    name: userData.name,
                    banner: userData.coverPicture || userData.profile_banner_url,
                    description: userData.description,
                    addedAt: Date.now()
                  };
                  tracked.push(newAdmin);
                  await chrome.storage.local.set({ trackedAdmins: tracked });
                  updateCachedTrackedAdmins(tracked);
                  updateTrackButtonState(true);
                }
              }
            } catch (error) {
              console.error('[Axiom] Error fetching profile:', error);
            }
          }
        });

        // Hover effects
        trackBtn.addEventListener('mouseenter', () => {
          trackBtn.style.opacity = '1';
        });
        trackBtn.addEventListener('mouseleave', () => {
          trackBtn.style.opacity = '0.6';
        });
      });

      container.appendChild(trackBtn);

      // Blacklist button
      const blacklistBtn = document.createElement('button');
      blacklistBtn.className = 'admin-blacklist-btn';
      blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>`;
      blacklistBtn.title = `Blacklist @${admin.screen_name}`;
      blacklistBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; color: #f43f5e !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      blacklistBtn.addEventListener('mouseenter', () => {
        blacklistBtn.style.opacity = '1';
      });
      blacklistBtn.addEventListener('mouseleave', () => {
        blacklistBtn.style.opacity = '0.6';
      });

      blacklistBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const username = admin.screen_name;
        if (!username) return;

        // Check if already blacklisted
        const result = await chrome.storage.local.get(['blacklistedAdmins']);
        const blacklist = result.blacklistedAdmins || [];
        const existing = blacklist.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
        });

        if (existing) {
          blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>`;
          blacklistBtn.title = `@${username} is blacklisted`;
          blacklistBtn.style.color = '#10b981';
          return;
        }

        // Fetch profile and add to blacklist
        try {
          const response = await chrome.runtime.sendMessage({
            action: 'fetchUserProfile',
            username: username
          });

          if (response && response.success) {
            const userData = response.data?.data || response.data;
            if (userData && (userData.userName || userData.screen_name)) {
              const newAdmin = {
                username: userData.userName || userData.screen_name,
                profileImage: userData.profilePicture || userData.profile_image_url_https,
                followersCount: userData.followers || userData.followers_count,
                name: userData.name,
                banner: userData.coverPicture || userData.profile_banner_url,
                description: userData.description,
                addedAt: Date.now()
              };
              blacklist.push(newAdmin);
              await chrome.storage.local.set({ blacklistedAdmins: blacklist });
              updateCachedBlacklistedAdmins(blacklist);

              blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>`;
              blacklistBtn.title = `@${username} is blacklisted`;
              blacklistBtn.style.color = '#10b981';
            }
          }
        } catch (error) {
          console.error('[Axiom] Error fetching profile:', error);
        }
      });

      container.appendChild(blacklistBtn);
    }

    return container;
  }

  // Create admin info element (wrapper for consistency)
  async function createAdminInfoElement(adminData, settings) {
    return await createAdminDisplay(adminData, settings, null);
  }

  // Create verification badge (green check or red X)
  function createVerificationBadge(verificationResult) {
    if (!verificationResult) {
      return null;
    }

    const badge = document.createElement('div');
    badge.className = 'verification-badge';

    // Show green check if verified
    if (verificationResult.isVerified === true) {
      badge.className += ' verified-green';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>`;
      badge.title = 'Verified - First token with this community';
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #10b981 !important; flex-shrink: 0 !important;';
    } else if (verificationResult.isVerified === false) {
      badge.className += ' verified-red';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>`;
      const ownerName = verificationResult.firstTokenAdmin || verificationResult.realOwner || 'unknown';
      badge.title = `Not the first token with this community (first was by @${ownerName})`;
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #ef4444 !important; flex-shrink: 0 !important;';
    } else {
      return null;
    }

    return badge;
  }

  // Register community and check ownership
  async function registerAndVerifyCommunity(communityId, adminUsername) {
    // Check cache first - if we've already verified this community, return cached result
    // This prevents showing X on re-renders of the same card
    const cacheKey = communityId;
    if (communityVerificationCache.has(cacheKey)) {
      console.log(`[Axiom] Using cached verification result for community ${communityId}`);
      return communityVerificationCache.get(cacheKey);
    }

    return new Promise((resolve) => {
      safeChromeAPI(() => {
        // Get current tab ID for per-tab tracking
        chrome.runtime.sendMessage({ action: 'getTabId' }, (tabResponse) => {
          const tabId = tabResponse?.tabId || 0;
          
          chrome.runtime.sendMessage({
            action: 'registerCommunityOwner',
            communityId: communityId,
            adminUsername: adminUsername,
            tabId: tabId
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('[Axiom] Error registering community:', chrome.runtime.lastError);
              const result = { isFirstOwner: true, isVerified: true };
              communityVerificationCache.set(cacheKey, result);
              resolve(result);
              return;
            }

            if (response && response.success) {
              // Cache the result for this community
              communityVerificationCache.set(cacheKey, response.data);
              resolve(response.data);
            } else {
              console.error('[Axiom] Failed to register community:', response?.error);
              const result = { isFirstOwner: true, isVerified: true };
              communityVerificationCache.set(cacheKey, result);
              resolve(result);
            }
          });
        });
      }, () => {
        const result = { isFirstOwner: true, isVerified: true };
        communityVerificationCache.set(cacheKey, result);
        resolve(result);
      });
    });
  }

  // Check if admin is tracked
  function isTrackedAdmin(username) {
    if (!username) return false;
    return trackedUsernamesSet.has(username.toLowerCase());
  }

  // Check if admin is blacklisted
  function isBlacklistedAdmin(username) {
    if (!username) return false;
    return blacklistedUsernamesSet.has(username.toLowerCase());
  }

  // Apply overlay to card (from guide pattern)
  async function addOverlay(card) {
    // Check if X community detection is enabled
    if (!cachedSettings.xCommunityEnabled) {
      return;
    }

    const communityLink = getXCommunityLink(card);
    if (!communityLink) {
      return;
    }

    const cardId = communityLink;

    // Temporary lock to prevent concurrent processing (like padre)
    if (processedCards.has(cardId)) {
      return;
    }
    processedCards.add(cardId);

    const platformType = detectPlatform(card);

    // Set card to relative for absolute positioning of overlay
    card.style.position = 'relative';

    // Add hexToRgba function if not exists
    const hexToRgba = (hex, alpha) => {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };

    let adminData = null;
    let isAdmin = false;
    let isBlacklisted = false;
    let verificationResult = null;

    try {
      const communityId = extractCommunityId(communityLink);
      if (communityId) {
        const communityInfo = await fetchCommunityInfo(communityId);
        if (communityInfo && communityInfo.community_info) {
          adminData = communityInfo.community_info.creator || communityInfo.community_info.admin;

          if (adminData && adminData.screen_name) {
            isAdmin = isTrackedAdmin(adminData.screen_name);
            isBlacklisted = isBlacklistedAdmin(adminData.screen_name);

            // Register and verify community ownership using unique community ID
            if (cachedSettings.communityVerificationEnabled) {
              verificationResult = await registerAndVerifyCommunity(
                communityId,
                adminData.screen_name
              );
            }
          }
        }
      }
    } catch (error) {
      console.error('[Axiom] Error fetching community info:', error.message);
      // Continue anyway - we'll still show the overlay
    }

    try {
      // Create verification badge if available
      let verificationBadge = null;
      if (verificationResult) {
        verificationBadge = createVerificationBadge(verificationResult);
      }

      // Add background styling
      // Add background styling - always enabled
      const opacity = (cachedSettings.trackedGradientOpacity || 20) / 100 * 0.5;
      const normalColorHex = cachedSettings.normalAdminColor || '#1a1a2e';
      const normalColor = hexToRgba(normalColorHex, opacity);

      // For tracked admins, use the tracked gradient color
      let backgroundColor = normalColor;
      if (isAdmin && !isBlacklisted) {
        const trackedColorHex = cachedSettings.trackedGradientColor || '#22d3ee';
        backgroundColor = hexToRgba(trackedColorHex, opacity);
      }

      // Apply background
      card.style.setProperty('background', `linear-gradient(to left, ${backgroundColor} 0%, transparent 50%)`, 'important');
      card.style.setProperty('border-radius', `12px`, 'important');

      // Add border for tracked admins (ONLY difference)
      if (isAdmin && !isBlacklisted) {
        card.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor || '#22d3ee'}`, 'important');

        // CRITICAL FIX: Also apply border to any wrapper elements that have the gradient background
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor || '#22d3ee'}`, 'important');
          }
        });

        // Play tracked admin alert sound (only once per unique token, persists across page navigations)
        if (typeof window.AdminAlertAudio !== 'undefined') {
          const adminUsername = adminData.screen_name.toLowerCase();
          const tokenAlertId = `${adminUsername}-${cardId}`;
          if (!hasPlayedAlert(tokenAlertId)) {
            markAlertPlayed(tokenAlertId);
            window.AdminAlertAudio.playAdminAlert();
          }
        }
      } else {
        card.style.setProperty('border', 'none', 'important');

        // Also remove border from wrapper elements
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', 'none', 'important');
          }
        });
      }

      // Add blacklist overlay if admin is blacklisted (overrides everything)
      if (isBlacklisted) {
        applyBlacklistOverlay(card, adminData?.screen_name || 'unknown');
      }

      // Create and append admin info to card (with verification badge)
      // CRITICAL FIX: Ensure admin display is ALWAYS created, even if adminData is null
      // This fixes the issue where tracked admin usernames don't show on axiom.trade
      if (cachedSettings.showAdminInfo) {
        let adminInfoElement;

        if (adminData) {
          // We have admin data from the API - use it
          adminInfoElement = await createAdminDisplay(adminData, cachedSettings, verificationBadge);
        } else {
          // API failed or adminData is null - create fallback with minimal info
          // Try to find username from existing community indicator (from content.js)
          const existingIndicator = card.querySelector('.admin-username');
          const fallbackUsername = existingIndicator?.textContent?.replace('@', '') || 'Admin';

          // Create minimal admin display object
          const fallbackAdminData = {
            screen_name: fallbackUsername.replace('@', ''),
            profile_image_url_https: null,
            followers_count: null
          };

          adminInfoElement = await createAdminDisplay(fallbackAdminData, cachedSettings, verificationBadge);
        }

        card.appendChild(adminInfoElement);
      } else {
        const fallbackElement = createFallbackIndicator(communityLink, adminData);
        card.appendChild(fallbackElement);
      }
    } finally {
      // Remove from processing set (like padre - allows reprocessing)
      processedCards.delete(cardId);
    }
  }

  // Create fallback indicator when API fails (matching padre style, centered)
  function createFallbackIndicator(communityLink, adminData = null) {
    const container = document.createElement('div');
    container.className = 'admin-display honed-admin-info x-community-admin-info no-hover-effect';
    // Center in card (offset down 1px, left 15px)
    container.style.cssText = `
      position: absolute !important;
      top: calc(50% + 1px) !important;
      left: calc(50% - 15px) !important;
      transform: translate(-50%, -50%) !important;
      z-index: 50 !important;
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      gap: 4px !important;
    `;

    // If we have admin data but showAdminInfo is off, still show the username
    if (adminData && adminData.screen_name) {
      const screenName = adminData.screen_name || adminData.userName || adminData.name || 'Unknown';
      const displayName = screenName.startsWith('@') ? screenName : `@${screenName}`;

      const usernameLabel = document.createElement('span');
      usernameLabel.className = 'admin-username';
      usernameLabel.textContent = displayName;
      usernameLabel.style.cssText = 'font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important;';

      container.appendChild(usernameLabel);
    } else {
      // Show "Community" badge when we can't fetch admin info
      const label = document.createElement('span');
      label.className = 'admin-username';
      label.textContent = 'Community';
      label.style.cssText = 'font-size: 12px !important; color: #5DBCFF !important; font-weight: 500 !important;';

      container.appendChild(label);
    }

    return container;
  }

  // Apply blacklist overlay with blur and reveal button
  function applyBlacklistOverlay(card, username) {
    // Skip known non-card UI elements
    if (card.classList.contains('padre-no-scroll') ||
        card.classList.contains('css-xek4ag')) {
      return;
    }

    // Mark card as blacklisted
    card.classList.add('blacklisted-token');

    // Check if overlay already exists
    if (card.querySelector('.blacklist-overlay')) {
      return;
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'blacklist-overlay';
    overlay.setAttribute('data-blacklist-username', username);

    // Create reveal button
    const revealBtn = document.createElement('button');
    revealBtn.className = 'blacklist-reveal-btn';
    revealBtn.textContent = 'Show';
    revealBtn.title = 'This token is from a blacklisted admin';

    revealBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.classList.add('revealed');
    });

    overlay.appendChild(revealBtn);
    card.appendChild(overlay);
  }

  // Process all token cards
  async function processTokenCards() {
    // Skip processing if X community detection is disabled
    if (!cachedSettings.xCommunityEnabled) {
      return;
    }

    const tokenCards = findTokenCards();
    // Process cards sequentially to avoid race conditions with community verification
    for (const card of tokenCards) {
      await addOverlay(card);
    }
  }

  // Hot reload for settings changes
  function setupHotReload() {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        const startTime = performance.now();

        // Handle background color/opacity changes - update instantly (exactly like padre)
        if (changes.trackedGradientOpacity || changes.normalAdminColor) {
          const updateStart = performance.now();

          const opacity = ((changes.trackedGradientOpacity?.newValue || cachedSettings.trackedGradientOpacity || 20) / 100 * 0.5);
          const normalColorHex = changes.normalAdminColor?.newValue || cachedSettings.normalAdminColor || '#1a1a2e';

          // hexToRgba function
          const hexToRgba = (hex, alpha) => {
            const r = parseInt(hex.slice(1, 3), 16);
            const g = parseInt(hex.slice(3, 5), 16);
            const b = parseInt(hex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
          };

          const normalColor = hexToRgba(normalColorHex, opacity);

          // Update all cards that have been processed (have position relative and background)
          const updatedCards = new Set();

          // First, update cards with admin info
          document.querySelectorAll('.honed-admin-info').forEach(adminInfo => {
            const card = adminInfo.closest('.group');
            if (card) {
              card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
              card.style.setProperty('border-radius', `12px`, 'important');
              updatedCards.add(card);
            }
          });

          // Also update any .group cards that already have the gradient background (in case admin info is disabled)
          document.querySelectorAll('.group').forEach(card => {
            if (updatedCards.has(card)) return; // Skip already updated

            const currentBg = card.style.getPropertyValue('background');
            if (currentBg && currentBg.includes('linear-gradient')) {
              card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
              card.style.setProperty('border-radius', `12px`, 'important');
              updatedCards.add(card);
            }
          });

          // Update cached settings
          if (changes.trackedGradientOpacity) {
            cachedSettings.trackedGradientOpacity = changes.trackedGradientOpacity.newValue;
          }
          if (changes.normalAdminColor) {
            cachedSettings.normalAdminColor = changes.normalAdminColor.newValue;
          }

          const updateTime = performance.now() - updateStart;
        }

        // Handle tracked border color changes
        if (changes.trackedBorderColor) {
          const trackedBorderColor = changes.trackedBorderColor.newValue || '#22d3ee';

          document.querySelectorAll('.group').forEach(card => {
            const currentBorder = card.style.getPropertyValue('border');
            // Update cards that have the tracked admin border (solid, not none)
            if (currentBorder && currentBorder.includes('solid') && !currentBorder.includes('none')) {
              card.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
            }

            // CRITICAL FIX: Also update wrapper elements with gradient background
            const wrapperSelector = `div[style*="linear-gradient(to left"]`;
            const wrappers = card.querySelectorAll(wrapperSelector);
            wrappers.forEach(wrapper => {
              const style = wrapper.getAttribute('style') || '';
              if (style.includes('linear-gradient') && style.includes('solid')) {
                wrapper.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
              }
            });
          });

          cachedSettings.trackedBorderColor = changes.trackedBorderColor.newValue;
        }

        // Handle trackedGradientColor changes
        if (changes.trackedGradientColor) {
          cachedSettings.trackedGradientColor = changes.trackedGradientColor.newValue;

          const opacity = (cachedSettings.trackedGradientOpacity || 20) / 100 * 0.5;
          const trackedColorHex = changes.trackedGradientColor.newValue || '#22d3ee';
          const hexToRgba = (hex, alpha) => {
            const r = parseInt(hex.slice(1, 3), 16);
            const g = parseInt(hex.slice(3, 5), 16);
            const b = parseInt(hex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
          };
          const trackedColor = hexToRgba(trackedColorHex, opacity);

          document.querySelectorAll('.group').forEach(card => {
            const adminInfo = card.querySelector('.honed-admin-info');
            if (adminInfo) {
              const usernameEl = adminInfo.querySelector('.admin-username');
              if (usernameEl) {
                const username = usernameEl.textContent.trim();
                const isTracked = cachedTrackedAdmins.has(username);

                if (isTracked) {
                  card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
                }
              }
            }
          });
        }

        // For other settings, update cache and reprocess
        const hasOtherChanges = Object.keys(changes).some(key =>
          ['xCommunityEnabled', 'showAdminInfo', 'showMemberPreview', 'showFollowerCount', 'showTrackBlacklistButtons', 'communityVerificationEnabled'].includes(key)
        );

        if (hasOtherChanges) {
          Object.keys(changes).forEach(key => {
            if (cachedSettings.hasOwnProperty(key)) {
              cachedSettings[key] = changes[key].newValue;
            }
          });

          (async () => {
            // Clear processed cards cache to force reprocessing of all cards
            processedCards.clear();
            // Remove existing indicators first for clean reprocessing
            document.querySelectorAll('.honed-admin-info').forEach(el => el.remove());

            await processTokenCards();
            const totalTime = performance.now() - startTime;
          })();
        } else {
          const totalTime = performance.now() - startTime;
        }
      }
    });

    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        if (changes.trackedAdmins) {
          updateCachedTrackedAdmins(changes.trackedAdmins.newValue || []);
        }
        if (changes.blacklistedAdmins) {
          updateCachedBlacklistedAdmins(changes.blacklistedAdmins.newValue || []);
        }
      }
    });
  }

  // Initialize
  async function init() {
    // License check - verify user has valid license
    if (typeof window.License !== 'undefined') {
      const isLicensed = await window.License.isLicensed();
      if (!isLicensed) {
        return; // Stop initialization - extension won't function
      }
    }

    // Load previously played admin alerts (must complete before processing cards)
    await loadPlayedAlerts();

    // Load initial data
    const [settings, trackedAdmins, blacklistedAdmins] = await Promise.all([
      getSettings(),
      getTrackedAdmins(),
      getBlacklistedAdmins()
    ]);

    Object.assign(cachedSettings, settings);
    updateCachedTrackedAdmins(trackedAdmins);
    updateCachedBlacklistedAdmins(blacklistedAdmins);

    // Setup hot reload
    setupHotReload();

    // Initial processing - no delay, run immediately
    // Use requestAnimationFrame to ensure DOM is ready
    await new Promise(resolve => requestAnimationFrame(() => resolve()));
    await processTokenCards();

    // Inject Analytics and Admin Search buttons into toolbar
    injectAnalyticsButton();
    injectAdminSearchButton();

    // Re-inject buttons when toolbar changes (SPA navigation) - debounced
    let buttonInjectionTimeout = null;
    const buttonInjectionObserver = new MutationObserver(() => {
      if (buttonInjectionTimeout) {
        clearTimeout(buttonInjectionTimeout);
      }
      buttonInjectionTimeout = setTimeout(() => {
        injectAnalyticsButton();
        injectAdminSearchButton();
      }, 500); // Debounce button injection
    });
    buttonInjectionObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // Store reference for cleanup
    window._honedButtonInjectionTimeout = buttonInjectionTimeout;

    // Debounced processing to prevent rapid reprocessing
    let processTimeout = null;
    let isProcessing = false;

    const debouncedProcess = () => {
      if (isProcessing) return;

      if (processTimeout) {
        clearTimeout(processTimeout);
      }

      processTimeout = setTimeout(async () => {
        if (isProcessing) return;

        isProcessing = true;
        try {
          await processTokenCards();
        } finally {
          isProcessing = false;
        }
      }, 250); // Wait 250ms after last mutation before processing
    };

    // Monitor for new cards
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
              // Ignore our own elements
              if (node.classList?.contains('honed-admin-info') ||
                  node.classList?.contains('admin-display') ||
                  node.querySelector?.('.honed-admin-info')) {
                continue;
              }

              if (node.matches('a[href*="x.com/i/communities"]') ||
                  node.matches('a[href*="twitter.com/i/communities"]') ||
                  node.querySelector('a[href*="x.com/i/communities"]') ||
                  node.querySelector('a[href*="twitter.com/i/communities"]')) {
                debouncedProcess();
                break;
              }
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Periodic scan every 200ms (like padre)
    const periodicScanInterval = setInterval(() => {
      if (!isProcessing) {
        debouncedProcess();
      }
    }, 200);

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', () => {
      clearInterval(periodicScanInterval);
      observer.disconnect();
      buttonInjectionObserver.disconnect();
    });

    // Handle page visibility changes (navigation, back button, tab switch)
    document.addEventListener('visibilitychange', async () => {
      if (document.visibilityState === 'visible') {
        await processTokenCards();
      }
    });

    // Also handle URL changes (SPA navigation)
    let lastUrl = location.href;
    const urlObserver = new MutationObserver(() => {
      const currentUrl = location.href;
      if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        // Small delay to let page settle
        setTimeout(() => processTokenCards(), 250);
      }
    });
    urlObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ============================================
  // Message listener for background script triggers
  // Handles webNavigation events from background.js
  // ============================================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'processTokenCards') {
      processTokenCards().then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        console.error('[Axiom] Error processing token cards:', err);
        sendResponse({ success: false, error: err.message });
      });
      return true; // Keep message channel open for async response
    }

    if (request.action === 'sheetsDataUpdated') {
      console.log('[Axiom] Data updated in background, refreshing UI...');

      // Refresh UI with fresh data - wait for cache to reload
      (async () => {
        try {
          // Force refresh cache and wait for fresh data
          if (typeof SheetsData !== 'undefined') {
            console.log('[Axiom] Reloading admin cache with fresh data...');
            await SheetsData.forceRefresh();
            console.log('[Axiom] Cache reloaded, processing token cards...');
          }

          // Refresh token cards with fresh data
          if (typeof AdminDisplayHotReload !== 'undefined') {
            await processTokenCards(); // Re-process cards with fresh data
          }

          console.log('[Axiom] UI refresh complete');
        } catch (err) {
          console.error('[Axiom] Error refreshing UI:', err);
        }
      })();

      // Respond immediately to avoid timeout
      sendResponse({ success: true });
      return true;
    }
  });

  // ============================================
  // CHART PAGE - Admin Header (Like Padre)
  // ============================================
  
  // Chart page state
  let chartPageProcessed = false;
  let chartProcessingInProgress = false;
  let currentChartCommunityLink = null;
  
  function isChartPage() {
    const path = window.location.pathname;
    return path.includes('/meme/') || path.includes('/token/');
  }
  
  function getChartPageCommunityLink() {
    const communityLink = document.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    return communityLink ? communityLink.href : null;
  }
  
  function findChartHeaderContainer() {
    // Find the header container - try multiple selectors for robustness
    // Axiom uses Tailwind classes with square brackets that need escaping
    const selectors = [
      '.relative.flex.max-h-\\[64px\\].min-h-\\[64px\\]',
      '.relative.flex.max-h-\\[64px\\]',
      '.relative.flex.min-h-\\[64px\\]',
      '.border-b.border-primaryStroke'
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    
    // Fallback: find by structure
    const allDivs = document.querySelectorAll('div.relative.flex');
    for (const div of allDivs) {
      const style = window.getComputedStyle(div);
      const height = parseInt(style.height);
      if (height >= 60 && height <= 70 && div.classList.contains('border-b')) {
        return div;
      }
    }
    
    return null;
  }
  
  function createChartHeaderSkeleton() {
    const skeleton = document.createElement('div');
    skeleton.className = 'honed-chart-skeleton';
    skeleton.id = 'honed-chart-skeleton';
    skeleton.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 0 12px;
      animation: pulse 1.5s infinite;
    `;
    skeleton.innerHTML = `
      <div style="width: 28px; height: 28px; border-radius: 50%; background: rgba(255,255,255,0.1);"></div>
      <div style="width: 80px; height: 12px; border-radius: 4px; background: rgba(255,255,255,0.1);"></div>
    `;
    return skeleton;
  }
  
  function createAxiomChartAdminHeader(adminData, stats, settings = {}) {
    const container = document.createElement('div');
    container.className = 'honed-chart-admin-header';
    container.id = 'honed-chart-admin-header';
    container.style.cssText = `
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 0 12px;
      border-left: 1px solid rgba(255,255,255,0.1);
      margin-left: 8px;
      flex-shrink: 0;
    `;
    
    const username = adminData.screen_name || adminData.userName || '';
    const avatarUrl = adminData.profile_image_url_https || adminData.profilePicture || '';
    const scoreData = SheetsData ? SheetsData.formatScore(stats?.total_rating || 0) : { formatted: 'N/A', class: '', color: '#888' };
    
    // Build score items (0-5)
    const scoreItems = [0, 1, 2, 3, 4, 5].map(score => {
      const count = stats?.[`tokens_score_${score}`] || 0;
      const colors = { 0: '#10b981', 1: '#22d3ee', 2: '#60a5fa', 3: '#fbbf24', 4: '#fb923c', 5: '#ef4444' };
      const clickable = count > 0 ? 'cursor: pointer;' : '';
      return `
        <div class="chart-score-item" data-score="${score}" style="
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 2px 5px;
          background: rgba(255,255,255,0.05);
          border-radius: 4px;
          min-width: 24px;
          ${clickable}
        ">
          <span style="font-size: 10px; color: ${colors[score]}; font-weight: 600;">${score}</span>
          <span style="font-size: 11px; color: #888;">${count}</span>
        </div>
      `;
    }).join('');
    
    // Failed count
    const failedCount = stats?.tokens_score_6 || 0;
    const failedItem = `
      <div class="chart-score-item" data-score="F" style="
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 2px 5px;
        background: rgba(255,255,255,0.05);
        border-radius: 4px;
        min-width: 24px;
      ">
        <span style="font-size: 10px; color: #6b7280; font-weight: 600;">F</span>
        <span style="font-size: 11px; color: #888;">${failedCount}</span>
      </div>
    `;
    
    // Quick Stats button - default to true if setting not defined
    const showQuickStats = settings?.showQuickStatsPopup !== false;
    const quickStatsBtn = showQuickStats ? `
      <button class="honed-quick-stats-btn" data-username="${username}" style="
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 6px;
        padding: 4px 8px;
        cursor: pointer;
        color: #888;
        font-size: 11px;
        display: flex;
        align-items: center;
        gap: 4px;
      ">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <path d="M3 9h18"/>
          <path d="M9 21V9"/>
        </svg>
        Stats
      </button>
    ` : '';
    
    container.innerHTML = `
      <div class="honed-admin-profile" style="display: flex; align-items: center; gap: 8px;">
        <img src="${avatarUrl}" alt="@${username}" style="
          width: 28px;
          height: 28px;
          border-radius: 50%;
          object-fit: cover;
        " onerror="this.style.display='none'">
        <div style="display: flex; flex-direction: column;">
          <span class="honed-admin-username" style="
            font-size: 12px;
            font-weight: 500;
            color: #e2e8f0;
            cursor: pointer;
          ">@${username}</span>
          <span style="font-size: 10px; color: ${scoreData.color};">Rating: ${scoreData.formatted}</span>
        </div>
      </div>
      <div style="display: flex; gap: 3px;">${scoreItems}${failedItem}</div>
      ${quickStatsBtn}
    `;
    
    // Add click handler for username
    const usernameEl = container.querySelector('.honed-admin-username');
    if (usernameEl && typeof adminTokensModal !== 'undefined') {
      usernameEl.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        adminTokensModal.show(username);
      });
    }
    
    // Add click handlers for score items
    const clickableItems = container.querySelectorAll('.chart-score-item[data-score]');
    clickableItems.forEach(item => {
      const score = item.getAttribute('data-score');
      const count = parseInt(item.querySelector('span:last-child').textContent);
      if (count > 0 && typeof ScoreFilteredTokensModal !== 'undefined') {
        item.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          try {
            if (!window.scoreFilteredTokensModal) {
              window.scoreFilteredTokensModal = new ScoreFilteredTokensModal();
            }
            window.scoreFilteredTokensModal.show(username, score);
          } catch (err) {
            console.error('[Axiom Chart] Error opening score modal:', err);
          }
        });
      }
    });
    
    // Add Quick Stats button handler
    const statsBtn = container.querySelector('.honed-quick-stats-btn');
    if (statsBtn && typeof QuickStatsPopup !== 'undefined') {
      statsBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        try {
          if (!window.quickStatsPopup) {
            window.quickStatsPopup = new QuickStatsPopup();
          }
          if (window.quickStatsPopup.isOpen && window.quickStatsPopup.currentUsername === username) {
            window.quickStatsPopup.hide();
            statsBtn.classList.remove('active');
          } else {
            window.quickStatsPopup.show(username, cachedSettings);
            statsBtn.classList.add('active');
          }
        } catch (err) {
          console.error('[Axiom Chart] Error toggling quick stats:', err);
        }
      });
    }
    
    return container;
  }
  
  async function processChartPage() {
    console.log('[Axiom Chart] processChartPage called');
    if (chartProcessingInProgress) {
      console.log('[Axiom Chart] Already processing, skipping');
      return;
    }
    if (!isChartPage()) {
      console.log('[Axiom Chart] Not a chart page');
      return;
    }
    
    const communityLink = getChartPageCommunityLink();
    console.log('[Axiom Chart] Community link:', communityLink);
    if (!communityLink) {
      console.log('[Axiom Chart] No community link found');
      return;
    }
    
    // Check if we're on a different chart
    const onDifferentChart = currentChartCommunityLink && currentChartCommunityLink !== communityLink;
    
    if (onDifferentChart) {
      // Clean up old header when navigating to DIFFERENT token
      const existing = document.getElementById('honed-chart-admin-header');
      const skeleton = document.getElementById('honed-chart-skeleton');
      if (existing) existing.remove();
      if (skeleton) skeleton.remove();
      if (window.quickStatsPopup) window.quickStatsPopup.hide();
      chartPageProcessed = false;
      currentChartCommunityLink = null;
    }
    
    // Skip if already processed for this chart and header still exists
    if (chartPageProcessed && document.getElementById('honed-chart-admin-header')) {
      return;
    }
    
    // Don't re-render if Quick Stats popup is open (prevents closing popup accidentally)
    if (window.quickStatsPopup?.isOpen) {
      return;
    }
    
    const headerContainer = findChartHeaderContainer();
    console.log('[Axiom Chart] Header container found:', !!headerContainer);
    if (!headerContainer) {
      console.log('[Axiom Chart] No header container found');
      return;
    }
    
    // Check if already exists
    if (headerContainer.querySelector('#honed-chart-admin-header')) return;
    
    chartProcessingInProgress = true;
    
    // Show skeleton
    const skeleton = createChartHeaderSkeleton();
    const innerFlex = headerContainer.querySelector('.flex.flex-1.flex-row.items-center.justify-start');
    console.log('[Axiom Chart] Inner flex for skeleton:', !!innerFlex);
    if (innerFlex) {
      innerFlex.appendChild(skeleton);
      console.log('[Axiom Chart] Skeleton added');
    }
    
    try {
      const communityId = extractCommunityId(communityLink);
      if (!communityId) {
        if (skeleton.parentNode) skeleton.remove();
        chartProcessingInProgress = false;
        return;
      }
      
      const communityData = await fetchCommunityInfo(communityId);
      if (!communityData?.community_info) {
        if (skeleton.parentNode) skeleton.remove();
        chartProcessingInProgress = false;
        return;
      }
      
      const admin = communityData.community_info.creator || communityData.community_info.admin;
      if (!admin?.screen_name) {
        if (skeleton.parentNode) skeleton.remove();
        chartProcessingInProgress = false;
        return;
      }
      
      let stats = null;
      if (typeof SheetsData !== 'undefined') {
        stats = await SheetsData.getAdminStats(admin.screen_name);
      }
      
      if (skeleton.parentNode) skeleton.remove();
      
      // Double-check not already added
      if (document.getElementById('honed-chart-admin-header')) {
        chartProcessingInProgress = false;
        return;
      }
      
      const header = createAxiomChartAdminHeader(admin, stats, cachedSettings);
      const targetContainer = findChartHeaderContainer()?.querySelector('.flex.flex-1.flex-row.items-center.justify-start');
      console.log('[Axiom Chart] Target container for injection:', !!targetContainer);
      if (targetContainer) {
        targetContainer.appendChild(header);
        chartPageProcessed = true;
        currentChartCommunityLink = communityLink;
        console.log('[Axiom Chart] Header injected successfully for', admin.screen_name);
      } else {
        console.log('[Axiom Chart] No target container found to inject header');
      }
    } catch (err) {
      console.error('[Axiom] Error processing chart page:', err);
      if (skeleton.parentNode) skeleton.remove();
    } finally {
      chartProcessingInProgress = false;
    }
  }
  
  function resetChartPageState() {
    chartPageProcessed = false;
    chartProcessingInProgress = false;
    currentChartCommunityLink = null;
    const existing = document.getElementById('honed-chart-admin-header');
    const skeleton = document.getElementById('honed-chart-skeleton');
    if (existing) existing.remove();
    if (skeleton) skeleton.remove();
    if (window.quickStatsPopup) window.quickStatsPopup.hide();
  }

  // ============================================
  // SPA Navigation Detection - Override History API
  // Catches client-side routing changes (pushState/replaceState)
  // ============================================
  (function() {
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      // Reset chart state on navigation
      if (isChartPage()) {
        resetChartPageState();
        setTimeout(() => processChartPage(), 300);
      }
      setTimeout(() => processTokenCards(), 100);
    };

    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      if (isChartPage()) {
        resetChartPageState();
        setTimeout(() => processChartPage(), 300);
      }
      setTimeout(() => processTokenCards(), 100);
    };

    // Also listen to popstate (back/forward buttons)
    window.addEventListener('popstate', () => {
      if (isChartPage()) {
        resetChartPageState();
        setTimeout(() => processChartPage(), 300);
      }
      setTimeout(() => processTokenCards(), 100);
    });
  })();
  
  // Initial chart page processing with retry logic (like padre)
  let chartAttempts = 0;
  const maxChartAttempts = 20;
  
  const tryInjectChartHeader = async () => {
    if (!isChartPage()) return;
    
    const hasHeader = document.getElementById('honed-chart-admin-header');
    const hasSkeleton = document.getElementById('honed-chart-skeleton');
    
    if (hasHeader) return; // Already done
    
    if (hasSkeleton && chartAttempts > 3) {
      // Skeleton stuck, reset
      const skeleton = document.getElementById('honed-chart-skeleton');
      if (skeleton) skeleton.remove();
      chartProcessingInProgress = false;
    }
    
    if (hasSkeleton) return; // Wait for current processing
    
    await processChartPage();
    
    chartAttempts++;
    if (chartAttempts < maxChartAttempts) {
      setTimeout(tryInjectChartHeader, 1000);
    }
  };
  
  if (isChartPage()) {
    setTimeout(tryInjectChartHeader, 500);
  }

  // Start
  init();
})();
