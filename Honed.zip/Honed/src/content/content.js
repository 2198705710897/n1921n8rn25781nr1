// Memecoin X Community Detector - Content Script
// Detects token cards with X community links and adds admin information

console.log('[Honed] Content script loading...');

(async function() {
  'use strict';

  console.log('[Honed] Starting license check...');

  // ============================================
  // LICENSE CHECK - Cached validation with 15s interval
  // ============================================
  let licenseCheckInterval = null;
  let isLicenseValid = false;
  let failureCount = 0;
  const CACHE_TTL = 300000; // 5 minutes cache TTL

  // Initial license check (with server)
  isLicenseValid = await checkLicense();
  console.log('[Honed] License check result:', isLicenseValid);
  if (!isLicenseValid) {
    console.log('[Honed] License invalid - content script disabled');
    return; // Stop all execution
  }

  console.log('[Honed] License valid - continuing initialization...');

  // Start periodic license validation (every 15 seconds)
  licenseCheckInterval = setInterval(async () => {
    const valid = await checkLicense();
    if (!valid) {
      failureCount++;
      console.log(`[Honed] License validation failed (${failureCount}/3)`);
      if (failureCount >= 3) {
        console.log('[Honed] License invalidated after 3 failures - reloading page');
        clearInterval(licenseCheckInterval);
        window.location.reload();
      }
    } else {
      failureCount = 0; // Reset on success
    }
  }, 15000); // 15 seconds

  // Cleanup interval on page unload
  window.addEventListener('beforeunload', () => {
    if (licenseCheckInterval) {
      clearInterval(licenseCheckInterval);
    }
  });

  async function checkLicense() {
    // Get license key from storage and device ID from background (ensures fingerprint is generated)
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey', 'lastLicenseCheck', 'cachedLicenseValidity', 'updateRequired'], async (result) => {
        const key = result.licenseKey;

        if (!key) {
          console.log('[Honed] No license key found');
          resolve(false);
          return;
        }

        // Get device ID from background script (ensures fingerprint generation)
        const deviceResult = await chrome.runtime.sendMessage({ action: 'getDeviceId' });
        if (!deviceResult?.success || !deviceResult.deviceId) {
          console.log('[Honed] Failed to get device ID');
          resolve(false);
          return;
        }
        const deviceId = deviceResult.deviceId;

        // Check 5-minute cache first
        const lastCheck = result.lastLicenseCheck || 0;
        const cached = result.cachedLicenseValidity;
        const cacheAge = Date.now() - lastCheck;

        if (cached !== undefined && cacheAge < CACHE_TTL) {
          console.log(`[Honed] Using cached license validity (${Math.round(cacheAge / 1000)}s old)`);
          // Check if update is cached as required
          if (result.updateRequired) {
            showUpdateRequiredBanner();
            resolve(false);
            return;
          }
          resolve(cached);
          return;
        }

        // Cache miss or expired - validate with server
        try {
          console.log('[Honed] Cache miss - validating with server');
          const response = await fetch('https://n1921n8rn25781nr1.vercel.app/api/validate?key=' + encodeURIComponent(key) + '&deviceId=' + encodeURIComponent(deviceId));
          const data = await response.json();

          // Check for required update
          if (data.updateNotification && data.updateNotification.active) {
            console.log('[Honed] ⚠️ Update required - extension disabled');
            // Store update requirement
            chrome.storage.local.set({
              updateRequired: true,
              updateInfo: {
                message: data.updateNotification.message,
                downloadUrl: data.updateNotification.downloadUrl,
                timestamp: Date.now()
              },
              cachedLicenseValidity: false,
              lastLicenseCheck: Date.now()
            });
            showUpdateRequiredBanner(data.updateNotification);
            resolve(false);
            return;
          }

          // Clear any previous update requirement
          chrome.storage.local.remove(['updateRequired', 'updateInfo']);

          // Cache the result
          chrome.storage.local.set({
            cachedLicenseValidity: data.valid,
            lastLicenseCheck: Date.now()
          });

          if (data.valid) {
            console.log('[Honed] Server validation: valid (cached)');
            resolve(true);
          } else {
            console.log('[Honed] Server validation: invalid -', data.reason);
            resolve(false);
          }
        } catch (error) {
          console.error('[Honed] Validation error:', error);
          // On network error, use cached value if available
          if (cached !== undefined) {
            console.log('[Honed] Network error - using stale cached value');
            resolve(cached);
          } else {
            // No cache available - deny access (fail-closed)
            resolve(false);
          }
        }
      });
    });
  }

  // Show in-page update required banner
  function showUpdateRequiredBanner(updateInfo = null) {
    // Check if banner already exists
    if (document.getElementById('honed-update-required-banner')) return;

    const message = updateInfo?.message || 'An update is required to continue using Honed.';
    const downloadUrl = updateInfo?.downloadUrl;

    const banner = document.createElement('div');
    banner.id = 'honed-update-required-banner';
    banner.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      border-bottom: 2px solid #e94560;
      padding: 16px 24px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      box-shadow: 0 4px 20px rgba(233, 69, 96, 0.3);
    `;

    const iconSvg = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#e94560" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
        <path d="M2 17l10 5 10-5"></path>
        <path d="M2 12l10 5 10-5"></path>
      </svg>
    `;

    const contentHtml = `
      <div style="display: flex; align-items: center; gap: 12px;">
        ${iconSvg}
        <div>
          <div style="color: #fff; font-weight: 600; font-size: 14px;">Update Required</div>
          <div style="color: #a0a0a0; font-size: 13px; max-width: 500px;">${message}</div>
        </div>
      </div>
      ${downloadUrl ? `
        <a href="${downloadUrl}" target="_blank" style="
          background: #e94560;
          color: #fff;
          padding: 8px 20px;
          border-radius: 6px;
          text-decoration: none;
          font-weight: 600;
          font-size: 13px;
          white-space: nowrap;
          transition: background 0.2s;
        " onmouseover="this.style.background='#d63850'" onmouseout="this.style.background='#e94560'">
          Download Update
        </a>
      ` : ''}
    `;

    banner.innerHTML = contentHtml;
    document.body.appendChild(banner);

    // Adjust body padding to prevent content from being hidden
    document.body.style.paddingTop = '72px';

    console.log('[Honed] Update required banner shown');
  }

  // Helper to safely call Chrome APIs
  function safeChromeAPI(apiCall, fallback) {
    try {
      return apiCall();
    } catch (e) {
      if (e.message.includes('Extension context invalidated')) {
        // Silently ignore - extension was reloaded
        return fallback;
      }
      throw e;
    }
  }

  // In-memory cache for community data (persists for the session)
  const communityDataCache = new Map();

  // Set-based cache for tracked admin usernames (O(1) lookups)
  let trackedAdminsSet = new Set();

  // ============================================
  // Event Listener Cleanup Manager
  // Prevents memory leaks by tracking and cleaning up event listeners
  // ============================================
  const EventCleanupManager = {
    // Use WeakMap for automatic cleanup when elements are GC'd
    elementHandlers: new WeakMap(),
    // Track all root containers that have been processed
    processedContainers: new WeakSet(),
    // Store cleanup functions for manual disposal
    cleanupFunctions: [],

    // Add event listener with cleanup tracking
    addEventListener(element, event, handler, options = {}) {
      if (!element) return;

      // Get handlers array for this element
      let handlers = this.elementHandlers.get(element);
      if (!handlers) {
        handlers = [];
        this.elementHandlers.set(element, handlers);
      }

      // Store the handler for cleanup
      handlers.push({ event, handler, options });

      // Add the actual listener
      element.addEventListener(event, handler, options);
       },

    // Remove all event listeners from an element
    removeEventListeners(element) {
      const handlers = this.elementHandlers.get(element);
      if (!handlers) return;

      handlers.forEach(({ event, handler, options }) => {
        element.removeEventListener(event, handler, options);
      });

      this.elementHandlers.delete(element);
    },

    // Register a cleanup function to call on disposal
    registerCleanup(fn) {
      this.cleanupFunctions.push(fn);
    },

    // Cleanup all tracked resources
    cleanup() {
      // Run all cleanup functions
      this.cleanupFunctions.forEach(fn => {
        try {
          fn();
        } catch (e) {
          console.error('[EventCleanupManager] Cleanup error:', e);
        }
      });
      this.cleanupFunctions = [];
    }
  };

  // Global MutationObserver for cleanup of removed nodes
  let removalObserver = null;

  // Initialize tracked admins Set from storage
  async function initializeTrackedAdminsSet() {
    return new Promise((resolve) => {
      safeChromeAPI(() => {
        chrome.storage.local.get(['trackedAdmins'], (result) => {
          const admins = result.trackedAdmins || [];
          trackedAdminsSet = new Set(
            admins.map(a => (a.username || a.userName || a.screen_name)?.toLowerCase()).filter(Boolean)
          );
          resolve();
        });
      }, () => resolve());
    });
  }

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      safeChromeAPI(() => {
        chrome.storage.sync.get({
          xCommunityEnabled: true,
          showAdminInfo: true,
          showMemberPreview: true,
          showFollowerCount: true,
          showTrackBlacklistButtons: true,
          trackedGradientOpacity: 20,
          normalAdminColor: '#1a1a2e',
          communityVerificationEnabled: true,
          showSheetScores: true,
          showChartScoreDistro: true
        }, (settings) => {
          resolve(settings);
        });
      }, () => resolve({
        xCommunityEnabled: true,
        showAdminInfo: true,
        showMemberPreview: true,
        showFollowerCount: true,
        showTrackBlacklistButtons: true,
        trackedGradientOpacity: 20,
        normalAdminColor: '#1a1a2e',
        communityVerificationEnabled: true,
        showSheetScores: true,
        showChartScoreDistro: true
      }));
    });
  }

  // Extract community ID from URL (supports both x.com and twitter.com)
  function extractCommunityId(url) {
    const match = url.match(/(?:x\.com|twitter\.com)\/i\/communities\/(\d+)/);
    return match ? match[1] : null;
  }

  // Fetch community information from background worker
  async function fetchCommunityInfo(communityId) {
    // Check in-memory cache first (instant, no message overhead)
    if (communityDataCache.has(communityId)) {
      return communityDataCache.get(communityId);
    }

    // Only send message if not in memory
    const data = await new Promise((resolve, reject) => {
      safeChromeAPI(() => {
        chrome.runtime.sendMessage({
          action: 'fetchCommunityInfo',
          communityId: communityId
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response?.error || 'Failed to fetch community info'));
          }
        });
      }, () => reject(new Error('Extension context invalidated')));
    });

    // Cache in memory for this session
    communityDataCache.set(communityId, data);
    return data;
  }

  // Format follower count
  function formatNumber(count) {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    }
    if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  }

  // ============================================
  // ProfileTooltip - Cursor-following hover tooltip
  // Extends ProfileTooltipCore with sheet stats functionality
  // ============================================
  class ProfileTooltip extends ProfileTooltipCore {
    constructor() {
      super();
    }

    // Fetch profile and populate tooltip
    async _loadAndShow() {
      if (!this.tooltip) {
        this.tooltip = this._createTooltip();
      }

      // Show loading state
      this._setLoading();
      this.tooltip.style.display = 'block';
      this.tooltip.style.pointerEvents = 'auto'; // Ensure it can receive events when shown
      this.isActive = true;

      // Initial position near target element with viewport boundary checking
      const rect = this.targetElement.getBoundingClientRect();
      const offset = 8;
      const tooltipRect = this.tooltip.getBoundingClientRect();

      // Calculate initial position (right of target)
      let left = rect.right + offset;
      let top = rect.top;

      // Prevent right edge overflow - show to the left instead
      if (left + tooltipRect.width > window.innerWidth) {
        left = rect.left - tooltipRect.width - offset;
      }

      // Prevent bottom edge overflow - show above instead
      if (top + tooltipRect.height > window.innerHeight) {
        top = window.innerHeight - tooltipRect.height - offset;
      }

      // Also prevent top overflow
      if (top < offset) {
        top = offset;
      }

      // Prevent left overflow
      if (left < offset) {
        left = offset;
      }

      this.tooltip.style.left = `${left}px`;
      this.tooltip.style.top = `${top}px`;

      // Fetch profile data via background script
      try {
        const data = await this._fetchProfile(this.currentUsername);
        this._populate(data);

        // Re-check boundaries after content loads (dimensions may have changed)
        const newRect = this.tooltip.getBoundingClientRect();
        let newLeft = parseFloat(this.tooltip.style.left);
        let newTop = parseFloat(this.tooltip.style.top);

        if (newLeft + newRect.width > window.innerWidth) {
          newLeft = window.innerWidth - newRect.width - offset;
        }
        if (newLeft < offset) {
          newLeft = offset;
        }
        if (newTop + newRect.height > window.innerHeight) {
          newTop = window.innerHeight - newRect.height - offset;
        }
        if (newTop < offset) {
          newTop = offset;
        }

        this.tooltip.style.left = `${newLeft}px`;
        this.tooltip.style.top = `${newTop}px`;
      } catch (err) {
        console.error('[ProfileTooltip] Failed to fetch profile:', err);
        this._setError();
      }
    }

    // Fetch profile through background script
    async _fetchProfile(username) {
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'fetchUserProfile', username },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (response?.success && response?.data) {
              resolve(response.data);
            } else {
              reject(new Error(response?.error || 'Fetch failed'));
            }
          }
        );
      });
    }

    // Set error state (override core to customize for padre if needed)
    _setError() {
      // Use core implementation
      super._setError();
    }

    // Populate tooltip with data
    async _populate(data) {
      // Use core's populate method for basic profile data
      this._populateData(data);

      // Add sheet stats section - use the original Community API username
      // NOT the profile API username, as they may differ in casing/format
      await this._addSheetStatsSection(this.currentUsername);
    }

    // Add sheet stats section to tooltip
    async _addSheetStatsSection(username) {
      if (typeof SheetsData === 'undefined') return;

      const stats = await SheetsData.getAdminStats(username);
      if (!stats) return;

      const tooltip = this.tooltip;

      // Remove ALL existing stats sections (for when hovering over different admins)
      const existingSections = tooltip.querySelectorAll('.tooltip-sheet-stats');
      existingSections.forEach(section => section.remove());

      const contentArea = tooltip.querySelector('.tooltip-content');
      if (!contentArea) return;

      const scoreData = SheetsData.formatScore(stats.total_rating);

      // Create score section
      const scoreSection = document.createElement('div');
      scoreSection.className = 'tooltip-sheet-stats';

      scoreSection.innerHTML = `
        <div class="sheet-stats-divider"></div>
        <div class="sheet-stats-header">Admin Performance</div>
        <div class="sheet-stats-grid">
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Rating</span>
            <span class="sheet-stat-value ${scoreData.class}" style="color: ${scoreData.color}">
              ${scoreData.formatted}
            </span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Tokens</span>
            <span class="sheet-stat-value">${stats.total_tokens_created || 0}</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Winrate</span>
            <span class="sheet-stat-value">${((stats.winrate || 0) * 100).toFixed(0)}%</span>
          </div>
          <div class="sheet-stat-divider"></div>
          <div class="sheet-stat-item">
            <span class="sheet-stat-label">Failed</span>
            <span class="sheet-stat-value score-poor">${stats.tokens_score_6 || 0}</span>
          </div>
        </div>
        <div class="score-distribution">
          <div class="dist-label">Score Distribution</div>
          <div class="dist-grid">
            ${[0,1,2,3,4,5].map(score => {
              const count = stats[`tokens_score_${score}`] || 0;
              return `
                <div class="dist-cell dist-cell-${score}">
                  <span class="dist-cell-score">${score}</span>
                  <div class="dist-cell-divider"></div>
                  <span class="dist-cell-count">${count}</span>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;

      contentArea.appendChild(scoreSection);
    }

    // Format number for display
    _formatNumber(num) {
      const number = parseInt(num) || 0;
      if (number >= 1000000) {
        return (number / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
      }
      if (number >= 1000) {
        return (number / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
      }
      return number.toString();
    }
  }

  // Create singleton tooltip instance
  const profileTooltip = new ProfileTooltip();

  // Create singleton modal instance
  const adminTokensModal = typeof AdminTokensModal !== 'undefined' ? new AdminTokensModal(profileTooltip) : null;

  // Create singleton analytics modal instance
  const analyticsModal = typeof AnalyticsModal !== 'undefined' ? new AnalyticsModal() : null;



  // Initialize hot reload manager for admin scores
  if (typeof AdminDisplayHotReload !== 'undefined' && typeof SheetsData !== 'undefined') {
    const adminDisplayHotReload = new AdminDisplayHotReload(SheetsData);
    adminDisplayHotReload.start();
  }

  // Inject analytics button into padre.gg toolbar
  function injectAnalyticsButton() {
    // Look for the toolbar by finding the Customize button and walking up to its parent
    const customizeButtons = document.querySelectorAll('button');

    for (const customizeBtn of customizeButtons) {
      // Find the button with "Customize" text
      const textSpan = customizeBtn.querySelector('span');
      if (!textSpan || textSpan.textContent !== 'Customize') continue;

      // Get the toolbar (parent of the Customize button's container)
      const toolbar = customizeBtn.closest('.MuiStack-root');
      if (!toolbar) continue;

      // Check if analytics button already exists
      if (toolbar.querySelector('.analytics-trigger-button')) continue;

      // Copy the base classes from the Customize button to match the site's current styling
      const baseClasses = customizeBtn.className;

      // Create analytics button matching the existing button style
      const analyticsButton = document.createElement('button');
      analyticsButton.className = baseClasses + ' analytics-trigger-button';
      analyticsButton.setAttribute('tabindex', '0');
      analyticsButton.setAttribute('type', 'button');
      analyticsButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
          <path d="M2 5.5C2 4.11929 3.11929 3 4.5 3H11.5C12.8807 3 14 4.11929 14 5.5V10.5C14 11.8807 12.8807 13 11.5 13H4.5C3.11929 13 2 11.8807 2 10.5V5.5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M5 8H11" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M5 5.5H8" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M5 10.5H9" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Analytics</span>
      `;

      // Add click handler to open analytics modal (using EventCleanupManager)
      EventCleanupManager.addEventListener(analyticsButton, 'click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (analyticsModal) {
          analyticsModal.show();
        } else {
          console.error('Analytics modal not available');
        }
      });

      // Insert after the Customize button
      customizeBtn.parentNode.insertBefore(analyticsButton, customizeBtn.nextSibling);

      // Register cleanup for this button
      EventCleanupManager.registerCleanup(() => {
        if (analyticsButton.parentNode) {
          analyticsButton.remove();
        }
      });
    }
  }



  // Inject admin search button into padre.gg toolbar
  function injectAdminSearchButton() {
    // Look for the toolbar by finding the Analytics button
    const analyticsButtons = document.querySelectorAll('.analytics-trigger-button');

    for (const analyticsBtn of analyticsButtons) {
      // Get the toolbar (parent of the Analytics button's container)
      const toolbar = analyticsBtn.closest('.MuiStack-root');
      if (!toolbar) continue;

      // Check if admin search button already exists
      if (toolbar.querySelector('.admin-search-trigger-button')) continue;

      // Copy the base classes from the Analytics button to match styling
      const baseClasses = analyticsBtn.className.replace('analytics-trigger-button', '').trim();

      // Create admin search button matching the existing button style
      const adminSearchButton = document.createElement('button');
      adminSearchButton.className = baseClasses + ' admin-search-trigger-button';
      adminSearchButton.setAttribute('tabindex', '0');
      adminSearchButton.setAttribute('type', 'button');
      adminSearchButton.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
          <circle cx="7" cy="7" r="5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="13" y1="13" x2="10.5" y2="10.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Admin Search</span>
      `;

      // Add click handler to open admin search modal (using EventCleanupManager)
      EventCleanupManager.addEventListener(adminSearchButton, 'click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openAdminSearchModal();
      });

      // Insert after the Analytics button
      analyticsBtn.parentNode.insertBefore(adminSearchButton, analyticsBtn.nextSibling);

      // Register cleanup for this button
      EventCleanupManager.registerCleanup(() => {
        if (adminSearchButton.parentNode) {
          adminSearchButton.remove();
        }
      });
    }
  }

  // Open admin search modal
  function openAdminSearchModal() {
    // Create modal backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'analytics-modal-backdrop admin-search-modal-backdrop';
    backdrop.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.9);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: analytics-backdrop-fade-in 0.15s ease-out;
    `;

    // Create modal container
    const modal = document.createElement('div');
    modal.className = 'analytics-modal-container admin-search-modal-container';
    modal.style.cssText = `
      position: relative;
      width: 500px;
      max-width: 95vw;
      background: #111;
      border-radius: 16px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      overflow: hidden;
      animation: analytics-scale-in 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      flex-direction: column;
    `;

    modal.innerHTML = `
      <button class="analytics-modal-close-button admin-search-close-button" style="
        position: absolute;
        top: 16px;
        right: 16px;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        cursor: pointer;
        z-index: 10;
        transition: all 0.2s ease;
        color: #888;
      ">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <div class="analytics-modal-header" style="
        padding: 20px 24px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      ">
        <div class="analytics-modal-title" style="font-size: 18px; font-weight: 700; color: #fff;">🔍 Admin Search</div>
      </div>

      <div class="analytics-modal-content" style="
        padding: 24px;
        overflow-y: auto;
        max-height: 70vh;
      ">
        <div style="margin-bottom: 12px;">
          <p style="margin: 0; font-size: 13px; color: #888;">Search for tracked admins from the spreadsheet</p>
        </div>

        <div class="admin-search-input-wrapper" style="position: relative;">
          <input type="text" id="adminSearchUsername" class="admin-search-input" placeholder="Type to search admins..." style="
            width: 100%;
            padding: 14px 16px;
            padding-left: 44px;
            background: #1a1a1a;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #e0e0e0;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            box-sizing: border-box;
          ">
          <svg style="
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px;
            height: 18px;
            color: #666;
            pointer-events: none;
          " viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </div>

        <div id="adminSearchSuggestions" class="admin-search-suggestions" style="
          margin-top: 8px;
          display: none;
        "></div>

        <div id="adminSearchStatus" class="admin-search-status" style="
          margin-top: 16px;
          padding: 12px 16px;
          border-radius: 10px;
          font-size: 13px;
          text-align: center;
          display: none;
        "></div>
      </div>
    `;

    // Add CSS styles
    const style = document.createElement('style');
    style.textContent = `
      @keyframes analytics-backdrop-fade-in {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes analytics-scale-in {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }
      @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
      }

      .admin-search-input:focus {
        border-color: #22d3ee !important;
        box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.1);
      }

      .admin-search-close-button:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(255, 255, 255, 0.2) !important;
        color: #fff !important;
      }

      .admin-search-suggestions {
        display: block !important;
      }

      .admin-search-suggestion-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        background: #1a1a1a;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        margin-bottom: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .admin-search-suggestion-item:hover {
        background: #252525;
        border-color: rgba(34, 211, 238, 0.3);
        transform: translateX(4px);
      }

      .admin-search-suggestion-item:last-child {
        margin-bottom: 0;
      }

      .admin-search-suggestion-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #2a2a2a;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
        color: #888;
        flex-shrink: 0;
        overflow: hidden;
      }

      .admin-search-suggestion-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .admin-search-suggestion-info {
        flex: 1;
        min-width: 0;
      }

      .admin-search-suggestion-username {
        font-size: 14px;
        font-weight: 600;
        color: #e0e0e0;
      }

      .admin-search-suggestion-last-active {
        font-size: 12px;
        color: #888;
        margin-top: 2px;
      }

      .admin-search-suggestion-score {
        font-size: 13px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 6px;
        flex-shrink: 0;
      }

      .admin-search-suggestion-score.score-excellent {
        background: rgba(16, 185, 129, 0.15);
        color: #10b981;
      }

      .admin-search-suggestion-score.score-good {
        background: rgba(34, 211, 238, 0.15);
        color: #22d3ee;
      }

      .admin-search-suggestion-score.score-fair {
        background: rgba(251, 191, 36, 0.15);
        color: #fbbf24;
      }

      .admin-search-suggestion-score.score-poor {
        background: rgba(239, 68, 68, 0.15);
        color: #ef4444;
      }

      .admin-search-status.show {
        display: block !important;
      }

      .admin-search-status.loading {
        background: rgba(34, 211, 238, 0.1);
        color: #22d3ee;
        border: 1px solid rgba(34, 211, 238, 0.2);
      }

      .admin-search-status.error {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
      }

      .admin-search-suggestions-empty {
        text-align: center;
        padding: 32px 20px;
        color: #666;
        font-size: 14px;
      }
    `;
    document.head.appendChild(style);

    // Add modal to backdrop
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // Get references
    const input = modal.querySelector('#adminSearchUsername');
    const suggestionsEl = modal.querySelector('#adminSearchSuggestions');
    const statusEl = modal.querySelector('#adminSearchStatus');
    const closeBtn = modal.querySelector('.admin-search-close-button');

    // State
    let allAdmins = [];
    let searchTimeout = null;

    // Load admins from spreadsheet
    async function loadAdmins() {
      try {
        if (typeof SheetsData !== 'undefined') {
          const adminsData = await SheetsData.getAllAdmins();
          allAdmins = Object.entries(adminsData).map(([username, data]) => ({
            username,
            ...data
          }));
        }
      } catch (error) {
        console.error('[Admin Search] Failed to load admins:', error);
      }
    }

    // Focus input and load admins
    setTimeout(() => {
      input.focus();
      loadAdmins();
    }, 100);

    // Debounced search function
    function performSearch(query) {
      const trimmedQuery = query.toLowerCase().trim();

      // Clear previous timeout
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }

      if (!trimmedQuery) {
        suggestionsEl.style.display = 'none';
        suggestionsEl.innerHTML = '';
        statusEl.style.display = 'none';
        return;
      }

      // Debounce the search
      searchTimeout = setTimeout(() => {
        // Filter admins by username
        const matches = allAdmins.filter(admin => {
          return admin.username && admin.username.toLowerCase().includes(trimmedQuery);
        });

        // Show first 5 results
        const topMatches = matches.slice(0, 5);

        if (topMatches.length === 0) {
          suggestionsEl.innerHTML = '<div class="admin-search-suggestions-empty">No matching admins found in spreadsheet</div>';
        } else {
          suggestionsEl.innerHTML = topMatches.map(admin => {
            const scoreData = SheetsData ? SheetsData.formatScore(admin.total_rating || 0) : { formatted: 'N/A', class: 'score-poor' };
            const initials = (admin.username || '?').substring(0, 2).toUpperCase();

            return `
              <div class="admin-search-suggestion-item" data-username="${escapeHtml(admin.username)}">
                <div class="admin-search-suggestion-avatar">
                  <img src="https://unavatar.io/twitter/${admin.username}" alt="" onerror="this.style.display='none';this.parentNode.innerHTML='${escapeHtml(initials)}'">
                </div>
                <div class="admin-search-suggestion-info">
                  <div class="admin-search-suggestion-username">@${escapeHtml(admin.username)}</div>
                  ${admin.last_active ? `<div class="admin-search-suggestion-last-active">Last active ${escapeHtml(admin.last_active)}</div>` : ''}
                </div>
                <div class="admin-search-suggestion-score ${scoreData.class}">${scoreData.formatted}</div>
              </div>
            `;
          }).join('');

          // Add click handlers to suggestions
          suggestionsEl.querySelectorAll('.admin-search-suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
              const username = item.getAttribute('data-username');
              openAdminModal(username);
            });
          });
        }

        suggestionsEl.style.display = 'block';
      }, 150);
    }

    // Open admin modal
    async function openAdminModal(username) {
      closeModal();

      // Open admin tokens modal
      if (adminTokensModal) {
        await adminTokensModal.show(username);
      }
    }

    // Escape HTML
    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    // Close modal
    function closeModal() {
      if (backdrop.parentNode) {
        backdrop.style.animation = 'fadeOut 0.15s ease';
        setTimeout(() => {
          if (backdrop.parentNode) {
            backdrop.parentNode.removeChild(backdrop);
          }
          if (style.parentNode) {
            style.parentNode.removeChild(style);
          }
        }, 150);
      }
    }

    // Event listeners (using EventCleanupManager)
    EventCleanupManager.addEventListener(input, 'input', (e) => performSearch(e.target.value));

    EventCleanupManager.addEventListener(input, 'keypress', (e) => {
      if (e.key === 'Enter') {
        const trimmedQuery = input.value.toLowerCase().trim();
        if (trimmedQuery) {
          // Find exact match or first match
          const match = allAdmins.find(admin => admin.username.toLowerCase() === trimmedQuery);
          if (match) {
            openAdminModal(match.username);
          } else {
            const partialMatch = allAdmins.find(admin => admin.username.toLowerCase().includes(trimmedQuery));
            if (partialMatch) {
              openAdminModal(partialMatch.username);
            }
          }
        }
      }
    });

    EventCleanupManager.addEventListener(input, 'keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });

    EventCleanupManager.addEventListener(closeBtn, 'click', closeModal);

    // Close on backdrop click
    EventCleanupManager.addEventListener(backdrop, 'click', (e) => {
      if (e.target === backdrop) closeModal();
    });

    // Close on ESC key (global)
    const escHandler = (e) => {
      if (e.key === 'Escape') closeModal();
    };
    document.addEventListener('keydown', escHandler);

    // Cleanup when modal is removed
    EventCleanupManager.addEventListener(backdrop, 'DOMNodeRemoved', function() {
      document.removeEventListener('keydown', escHandler);
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    });
  }

  function findTokenCards() {
    const allCards = [];
    const seenCards = new Set();

    // Method 1: Find gridcells that actually contain community links
    const gridCells = document.querySelectorAll('[role="gridcell"]');
    gridCells.forEach((cell) => {
      // Skip known non-card UI elements (navigation, search bars, modals, etc.)
      // Only skip if the cell itself has these classes, not if it's a descendant
      if (cell.classList.contains('padre-no-scroll') ||
          cell.classList.contains('css-xek4ag') ||
          cell.classList.contains('MuiModal-root') ||
          cell.classList.contains('MuiBackdrop-root') ||
          cell.getAttribute('tabindex') === '-1' || // Skip modals/popovers
          cell.closest('.MuiModal-root')) { // Skip if inside any modal
        return;
      }

      // Only include if this cell contains a community link
      if (cell.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
        if (!seenCards.has(cell)) {
          allCards.push(cell);
          seenCards.add(cell);
        }
      }
    });

    // Method 2: Find cards through community links (walk up to find container)
    const communityLinks = document.querySelectorAll('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');

    communityLinks.forEach((link) => {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) return;

      let parent = link;
      for (let i = 0; i < 20; i++) {
        parent = parent.parentElement;
        if (!parent) break;

        // Skip known non-card UI elements during traversal
        // Only stop if we hit a parent with these classes within first few levels
        if (i < 3 && (parent.classList.contains('padre-no-scroll') ||
                       parent.classList.contains('css-xek4ag') ||
                       parent.classList.contains('MuiModal-root') ||
                       parent.classList.contains('MuiBackdrop-root') ||
                       parent.getAttribute('tabindex') === '-1')) {
          break;
        }

        const style = window.getComputedStyle(parent);
        const isPositionAbsolute = style.position === 'absolute';
        const hasHeight = parent.style.height || style.height !== 'auto';
        const hasWidth = parent.style.width || style.width !== 'auto';

        if (isPositionAbsolute && hasHeight && hasWidth) {
          // Additional check: skip if inside a modal
          if (parent.closest('.MuiModal-root')) break;

          if (!seenCards.has(parent)) {
            allCards.push(parent);
            seenCards.add(parent);
          }
          break;
        }
      }
    });

    // Filter to visible cards in viewport
    const viewportHeight = window.innerHeight;
    return allCards.filter(card => {
      const rect = card.getBoundingClientRect();
      return rect.top < viewportHeight && rect.bottom > 0;
    });
  }

  // Get X community link from a card
  function getXCommunityLink(card) {
    const link = card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
    return link ? link.href : null;
  }

  // Create admin display element
  async function createAdminDisplay(admin, settings, verificationBadge = null) {
    const container = document.createElement('div');
    container.className = 'admin-display';
    // Force horizontal layout
    container.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important; gap: 4px !important;';

    // Admin avatar
    const avatar = document.createElement('img');
    const fallbackIcon = safeChromeAPI(() => chrome.runtime.getURL('icons/icon48.png'), 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="10"/></svg>');
    avatar.src = admin.profile_image_url_https || fallbackIcon;
    avatar.alt = admin.screen_name || 'Admin';
    avatar.className = 'admin-avatar';
    avatar.style.cssText = 'width: 18px !important; height: 18px !important; border-radius: 50% !important; flex-shrink: 0 !important; position: relative !important;';
    avatar.onerror = () => {
      avatar.src = safeChromeAPI(() => chrome.runtime.getURL('icons/icon48.png'), fallbackIcon);
    };

    // Admin info container
    const infoContainer = document.createElement('div');
    infoContainer.className = 'admin-username-container';
    infoContainer.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important;';

    // Username label with hover capability
    const usernameLabel = document.createElement('span');
    usernameLabel.className = 'admin-username';
    usernameLabel.textContent = '@' + (admin.screen_name || 'unknown');
    usernameLabel.style.cssText = 'cursor: pointer !important; pointer-events: auto !important; font-size: 12px !important; color: #e2e8f0 !important; font-weight: 500 !important;';

    // Add hover event listener for profile tooltip (using EventCleanupManager)
    EventCleanupManager.addEventListener(usernameLabel, 'mouseenter', (e) => {
      profileTooltip.show(e.target, admin.screen_name || 'unknown');
    });

    EventCleanupManager.addEventListener(usernameLabel, 'mousemove', (e) => {
      profileTooltip.updatePosition(e.clientX, e.clientY);
    });

    EventCleanupManager.addEventListener(usernameLabel, 'mouseleave', () => {
      profileTooltip.hide();
    });

    // Add click event listener to open modal
    EventCleanupManager.addEventListener(usernameLabel, 'click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const username = admin.screen_name || 'unknown';
      if (adminTokensModal) {
        adminTokensModal.show(username);
      }
    });

    infoContainer.appendChild(usernameLabel);

    // Follower count (if enabled and available)
    if (settings.showFollowerCount && admin.followers_count) {
      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' • ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const followerCount = document.createElement('span');
      followerCount.className = 'admin-follower-count';
      followerCount.textContent = formatNumber(admin.followers_count);
      followerCount.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      infoContainer.appendChild(separator);
      infoContainer.appendChild(followerCount);
    }

    // Sheet score (if enabled) - ALWAYS create element, will be updated by hot reload
    if (settings.showSheetScores && typeof SheetsData !== 'undefined') {
      const adminUsername = admin.screen_name || admin.userName;
      if (!adminUsername) {
        console.warn('[Padre] Admin has no username:', admin);
        return container;
      }
      const stats = await SheetsData.getAdminStats(adminUsername);

      const separator = document.createElement('span');
      separator.className = 'admin-separator';
      separator.textContent = ' - ';
      separator.style.cssText = 'font-size: 12px !important; color: #94a3b8 !important;';

      const scoreSpan = document.createElement('span');
      scoreSpan.className = `admin-sheet-score`;
      scoreSpan.setAttribute('data-admin-username', admin.screen_name || admin.userName || '');

      // Set initial state based on available data
      if (stats && stats.total_rating >= 0) {
        const scoreData = SheetsData.formatScore(stats.total_rating);
        scoreSpan.className = `admin-sheet-score ${scoreData.class}`;
        scoreSpan.textContent = scoreData.formatted;
        scoreSpan.style.cssText = `font-size: 12px !important; color: ${scoreData.color} !important; font-weight: 600 !important;`;
      } else {
        // Show loading state - will be updated by hot reload when data arrives
        scoreSpan.textContent = '...';
        scoreSpan.style.cssText = 'font-size: 12px !important; color: #64748b !important; font-weight: 400 !important;';
      }

      infoContainer.appendChild(separator);
      infoContainer.appendChild(scoreSpan);
    }

    container.appendChild(avatar);
    container.appendChild(infoContainer);

    // Add verification badge if available (always show when verification is enabled)
    if (verificationBadge && settings.communityVerificationEnabled) {
      const verificationBadgeContainer = document.createElement('div');
      verificationBadgeContainer.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; padding: 2px !important;';
      verificationBadgeContainer.appendChild(verificationBadge);
      container.appendChild(verificationBadgeContainer);
    }

    // Add blacklist and track buttons (if enabled)
    if (settings.showTrackBlacklistButtons) {
      // Add blacklist button
      const blacklistBtn = document.createElement('button');
      blacklistBtn.className = 'admin-blacklist-btn';
      blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>`;
      blacklistBtn.title = `Blacklist @${admin.screen_name}`;
      blacklistBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; color: #f43f5e !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      EventCleanupManager.addEventListener(blacklistBtn, 'mouseenter', () => {
        blacklistBtn.style.opacity = '1';
      });
      EventCleanupManager.addEventListener(blacklistBtn, 'mouseleave', () => {
        blacklistBtn.style.opacity = '0.6';
      });

      EventCleanupManager.addEventListener(blacklistBtn, 'click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const username = admin.screen_name;
        if (!username) return;

        // Check if already blacklisted
        const result = await chrome.storage.local.get(['blacklistedAdmins']);
        const blacklist = result.blacklistedAdmins || [];
        const existing = blacklist.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
        });

        if (existing) {
          blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>`;
          blacklistBtn.title = `@${username} is blacklisted`;
          blacklistBtn.style.color = '#10b981';
          return;
        }

        // Fetch profile and add to blacklist
        try {
          const response = await chrome.runtime.sendMessage({
            action: 'fetchUserProfile',
            username: username
          });

          if (response && response.success) {
            const userData = response.data?.data || response.data;
            if (userData && (userData.userName || userData.screen_name)) {
              const newAdmin = {
                username: userData.userName || userData.screen_name,
                profileImage: userData.profilePicture || userData.profile_image_url_https,
                followersCount: userData.followers || userData.followers_count,
                name: userData.name,
                banner: userData.coverPicture || userData.profile_banner_url,
                description: userData.description,
                addedAt: Date.now()
              };

              blacklist.push(newAdmin);
              await chrome.storage.local.set({ blacklistedAdmins: blacklist });

              // Update button to show success
              blacklistBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>`;
              blacklistBtn.title = `@${username} blacklisted`;
              blacklistBtn.style.color = '#10b981';
            }
          }
        } catch (error) {
          console.error('Failed to add to blacklist:', error);
        }
      });

      container.appendChild(blacklistBtn);

      // Add track button
      const trackBtn = document.createElement('button');
      trackBtn.className = 'admin-track-btn';
      trackBtn.setAttribute('data-admin-username', admin.screen_name || '');

      trackBtn.style.cssText = 'background: transparent !important; border: none !important; cursor: pointer !important; padding: 2px !important; display: flex !important; align-items: center !important; justify-content: center !important; opacity: 0.6 !important; transition: opacity 0.2s !important; flex-shrink: 0 !important;';

      // Function to update button state
      const updateTrackButtonState = async (isTracked) => {
        if (isTracked) {
          trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
          </svg>`;
          trackBtn.title = `Untrack @${admin.screen_name}`;
          trackBtn.style.color = '#fbbf24';
        } else {
          trackBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
          </svg>`;
          trackBtn.title = `Track @${admin.screen_name}`;
          trackBtn.style.color = '#22d3ee';
        }
      };

      // Check initial state
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        const tracked = result.trackedAdmins || [];
        const existing = tracked.find(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === (admin.screen_name || '').toLowerCase();
        });
        updateTrackButtonState(!!existing);
      });

      EventCleanupManager.addEventListener(trackBtn, 'mouseenter', () => {
        trackBtn.style.opacity = '1';
      });
      EventCleanupManager.addEventListener(trackBtn, 'mouseleave', () => {
        trackBtn.style.opacity = '0.6';
      });

      EventCleanupManager.addEventListener(trackBtn, 'click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const username = admin.screen_name;
        if (!username) return;

        // Check if already tracked
        const result = await chrome.storage.local.get(['trackedAdmins']);
        const tracked = result.trackedAdmins || [];
        const existingIndex = tracked.findIndex(a => {
          const adminUsername = a.username || a.userName || a.screen_name;
          return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
        });

        if (existingIndex !== -1) {
          // Untrack: remove from tracked list
          tracked.splice(existingIndex, 1);
          await chrome.storage.local.set({ trackedAdmins: tracked });

          // Update ALL track buttons for this admin across the page
          document.querySelectorAll(`.admin-track-btn[data-admin-username="${username}"]`).forEach(btn => {
            btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>`;
            btn.title = `Track @${username}`;
            btn.style.color = '#22d3ee';
          });
        } else {
          // Track: add to tracked list
          try {
            const response = await chrome.runtime.sendMessage({
              action: 'fetchUserProfile',
              username: username
            });

            if (response && response.success) {
              const userData = response.data?.data || response.data;
              if (userData && (userData.userName || userData.screen_name)) {
                const newAdmin = {
                  username: userData.userName || userData.screen_name,
                  profileImage: userData.profilePicture || userData.profile_image_url_https,
                  followersCount: userData.followers || userData.followers_count,
                  name: userData.name,
                  banner: userData.coverPicture || userData.profile_banner_url,
                  description: userData.description,
                  addedAt: Date.now()
                };

                tracked.push(newAdmin);
                await chrome.storage.local.set({ trackedAdmins: tracked });

                // Update ALL track buttons for this admin across the page
                document.querySelectorAll(`.admin-track-btn[data-admin-username="${username}"]`).forEach(btn => {
                  btn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                  </svg>`;
                  btn.title = `Untrack @${username}`;
                  btn.style.color = '#fbbf24';
                });
              }
            }
          } catch (error) {
            console.error('Failed to toggle track status:', error);
          }
        }
      });

      container.appendChild(trackBtn);
    }

    return container;
  }

  // Create member preview avatars
  function createMemberAvatar(member) {
    const container = document.createElement('div');
    container.className = 'member-avatar-container';
    // Inline styles for proper alignment
    container.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important; margin-left: -4px !important;';

    const avatar = document.createElement('img');
    const fallbackIcon = safeChromeAPI(() => chrome.runtime.getURL('icons/icon48.png'), 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="10"/></svg>');
    avatar.src = member.profile_image_url_https || fallbackIcon;
    avatar.alt = member.screen_name || 'Member';
    avatar.className = 'member-avatar';
    avatar.style.cssText = 'width: 18px !important; height: 18px !important; border-radius: 50% !important; flex-shrink: 0 !important; cursor: pointer;';
    avatar.onerror = () => {
      avatar.src = safeChromeAPI(() => chrome.runtime.getURL('icons/icon48.png'), fallbackIcon);
    };

    const username = document.createElement('span');
    username.className = 'member-username-label';
    username.textContent = '@' + (member.screen_name || 'unknown');
    username.style.cursor = 'pointer';

    // Add hover event listeners for profile tooltip (using EventCleanupManager)
    const hoverHandler = (e) => {
      profileTooltip.show(e.target, member.screen_name || 'unknown');
    };

    const moveHandler = (e) => {
      profileTooltip.updatePosition(e.clientX, e.clientY);
    };

    EventCleanupManager.addEventListener(avatar, 'mouseenter', hoverHandler);
    EventCleanupManager.addEventListener(username, 'mouseenter', hoverHandler);
    EventCleanupManager.addEventListener(avatar, 'mousemove', moveHandler);
    EventCleanupManager.addEventListener(username, 'mousemove', moveHandler);

    EventCleanupManager.addEventListener(container, 'mouseleave', () => {
      profileTooltip.hide();
    });

    container.appendChild(avatar);
    container.appendChild(username);

    return container;
  }

  // Create verification badge (green check or red X)
  function createVerificationBadge(verificationResult) {
    if (!verificationResult) {
      return null;
    }

    const badge = document.createElement('div');
    badge.className = 'verification-badge';

    // Show green check if verified (first token with this community)
    if (verificationResult.isVerified === true) {
      badge.className += ' verified-green';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>`;
      badge.title = 'Verified - First token with this community';
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #10b981 !important; flex-shrink: 0 !important;';
    } else if (verificationResult.isVerified === false) {
      badge.className += ' verified-red';
      badge.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>`;
      const ownerName = verificationResult.firstTokenAdmin || 'unknown';
      badge.title = `Not the first token with this community (first was by @${ownerName})`;
      badge.style.cssText = 'display: flex !important; align-items: center !important; justify-content: center !important; color: #ef4444 !important; flex-shrink: 0 !important;';
    } else {
      return null;
    }

    return badge;
  }

  // Register community and check ownership
  async function registerAndVerifyCommunity(communityId, adminUsername) {
    // Check cache first - if we've already verified this community, return cached result
    // This prevents showing X on re-renders of the same card
    const cacheKey = communityId;
    if (communityVerificationCache.has(cacheKey)) {
      console.log(`[Community Verification] Using cached result for community ${communityId}`);
      return communityVerificationCache.get(cacheKey);
    }

    return new Promise((resolve) => {
      safeChromeAPI(() => {
        // Get current tab ID for per-tab tracking
        chrome.runtime.sendMessage({ action: 'getTabId' }, (tabResponse) => {
          const tabId = tabResponse?.tabId || 0;
          
          chrome.runtime.sendMessage({
            action: 'registerCommunityOwner',
            communityId: communityId,
            adminUsername: adminUsername,
            tabId: tabId
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('[Community Verification] Error registering community:', chrome.runtime.lastError);
              const result = { isFirstOwner: true, isVerified: true };
              communityVerificationCache.set(cacheKey, result);
              resolve(result);
              return;
            }

            if (response && response.success) {
              // Cache the result for this community
              communityVerificationCache.set(cacheKey, response.data);
              resolve(response.data);
            } else {
              console.error('[Community Verification] Failed to register community:', response?.error);
              const result = { isFirstOwner: true, isVerified: true };
              communityVerificationCache.set(cacheKey, result);
              resolve(result);
            }
          });
        });
      }, () => {
        const result = { isFirstOwner: true, isVerified: true };
        communityVerificationCache.set(cacheKey, result);
        resolve(result);
      });
    });
  }

  // Create community indicator with admin and member info
  async function createCommunityIndicator(communityData, settings, verificationResult = null) {
    const wrapper = document.createElement('div');
    wrapper.className = 'community-indicator-wrapper admin-found';
    // Force horizontal layout with inline styles
    wrapper.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important; gap: 6px !important; flex-wrap: nowrap !important; padding: 6px 10px !important; border-radius: 6px !important;';

    // Get admin (creator or first admin)
    const admin = communityData.community_info.creator || communityData.community_info.admin;

    // Create verification badge if available
    let verificationBadge = null;
    if (verificationResult) {
      verificationBadge = createVerificationBadge(verificationResult);
    }

    // Add admin display if enabled
    if (settings.showAdminInfo && admin) {
      const adminDisplay = await createAdminDisplay(admin, settings, verificationBadge);
      wrapper.appendChild(adminDisplay);
    }

    // Add member previews if enabled
    if (settings.showMemberPreview) {
      const members = communityData.community_info.members_preview || [];
      const maxMembers = 3;

      members.slice(0, maxMembers).forEach(member => {
        // Skip if this is the admin
        if (admin && member.id === admin.id) return;

        const memberAvatar = createMemberAvatar(member);
        wrapper.appendChild(memberAvatar);
      });
    }

    return wrapper;
  }

  // Find the target container within a card to inject the indicator
  function findTargetContainer(card) {
    // Handle pump.fun structure
      // Primary target: .css-fmopri - the empty container below socials
      let target = card.querySelector('.css-fmopri');
      if (target) return target;

      // Secondary target: .css-1x2470e - the bottom stats row
      target = card.querySelector('.css-1x2470e');
      if (target) return target;

      // Tertiary target: Look for the last MuiStack-root that contains stat icons
      // This is the row with user icon, chart icon, crown icon, ghost icon, layers icon
      const allStacks = card.querySelectorAll('.MuiStack-root');
      for (let i = allStacks.length - 1; i >= 0; i--) {
        const stack = allStacks[i];
        // Check if this stack contains the bottom stat icons (remixicon SVGs)
        if (stack.querySelector('.remixicon') || stack.querySelector('svg[viewBox="0 0 24 24"]')) {
          // Make sure it's not the socials section by checking it doesn't have community links
          if (!stack.querySelector('a[href*="x.com/i/communities"]') &&
              !stack.querySelector('a[href*="pump.fun"]')) {
            return stack;
          }
        }
      }

      // Look for a child MuiStack container
      target = card.querySelector('.MuiStack-root');
      if (target) return target;

      // If the card itself is a MuiStack-root, look for a suitable child container
      if (card.classList.contains('MuiStack-root')) {
        // Look for a flex container child
        const flexChild = Array.from(card.children).find(child => {
          const style = window.getComputedStyle(child);
          return style.display === 'flex' || child.classList.contains('MuiStack-root');
        });
        if (flexChild) return flexChild;

        // If the card has children, use the first suitable one or the card itself
        if (card.children.length > 0) {
          return card;
        }
      }

      // Final fallback: use the card itself if it's a flex container
      const cardStyle = window.getComputedStyle(card);
      if (cardStyle.display === 'flex') {
        return card;
      }

      return null;
  }

  // Create fallback indicator for when API fails
  function createNotFoundIndicator(settings) {
    const wrapper = document.createElement('div');
    wrapper.className = 'community-indicator-wrapper not-found';
    wrapper.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important; gap: 6px !important; flex-wrap: nowrap !important; padding: 6px 10px !important; border-radius: 6px !important;';

    const notFoundLabel = document.createElement('span');
    notFoundLabel.className = 'admin-not-found';
    notFoundLabel.textContent = 'Admin not found';
    notFoundLabel.style.cssText = 'font-size: 12px !important; color: #ef4444 !important; font-weight: 500 !important;';

    wrapper.appendChild(notFoundLabel);
    return wrapper;
  }

  // Track if spinner keyframes have been added to avoid duplicate style tags
  let spinnerKeyframesAdded = false;

  // Create loading indicator to show immediately while fetching data
  function createLoadingIndicator(settings) {
    const wrapper = document.createElement('div');
    wrapper.className = 'community-indicator-wrapper loading';
    wrapper.style.cssText = 'display: flex !important; flex-direction: row !important; align-items: center !important; gap: 6px !important; flex-wrap: nowrap !important; padding: 6px 10px !important; border-radius: 6px !important; background: rgba(255, 255, 255, 0.03) !important;';

    // Add spinner animation keyframes only once
    if (!spinnerKeyframesAdded) {
      const style = document.createElement('style');
      style.id = 'honed-spinner-keyframes';
      style.textContent = '@keyframes honed-spin { to { transform: rotate(360deg); } }';
      document.head.appendChild(style);
      spinnerKeyframesAdded = true;
    }

    const spinner = document.createElement('span');
    spinner.className = 'loading-spinner';
    spinner.style.cssText = 'width: 12px !important; height: 12px !important; border: 2px solid rgba(255, 255, 255, 0.1) !important; border-top-color: #22d3ee !important; border-radius: 50% !important; animation: honed-spin 0.8s linear infinite !important;';

    const loadingLabel = document.createElement('span');
    loadingLabel.className = 'loading-label';
    loadingLabel.textContent = 'Loading...';
    loadingLabel.style.cssText = 'font-size: 11px !important; color: #888 !important; font-weight: 500 !important;';

    wrapper.appendChild(spinner);
    wrapper.appendChild(loadingLabel);
    return wrapper;
  }

  // Helper function to convert hex to rgba (same as core.js)
  function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  // Track cards being processed to prevent duplicates
  const processingCards = new Set();

  // Track verification results per community for current page session
  // This ensures consistent results even if page re-renders
  const communityVerificationCache = new Map();

  // Track tokens that have already played their admin alert (persists across page navigations)
  let playedAlertTokens = new Set();
  let playedAlertsLoaded = false;

  // Load played alerts from storage on init (returns Promise)
  function loadPlayedAlerts() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['playedAdminAlerts'], (result) => {
        if (result.playedAdminAlerts && Array.isArray(result.playedAdminAlerts)) {
          playedAlertTokens = new Set(result.playedAdminAlerts);
          console.log('[AdminAlert] Loaded', playedAlertTokens.size, 'played alerts from storage');
        }
        playedAlertsLoaded = true;
        resolve();
      });
    });
  }

  // Check if token has already played alert
  function hasPlayedAlert(tokenAlertId) {
    return playedAlertTokens.has(tokenAlertId);
  }

  // Mark token as having played alert and persist to storage
  function markAlertPlayed(tokenAlertId) {
    playedAlertTokens.add(tokenAlertId);
    chrome.storage.local.set({ playedAdminAlerts: Array.from(playedAlertTokens) });
  }

  async function addIndicator(card) {
    const settings = await getSettings();

    if (!settings.xCommunityEnabled) return;

    // Get community link first - use it as the card ID for proper deduplication
    const communityLink = getXCommunityLink(card);
    if (!communityLink) {
      return; // Skip cards without community link
    }

    // Check if already has indicator or is being processed
    const existingIndicator = card.querySelector('.community-indicator-wrapper');
    if (existingIndicator) {
      return;
    }

    // Use community link as the card ID for deduplication
    const cardId = communityLink;
    if (processingCards.has(cardId)) {
      return;
    }
    processingCards.add(cardId);

    try {

      const communityId = extractCommunityId(communityLink);
      if (!communityId) {
        processingCards.delete(cardId);
        return;
      }

      const targetContainer = findTargetContainer(card);
      if (!targetContainer) {
        processingCards.delete(cardId);
        return;
      }

      // Check again for existing indicator (race condition check)
      const oldIndicator = targetContainer.querySelector('.community-indicator-wrapper');
      if (oldIndicator) {
        processingCards.delete(cardId);
        return;
      }

      // IMMEDIATE FEEDBACK: Apply gradient background right away
      // This gives instant visual feedback that we detected the card
      const opacity = (settings.trackedGradientOpacity || 20) / 100 * 0.5;
      const normalColorHex = settings.normalAdminColor || '#1a1a2e';
      const normalColor = hexToRgba(normalColorHex, opacity);
      card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
      card.style.setProperty('border-radius', `12px`, 'important');

      // Check if admin is tracked (cached lookup, O(1))
      let isAdminTracked = false;
      const adminUsernameElement = card.querySelector('.admin-username');
      if (adminUsernameElement) {
        const username = adminUsernameElement.textContent.replace('@', '').toLowerCase();
        isAdminTracked = trackedAdminsSet.has(username);
      }

      // If admin is tracked, update background to tracked gradient color
      if (isAdminTracked) {
        const trackedColorHex = settings.trackedGradientColor || '#22d3ee';
        const trackedColor = hexToRgba(trackedColorHex, opacity);
        card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
      }

      // Add border for tracked admins immediately
      if (isAdminTracked) {
        card.style.setProperty('border', `2px solid ${settings.trackedBorderColor || '#22d3ee'}`, 'important');
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', `2px solid ${settings.trackedBorderColor || '#22d3ee'}`, 'important');
          }
        });
      }

      // Show a loading skeleton indicator IMMEDIATELY (before API calls)
      let loadingIndicator = createLoadingIndicator(settings);

      // Insert loading indicator instantly - no waiting for API
      if (targetContainer.firstChild) {
        targetContainer.insertBefore(loadingIndicator, targetContainer.firstChild);
      } else {
        targetContainer.appendChild(loadingIndicator);
      }

      // Now fetch the actual data async and update the indicator when ready
      let indicator;
      let adminFound = false;
      let verificationResult = null;

      try {
        const communityData = await fetchCommunityInfo(communityId);

        if (!communityData || !communityData.community_info) {
          // API returned no data - show not found
          indicator = createNotFoundIndicator(settings);
          adminFound = false;
        } else {
          // Get admin username for verification
          // Use communityId (from URL) for uniqueness, not display name
          const admin = communityData.community_info.creator || communityData.community_info.admin;

          if (communityId && admin && admin.screen_name && settings.communityVerificationEnabled) {
            // Register community and check ownership using unique community ID
            verificationResult = await registerAndVerifyCommunity(communityId, admin.screen_name);
          }

          indicator = await createCommunityIndicator(communityData, settings, verificationResult);
          adminFound = true;
        }

      } catch (error) {
        // API failed - show not found
        console.error('Error adding indicator to pump.fun card:', error);
        indicator = createNotFoundIndicator(settings);
        adminFound = false;
      }

      // Replace loading indicator with actual indicator
      const existingLoading = targetContainer.querySelector('.community-indicator-wrapper.loading');
      if (existingLoading) {
        existingLoading.replaceWith(indicator);
      } else {
        // Fallback if loading indicator was somehow removed
        const finalCheck = targetContainer.querySelector('.community-indicator-wrapper');
        if (!finalCheck) {
          if (targetContainer.firstChild) {
            targetContainer.insertBefore(indicator, targetContainer.firstChild);
          } else {
            targetContainer.appendChild(indicator);
          }
        }
      }

      // Play tracked admin alert sound (only once per unique token, persists across page navigations)
      if (isAdminTracked && typeof window.AdminAlertAudio !== 'undefined') {
        const username = adminUsernameElement?.textContent.replace('@', '') || '';
        const tokenAlertId = `${username}-${cardId}`;
        if (!hasPlayedAlert(tokenAlertId)) {
          markAlertPlayed(tokenAlertId);
          window.AdminAlertAudio.playAdminAlert();
        }
      }

    } finally {
      // Remove from processing set
      processingCards.delete(cardId);
    }
  }

   // Process all visible token cards
   async function processTokenCards() {
     const tokenCards = findTokenCards();

     if (tokenCards.length === 0) {
       return;
     }

     // Process cards sequentially to avoid race conditions with community verification
     // If processed in parallel, multiple cards with the same community might all
     // see 'not exists' and try to register simultaneously, causing incorrect X marks
     for (const card of tokenCards) {
       await addIndicator(card);
     }
   }

  async function init() {
    // License check - verify user has valid license
    if (typeof window.License !== 'undefined') {
      const isLicensed = await window.License.isLicensed();
      if (!isLicensed) {
        return; // Stop initialization - extension won't function
      }
    }

    // Load previously played admin alerts (must complete before processing cards)
    await loadPlayedAlerts();

    // Initialize tracked admins Set for O(1) lookups
    await initializeTrackedAdminsSet();

    // Initial processing - run immediately with no delay
    // Show loading indicators instantly, then fetch data async
    processTokenCards();

    // Inject analytics button into toolbar
    injectAnalyticsButton();

    // Inject admin search button into toolbar
    injectAdminSearchButton();

    // Re-inject analytics button when toolbar changes (SPA navigation)
    const analyticsButtonObserver = new MutationObserver(() => {
      injectAnalyticsButton();
      injectAdminSearchButton();
    });
    analyticsButtonObserver.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Setup hot-reload listener for settings changes
    safeChromeAPI(() => {
      // Setup removal observer to clean up event listeners when elements are removed from DOM
      removalObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.removedNodes.length > 0) {
            for (const node of mutation.removedNodes) {
              if (node.nodeType === 1) { // Element node
                // Clean up event listeners for this element and all its children
                const cleanupElement = (el) => {
                  EventCleanupManager.removeEventListeners(el);
                  // Recursively clean up children
                  Array.from(el.children).forEach(cleanupElement);
                };
                cleanupElement(node);
              }
            }
          }
        }
      });

      removalObserver.observe(document.body, {
        childList: true,
        subtree: true
      });

      chrome.storage.onChanged.addListener((changes, areaName) => {
        // Update tracked admins Set when local storage changes
        if (areaName === 'local' && changes.trackedAdmins) {
          const admins = changes.trackedAdmins.newValue || [];
          trackedAdminsSet = new Set(
            admins.map(a => (a.username || a.userName || a.screen_name)?.toLowerCase()).filter(Boolean)
          );
        }

        if (areaName === 'sync') {
          const startTime = performance.now();

          const hasToggleChange = Object.keys(changes).some(key => {
            const setting = changes[key];
            const oldValue = setting.oldValue;
            const newValue = setting.newValue;

            // Handle background color/opacity changes - update instantly
            if (key === 'trackedGradientOpacity' || key === 'normalAdminColor') {
              const updateStart = performance.now();
              const opacity = ((changes.trackedGradientOpacity?.newValue || 20) / 100 * 0.5);
              const normalColorHex = changes.normalAdminColor?.newValue || '#1a1a2e';
              const normalColor = hexToRgba(normalColorHex, opacity);

              // Update all cards with community-indicator-wrapper
              document.querySelectorAll('.community-indicator-wrapper').forEach(indicator => {
                const card = indicator.closest('[role="gridcell"]');
                if (card) {
                  card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
                  card.style.setProperty('border-radius', `12px`, 'important');
                }
              });
              return true;
            }

            // Handle tracked border color changes - update instantly
            if (key === 'trackedBorderColor') {
              const trackedBorderColor = changes.trackedBorderColor?.newValue || '#22d3ee';

              // Update all cards with tracked admin border (has solid border)
              document.querySelectorAll('[role="gridcell"]').forEach(card => {
                const currentBorder = card.style.getPropertyValue('border');
                if (currentBorder && currentBorder.includes('solid') && !currentBorder.includes('none')) {
                  card.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
                }

                // CRITICAL FIX: Also update wrapper elements with gradient background
                const wrapperSelector = `div[style*="linear-gradient(to left"]`;
                const wrappers = card.querySelectorAll(wrapperSelector);
                wrappers.forEach(wrapper => {
                  const style = wrapper.getAttribute('style') || '';
                  if (style.includes('linear-gradient') && style.includes('solid')) {
                    wrapper.style.setProperty('border', `2px solid ${trackedBorderColor}`, 'important');
                  }
                });
              });

              return true;
            }

            // Handle trackedGradientColor changes
            if (key === 'trackedGradientColor') {
              const trackedColorHex = changes.trackedGradientColor.newValue || '#22d3ee';
              const opacity = (20 / 100 * 0.5);
              const trackedColor = hexToRgba(trackedColorHex, opacity);

              document.querySelectorAll('[role="gridcell"]').forEach(card => {
                const indicator = card.querySelector('.community-indicator-wrapper');
                if (indicator) {
                  const adminUsernameEl = indicator.querySelector('.admin-username');
                  if (adminUsernameEl) {
                    const username = adminUsernameEl.textContent.replace('@', '').toLowerCase();
                    const isTracked = trackedAdminsSet.has(username);

                    if (isTracked) {
                      card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
                    }
                  }
                }
              });
              return true;
            }

            // Handle showTrackBlacklistButtons changes - just hide/show buttons without reprocessing
            if (key === 'showTrackBlacklistButtons') {
              const buttonsVisible = changes.showTrackBlacklistButtons.newValue ?? true;
              document.querySelectorAll('.admin-blacklist-btn, .admin-track-btn').forEach(btn => {
                btn.style.display = buttonsVisible ? 'flex' : 'none';
              });
              return true;
            }

            // For other settings, we need to reprocess
            return ['xCommunityEnabled', 'showAdminInfo', 'showMemberPreview', 'showFollowerCount', 'communityVerificationEnabled'].includes(key);
          });

          if (hasToggleChange || Object.keys(changes).some(key =>
            ['xCommunityEnabled', 'showAdminInfo', 'showMemberPreview', 'showFollowerCount', 'communityVerificationEnabled'].includes(key)
          )) {
            (async () => {
              // Remove existing indicators first for clean reprocessing
              document.querySelectorAll('.community-indicator-wrapper').forEach(el => el.remove());

              await processTokenCards();
            })();
          }
        }
      });
    }, () => {});

    const observer = new MutationObserver((mutations) => {
      let shouldUpdate = false;

      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
              if (node.matches('[role="gridcell"]') ||
                  node.querySelector('[role="gridcell"]') ||
                  node.matches('a[href*="x.com/i/communities"]') ||
                  node.querySelector('a[href*="x.com/i/communities"]')) {
                shouldUpdate = true;
                break;
              }
            }
          }
        }
        if (shouldUpdate) break;
      }

      if (shouldUpdate) {
        processTokenCards();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Periodic scan for X community elements every 200ms (5x per second)
    // Store interval ID for cleanup on page unload
    const periodicScan = setInterval(() => {
      processTokenCards();
    }, 200);

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', () => {
      // Clear intervals
      clearInterval(periodicScan);

      // Disconnect observers
      analyticsButtonObserver.disconnect();
      observer.disconnect();
      if (removalObserver) {
        removalObserver.disconnect();
      }

      // Run all cleanup functions via EventCleanupManager
      EventCleanupManager.cleanup();
    });
  }

   // ============================================
   // Message listener for background script triggers
   // Handles webNavigation events from background.js
   // NOTE: Register BEFORE init() to ensure we catch early messages
   // ============================================
   chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
     if (request.action === 'processTokenCards') {
       processTokenCards().then(() => {
         sendResponse({ success: true });
       }).catch(err => {
         console.error('[Padre] Error processing token cards:', err);
         sendResponse({ success: false, error: err.message });
       });
       return true; // Keep message channel open for async response
     }
     if (request.action === 'testScoreAlert') {
       if (window.ScoreAlertAudio) {
         window.ScoreAlertAudio.testSound();
         sendResponse({ success: true });
       } else {
         sendResponse({ success: false, error: 'ScoreAlertAudio not available' });
       }
       return true;
     }
   });

   // ============================================
   // CHART PAGE ADMIN HEADER INJECTION
   // NOTE: Define BEFORE init() so it can be hooked into processTokenCards
   // ============================================

   // Track if chart page header has been processed
   let chartPageProcessed = false;
   let currentChartUsername = null;
   let currentChartCommunityLink = null;

   /**
    * Check if current page is a chart/trade page
    */
   function isChartPage() {
     const path = window.location.pathname;
     return path.includes('/trade/solana/') || path.includes('/trade/');
   }

   /**
    * Extract X community link from chart page
    */
   function getChartPageCommunityLink() {
     // Look for the X community link in the token-info section
     const communityLink = document.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');
     return communityLink ? communityLink.href : null;
   }

   /**
    * Find the token stats section to inject admin header before it
    * Injects between name/ticker and marketcap
    */
   function findTokenInfoSection() {
     const tokenStats = document.querySelector('[data-testid="token-stats"]');
     if (!tokenStats) return null;

     // Get the direct parent of token-stats (this is where we'll inject)
     const container = tokenStats.parentElement;

     if (container) {
       return { container, insertBeforeElement: tokenStats };
     }
     return null;
   }

   // Track if chart processing is in progress to prevent concurrent injections
   let chartProcessingInProgress = false;

   /**
    * Create loading skeleton for chart admin header
    */
   function createChartHeaderSkeleton() {
     const skeleton = document.createElement('div');
     skeleton.className = 'chart-header-skeleton';
     skeleton.id = 'chart-admin-header-skeleton';
     skeleton.innerHTML = `
       <div class="skeleton-avatar"></div>
       <div class="skeleton-text short"></div>
       <div class="skeleton-text long"></div>
     `;
     return skeleton;
   }

   /**
    * Create admin header element with profile info and score distribution
    */
   function createChartAdminHeader(adminData, stats, communityLink, settings = {}) {
     const header = document.createElement('div');
     header.className = 'chart-admin-header';
     header.id = 'chart-admin-header';

     // Extract community ID from link
     const communityId = extractCommunityId(communityLink);

     // Format score data
     const scoreData = SheetsData ? SheetsData.formatScore(stats.total_rating || 0) : { formatted: 'N/A', class: '' };

     // Build score distribution items (0-5 + failed)
     // Items are only clickable if count > 0
     const scoreItems = [0, 1, 2, 3, 4, 5].map(score => {
       const count = stats[`tokens_score_${score}`] || 0;
       const clickableClass = count > 0 ? 'chart-score-item-clickable' : '';
       const dataScore = `data-score="${score}"`;
       return `
         <div class="chart-score-item ${clickableClass}" ${dataScore}>
           <span class="chart-score-value">${score}</span>
           <span class="chart-score-count">${count}</span>
         </div>
       `;
     }).join('');

     const failedCount = stats.tokens_score_6 || 0;
     const failedClickableClass = failedCount > 0 ? 'chart-score-item-clickable' : '';
     const failedItem = `
       <div class="chart-score-item failed-count ${failedClickableClass}" data-score="F">
         <span class="chart-score-value">F</span>
         <span class="chart-score-count">${failedCount}</span>
       </div>
     `;

     const avatarUrl = adminData.profilePicture || adminData.profile_image_url_https || '';
     const username = adminData.userName || adminData.screen_name || '';

     // Quick Stats button (only show if setting is enabled)
     const showQuickStatsBtn = settings.showQuickStatsPopup ?? true;
     const quickStatsButtonHtml = showQuickStatsBtn ? `
       <button class="quick-stats-toggle-btn" data-username="${username}" title="Quick Stats">
         <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
           <rect x="3" y="3" width="18" height="18" rx="2"/>
           <path d="M3 9h18"/>
           <path d="M9 21V9"/>
         </svg>
       </button>
     ` : '';

     header.innerHTML = `
       <div class="chart-admin-profile">
         <img class="chart-admin-avatar" src="${avatarUrl}" alt="@${username}" data-no-tooltip="true" onerror="this.style.display='none'">
         <div class="chart-admin-info">
           <span class="chart-admin-username" data-username="${username}" data-no-tooltip="true">@${username}</span>
           <span class="chart-admin-rating ${scoreData.class}">Rating: ${scoreData.formatted}</span>
         </div>
       </div>
       <div class="chart-score-distribution">
         <span class="chart-score-label">Scores</span>
         <div class="chart-scores-grid">
           ${scoreItems}
           ${failedItem}
         </div>
       </div>
       ${quickStatsButtonHtml}
     `;

     // Add click handler for username to open modal
     const usernameEl = header.querySelector('.chart-admin-username');
     if (usernameEl && typeof adminTokensModal !== 'undefined') {
       safeChromeAPI(() => {
         usernameEl.addEventListener('click', (e) => {
           e.preventDefault();
           e.stopPropagation();
           if (typeof adminTokensModal !== 'undefined') {
             adminTokensModal.show(username);
           }
         });
       });
     }

     // Add click handlers for score items (only clickable items)
     const clickableScoreItems = header.querySelectorAll('.chart-score-item-clickable');
     if (clickableScoreItems.length > 0 && typeof ScoreFilteredTokensModal !== 'undefined') {
       // Initialize the modal if not already initialized
       if (!window.scoreFilteredTokensModal) {
         window.scoreFilteredTokensModal = new ScoreFilteredTokensModal();
       }

       safeChromeAPI(() => {
         clickableScoreItems.forEach(item => {
           item.addEventListener('click', (e) => {
             e.preventDefault();
             e.stopPropagation();
             const score = item.getAttribute('data-score');
             if (score && window.scoreFilteredTokensModal) {
               window.scoreFilteredTokensModal.show(username, score);
             }
           });
         });
       });
     }

     // Add Quick Stats toggle button handler
     const quickStatsBtn = header.querySelector('.quick-stats-toggle-btn');
     if (quickStatsBtn && typeof QuickStatsPopup !== 'undefined') {
       safeChromeAPI(() => {
         quickStatsBtn.addEventListener('click', (e) => {
           e.preventDefault();
           e.stopPropagation();

           if (!window.quickStatsPopup) {
             window.quickStatsPopup = new QuickStatsPopup();
           }

           const btnUsername = quickStatsBtn.getAttribute('data-username');
           if (btnUsername) {
             if (window.quickStatsPopup.isOpen && window.quickStatsPopup.currentUsername === btnUsername) {
               window.quickStatsPopup.hide();
               quickStatsBtn.classList.remove('active');
             } else {
               window.quickStatsPopup.show(btnUsername, settings);
               quickStatsBtn.classList.add('active');
             }
           }
         });
       });
     }

     return header;
   }

   /**
    * Process chart page and inject admin header
    */
   async function processChartPage() {
     // Guard against concurrent processing
     if (chartProcessingInProgress) {
       return;
     }

     if (!isChartPage()) {
       // Not on chart page, clean up if we had processed before
       if (chartPageProcessed) {
         const existingHeader = document.getElementById('chart-admin-header');
         const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
         if (existingHeader) existingHeader.remove();
         if (existingSkeleton) existingSkeleton.remove();
         // Clean up Quick Stats popup
         if (window.quickStatsPopup) {
           window.quickStatsPopup.hide();
         }
         chartPageProcessed = false;
         currentChartUsername = null;
         currentChartCommunityLink = null;
       }
       chartProcessingInProgress = false;
       return;
     }

     // Check if chart score distribution is enabled
     const settings = await getSettings();
     if (!settings.showChartScoreDistro) {
       // Setting disabled - remove any existing header
       const existingHeader = document.getElementById('chart-admin-header');
       const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
       if (existingHeader) existingHeader.remove();
       if (existingSkeleton) existingSkeleton.remove();
       // Clean up Quick Stats popup
       if (window.quickStatsPopup) {
         window.quickStatsPopup.hide();
       }
       chartPageProcessed = false;
       currentChartUsername = null;
       currentChartCommunityLink = null;
       chartProcessingInProgress = false;
       return;
     }

     // Get community link FIRST (before checking if already processed)
     const communityLink = getChartPageCommunityLink();
     if (!communityLink) {
       // No community link found, might be loading, try again later
       return;
     }

     // Check if we're on a different chart (community link changed)
     const communityId = extractCommunityId(communityLink);
     const onDifferentChart = currentChartCommunityLink && currentChartCommunityLink !== communityLink;

     // If we're on a different chart, clean up the old header
     if (onDifferentChart) {
       console.log('[Chart Page] Navigation detected - community changed, re-processing...');
       const existingHeader = document.getElementById('chart-admin-header');
       const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
       if (existingHeader) existingHeader.remove();
       if (existingSkeleton) existingSkeleton.remove();
       // Clean up Quick Stats popup
       if (window.quickStatsPopup) {
         window.quickStatsPopup.hide();
       }
       chartPageProcessed = false;
       currentChartUsername = null;
       currentChartCommunityLink = null;
     }

     // Check if already processed (for the same chart)
     if (chartPageProcessed) {
       // Verify the header still exists, if not re-process
       const existingHeader = document.getElementById('chart-admin-header');
       if (!existingHeader) {
         chartPageProcessed = false;
       } else {
         return; // Already exists for this chart
       }
     }

     // Find injection point
     const injectionPoint = findTokenInfoSection();
     if (!injectionPoint) {
       return;
     }

     const { container, insertBeforeElement } = injectionPoint;

     // Check if header OR skeleton already exists in container
     const existingHeader = container.querySelector('#chart-admin-header');
     const existingSkeleton = container.querySelector('#chart-admin-header-skeleton');
     if (existingHeader || existingSkeleton) {
       // Already processing or done
       chartProcessingInProgress = false;
       return;
     }

     // Mark processing as started
     chartProcessingInProgress = true;

     // Show loading skeleton
     const skeleton = createChartHeaderSkeleton();
     container.insertBefore(skeleton, insertBeforeElement);

     try {
       // Extract community ID
       const communityId = extractCommunityId(communityLink);
       if (!communityId) {
         if (skeleton) skeleton.remove();
         chartProcessingInProgress = false;
         return;
       }

       // Fetch community info
       const communityData = await fetchCommunityInfo(communityId);

       if (!communityData || !communityData.community_info) {
         if (skeleton) skeleton.remove();
         chartProcessingInProgress = false;
         return;
       }

       const admin = communityData.community_info.creator || communityData.community_info.admin;
       if (!admin || !admin.screen_name) {
         if (skeleton) skeleton.remove();
         chartProcessingInProgress = false;
         return;
       }

       const username = admin.screen_name;

       // Fetch admin stats
       let stats = null;
       if (typeof SheetsData !== 'undefined') {
         stats = await SheetsData.getAdminStats(username);
       }

       // Re-fetch injection point in case DOM changed during async calls
       const newInjectionPoint = findTokenInfoSection();
       if (!newInjectionPoint) {
         if (skeleton && skeleton.parentNode) skeleton.remove();
         chartProcessingInProgress = false;
         return;
       }

       // Remove skeleton (check it's still in DOM)
       if (skeleton && skeleton.parentNode) {
         skeleton.remove();
       }

       // Double-check header wasn't added while we were fetching
       const headerAlreadyExists = document.getElementById('chart-admin-header');
       if (headerAlreadyExists) {
         chartPageProcessed = true;
         chartProcessingInProgress = false;
         return;
       }

       // Create and insert actual header (pass settings for conditional button display)
       const header = createChartAdminHeader(admin, stats, communityLink, settings);

       // Insert before the token-stats section (between name/ticker and marketcap)
       newInjectionPoint.container.insertBefore(header, newInjectionPoint.insertBeforeElement);

       chartPageProcessed = true;
       currentChartUsername = username;
       currentChartCommunityLink = communityId;
       chartProcessingInProgress = false;

     } catch (error) {
       console.error('[Chart Page] Error processing admin header:', error);
       if (skeleton && skeleton.parentNode) skeleton.remove();
       chartProcessingInProgress = false;
     }
   }

   // Note: Chart page processing is handled separately:
   // - On initial load via tryInjectChartHeader
   // - On SPA navigation via history API overrides
   // It is NOT included in the periodic scan to prevent flickering on hover

   // Start the extension
   (async () => {
     try {
       await init();
       console.log('[Padre] Extension initialized successfully');
     } catch (error) {
       console.error('[Padre] Failed to initialize extension:', error);
     }
   })();

   // Initial chart page processing (for direct page loads, not just SPA navigation)
   // Keep trying with intervals until successful, since content may load slowly
   let chartAttempts = 0;
   const maxChartAttempts = 20; // Try for up to 20 seconds

   const tryInjectChartHeader = async () => {
     if (!isChartPage()) {
       return; // Not on chart page
     }

     // Check if already successfully injected OR skeleton is present (processing in progress)
     const hasHeader = document.getElementById('chart-admin-header');
     const hasSkeleton = document.getElementById('chart-admin-header-skeleton');

     if (hasHeader) {
       return; // Already injected successfully
     }

     if (hasSkeleton) {
       // Skeleton exists but no header - might be stuck processing
       // Reset the processing flag to allow retry
       if (chartAttempts > 3) {
         console.log('[Chart Page] Skeleton stuck, resetting for retry...');
         const skeleton = document.getElementById('chart-admin-header-skeleton');
         if (skeleton) skeleton.remove();
         chartProcessingInProgress = false;
       }
       return; // Wait for current processing to complete
     }

     // Try to inject
     await processChartPage();

     chartAttempts++;
     if (chartAttempts < maxChartAttempts) {
       setTimeout(tryInjectChartHeader, 1000); // Try every second
     }
   };

   // Start trying
   setTimeout(tryInjectChartHeader, 500);

   // ============================================
   // SPA Navigation Detection - Override History API
   // Catches client-side routing changes (pushState/replaceState)
   // ============================================
   (function() {
     const originalPushState = history.pushState;
     const originalReplaceState = history.replaceState;

     // Helper function to close Quick Stats popup and reset button state
     function closeQuickStatsPopup() {
       if (window.quickStatsPopup && window.quickStatsPopup.isOpen) {
         window.quickStatsPopup.hide();
       }
       // Also reset the button active state
       const quickStatsBtn = document.querySelector('.quick-stats-toggle-btn.active');
       if (quickStatsBtn) {
         quickStatsBtn.classList.remove('active');
       }
     }

     history.pushState = function(...args) {
       const wasOnChartPage = chartPageProcessed;
       originalPushState.apply(this, args);

       // Always close Quick Stats popup when navigating from a chart page
       // This ensures popup closes when going to any page (chart or not)
       if (wasOnChartPage) {
         closeQuickStatsPopup();
       }

       // Force re-processing of chart page on navigation
       if (isChartPage() && chartPageProcessed) {
         const newCommunityLink = getChartPageCommunityLink();
         const newCommunityId = newCommunityLink ? extractCommunityId(newCommunityLink) : null;
         if (newCommunityId !== currentChartCommunityLink) {
           console.log('[Chart Page] Navigation (pushState) detected, resetting chart state...');
           const existingHeader = document.getElementById('chart-admin-header');
           const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
           if (existingHeader) existingHeader.remove();
           if (existingSkeleton) existingSkeleton.remove();
           chartPageProcessed = false;
           currentChartUsername = null;
           currentChartCommunityLink = null;
           chartProcessingInProgress = false;
         }
       }
       setTimeout(() => processTokenCards(), 100);
       // Also process chart page on navigation
       setTimeout(() => processChartPage(), 150);
     };

     history.replaceState = function(...args) {
       const wasOnChartPage = chartPageProcessed;
       originalReplaceState.apply(this, args);

       // Always close Quick Stats popup when navigating from a chart page
       if (wasOnChartPage) {
         closeQuickStatsPopup();
       }

       // Force re-processing of chart page on navigation
       if (isChartPage() && chartPageProcessed) {
         const newCommunityLink = getChartPageCommunityLink();
         const newCommunityId = newCommunityLink ? extractCommunityId(newCommunityLink) : null;
         if (newCommunityId !== currentChartCommunityLink) {
           console.log('[Chart Page] Navigation (replaceState) detected, resetting chart state...');
           const existingHeader = document.getElementById('chart-admin-header');
           const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
           if (existingHeader) existingHeader.remove();
           if (existingSkeleton) existingSkeleton.remove();
           chartPageProcessed = false;
           currentChartUsername = null;
           currentChartCommunityLink = null;
           chartProcessingInProgress = false;
         }
       }
       setTimeout(() => processTokenCards(), 100);
       // Also process chart page on navigation
       setTimeout(() => processChartPage(), 150);
     };

     // Also listen to popstate (back/forward buttons)
     window.addEventListener('popstate', () => {
       const wasOnChartPage = chartPageProcessed;

       // Always close Quick Stats popup when navigating from a chart page
       if (wasOnChartPage) {
         closeQuickStatsPopup();
       }

       // Force re-processing of chart page on navigation
       if (isChartPage() && chartPageProcessed) {
         const newCommunityLink = getChartPageCommunityLink();
         const newCommunityId = newCommunityLink ? extractCommunityId(newCommunityLink) : null;
         if (newCommunityId !== currentChartCommunityLink) {
           console.log('[Chart Page] Navigation (popstate) detected, resetting chart state...');
           const existingHeader = document.getElementById('chart-admin-header');
           const existingSkeleton = document.getElementById('chart-admin-header-skeleton');
           if (existingHeader) existingHeader.remove();
           if (existingSkeleton) existingSkeleton.remove();
           chartPageProcessed = false;
           currentChartUsername = null;
           currentChartCommunityLink = null;
           chartProcessingInProgress = false;
         }
       }
       setTimeout(() => processTokenCards(), 100);
       // Also process chart page on navigation
       setTimeout(() => processChartPage(), 150);
     });
   })();

  // ============================================
  // Listen for data updates from background script
  // Invalidate cache when new data is synced from Google Sheets
  // ============================================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'sheetsDataUpdated') {
      console.log('[Honed] Data updated in background, refreshing UI...');

      // Refresh UI with fresh data - wait for cache to reload
      (async () => {
        try {
          // Force refresh cache and wait for fresh data
          if (typeof SheetsData !== 'undefined') {
            console.log('[Honed] Reloading admin cache with fresh data...');
            await SheetsData.forceRefresh();
            console.log('[Honed] Cache reloaded, processing token cards...');
          }

          // Refresh token cards with fresh data
          if (typeof AdminDisplayHotReload !== 'undefined') {
            await processTokenCards(); // Re-process cards with fresh data
          }

          console.log('[Honed] UI refresh complete');
        } catch (err) {
          console.error('[Honed] Error refreshing UI:', err);
        }
      })();

      // Respond immediately to avoid timeout
      sendResponse({ success: true });
      return true;
    }
  });

})();
