// Tracked Admins Enhancement Script
// This script runs alongside content.js to add tracked admin features

(async function() {
  'use strict';

  // ============================================
  // SINGLETON PATTERN - Prevent duplicate injection
  // ============================================
  const INJECTION_KEY = '__honed_core_injected__';

  if (window[INJECTION_KEY]) {
    console.log('[Honed] Core already injected, skipping duplicate initialization');
    // Cleanup any existing resources from previous injection
    if (window.__honed_cleanup__) {
      window.__honed_cleanup__();
    }
    return;
  }
  window[INJECTION_KEY] = true;

  // VERY OBVIOUS STARTUP LOG
  console.log('🔥🔥🔥 [HONED CORE] SCRIPT IS RUNNING! 🔥🔥🔥');
  console.log('[HONED CORE] Current URL:', window.location.href);
  console.log('[HONED CORE] Timestamp:', new Date().toISOString());

  // Cleanup function for preventing memory leaks
  const cleanupState = {
    interval: null,
    observer: null,
    scrollFrame: null,
    intersectionObserver: null
  };

  window.__honed_cleanup__ = () => {
    if (cleanupState.interval) {
      clearInterval(cleanupState.interval);
      cleanupState.interval = null;
    }
    if (cleanupState.observer) {
      cleanupState.observer.disconnect();
      cleanupState.observer = null;
    }
    if (cleanupState.scrollFrame) {
      cancelAnimationFrame(cleanupState.scrollFrame);
      cleanupState.scrollFrame = null;
    }
    if (cleanupState.intersectionObserver) {
      cleanupState.intersectionObserver.disconnect();
      cleanupState.intersectionObserver = null;
    }
    console.log('[Honed] Core cleanup completed');
  };

  // Cleanup on page unload
  window.addEventListener('beforeunload', window.__honed_cleanup__);
  // Also cleanup on extension context invalidation
  window.addEventListener('unload', window.__honed_cleanup__);

  // Cached data for instant access (updated via storage listeners)
  let cachedTrackedAdmins = [];
  let cachedBlacklistedAdmins = [];
  let cachedSettings = {
    trackedBorderColor: '#22d3ee',
    trackedGradientColor: '#22d3ee',
    normalAdminColor: '#1a1a2e',
    trackedGradientOpacity: 20,
    adminAlertEnabled: false,
    adminAlertVolume: 50,
    // Score Alert settings
    scoreAlertEnabled: false,
    scoreAlertThreshold: 2,
    scoreAlertVolume: 50,
    scoreAlertBorderColor: '#10b981',
    scoreAlertGradientColor: '#10b981',
    scoreAlertGradientOpacity: 20
  };
  let trackedUsernamesSet = new Set(); // Cached lowercase usernames
  let blacklistedUsernamesSet = new Set(); // Cached blacklisted usernames

  // ============================================
  // PERFORMANCE: Helper to extract normalized username
  // ============================================
  function getNormalizedUsername(admin) {
    const username = admin?.username || admin?.userName || admin?.screen_name;
    return username ? username.toLowerCase() : null;
  }

  // ============================================
  // PERFORMANCE: Incremental set updates (O(k) vs O(n))
  // ============================================
  function updateTrackedAdminsIncremental(oldAdmins, newAdmins) {
    const oldSet = new Set(oldAdmins.map(getNormalizedUsername).filter(Boolean));
    const newSet = new Set(newAdmins.map(getNormalizedUsername).filter(Boolean));

    // Remove deleted admins
    for (const username of oldSet) {
      if (!newSet.has(username)) {
        trackedUsernamesSet.delete(username);
      }
    }
    // Add new admins
    for (const username of newSet) {
      if (!oldSet.has(username)) {
        trackedUsernamesSet.add(username);
      }
    }
    cachedTrackedAdmins = newAdmins;
  }

  function updateBlacklistedAdminsIncremental(oldAdmins, newAdmins) {
    const oldSet = new Set(oldAdmins.map(getNormalizedUsername).filter(Boolean));
    const newSet = new Set(newAdmins.map(getNormalizedUsername).filter(Boolean));

    // Remove deleted admins
    for (const username of oldSet) {
      if (!newSet.has(username)) {
        blacklistedUsernamesSet.delete(username);
      }
    }
    // Add new admins
    for (const username of newSet) {
      if (!oldSet.has(username)) {
        blacklistedUsernamesSet.add(username);
      }
    }
    cachedBlacklistedAdmins = newAdmins;
  }

  // Get tracked admins from storage
  async function getTrackedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['trackedAdmins'], (result) => {
        resolve(result.trackedAdmins || []);
      });
    });
  }

  // Get blacklisted admins from storage
  async function getBlacklistedAdmins() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['blacklistedAdmins'], (result) => {
        resolve(result.blacklistedAdmins || []);
      });
    });
  }

  // Get settings from storage
  async function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get({
        trackedBorderColor: '#22d3ee',
        trackedGradientColor: '#22d3ee',
        normalAdminColor: '#1a1a2e',
        trackedGradientOpacity: 20,
        adminAlertEnabled: false,
        adminAlertVolume: 50,
        // Score Alert settings
        scoreAlertEnabled: false,
        scoreAlertThreshold: 2,
        scoreAlertVolume: 50,
        scoreAlertBorderColor: '#10b981',
        scoreAlertGradientColor: '#10b981',
        scoreAlertGradientOpacity: 20
      }, (settings) => {
        resolve(settings);
      });
    });
  }

  // Legacy full rebuild (kept for initial load)
  function updateCachedTrackedAdmins(admins) {
    cachedTrackedAdmins = admins;
    trackedUsernamesSet = new Set(admins.map(getNormalizedUsername).filter(Boolean));
  }

  // Legacy full rebuild (kept for initial load)
  function updateCachedBlacklistedAdmins(admins) {
    cachedBlacklistedAdmins = admins;
    blacklistedUsernamesSet = new Set(admins.map(getNormalizedUsername).filter(Boolean));
  }

  // Initialize admin alert audio service
  async function initAdminAlertAudio() {
    const settings = await getSettings();

    if (window.AdminAlertAudio) {
      const volume = (settings.adminAlertVolume || 50) / 100;
      window.AdminAlertAudio.configure({
        enabled: settings.adminAlertEnabled || false,
        volume: volume,
        customSoundUrl: null
      });

    }
  }

  // Play admin alert sound when tracked admin creates token
  async function onTrackedAdminTokenDetected(adminUsername) {

    if (!window.AdminAlertAudio) {
      return;
    }

    const settings = await getSettings();

    if (!settings.adminAlertEnabled) {
      return;
    }

    // Try to unlock audio and play
    const audioService = window.AdminAlertAudio;

    // Update configuration with latest settings
    const volume = (settings.adminAlertVolume || 50) / 100;
    audioService.configure({
      enabled: true,
      volume: volume
    });

    const played = await audioService.playAdminAlert();

  }

  // Play score alert sound when admin score meets threshold
  async function onScoreThresholdMet(adminUsername, adminScore) {
    if (!window.ScoreAlertAudio) {
      return;
    }

    const settings = await getSettings();

    if (!settings.scoreAlertEnabled) {
      return;
    }

    // Check if score meets threshold (better than or equal to)
    if (adminScore > settings.scoreAlertThreshold) {
      return; // Score doesn't meet threshold
    }

    const audioService = window.ScoreAlertAudio;
    const volume = (settings.scoreAlertVolume || 50) / 100;
    audioService.configure({
      enabled: true,
      volume: volume
    });

    const played = await audioService.playScoreAlert();
  }

  // Hex to RGBA converter
  function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  // ============================================
  // PERFORMANCE: Optimized token card finder
  // Uses early exit patterns and fast path checks
  // ============================================
  function findTokenCards() {
    const allCards = [];
    const seenCards = new Set();

    // Strategy 1: Fast path for gridcell elements (O(1) check per element)
    const gridCells = document.querySelectorAll('[role="gridcell"]');
    for (const cell of gridCells) {
      // Early skip known non-card elements (fast classList checks)
      if (cell.classList.contains('padre-no-scroll') ||
          cell.classList.contains('css-xek4ag') ||
          cell.classList.contains('MuiModal-root') ||
          cell.classList.contains('MuiBackdrop-root') ||
          cell.getAttribute('tabindex') === '-1' ||
          cell.closest('.MuiModal-root')) {
        continue;
      }

      // Only include if this cell contains a community link
      if (cell.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
        allCards.push(cell);
      }
    }

    // Strategy 2: Walk up from community links (reduced depth from 20 to 10)
    const communityLinks = document.querySelectorAll('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]');

    for (const link of communityLinks) {
      // Skip if link is inside a modal
      if (link.closest('.MuiModal-root')) continue;

      // Use findTokenCardFromElement helper
      const card = findTokenCardFromElement(link);
      if (card && !seenCards.has(card)) {
        allCards.push(card);
        seenCards.add(card);
      }
    }

    return allCards;
  }

  // ============================================
  // PERFORMANCE: Optimized single-element card finder
  // Reduced depth from 30 to 10, uses fast path checks
  // O(d) where d is depth (max 10, down from 30)
  // ============================================
  function findTokenCardFromElement(startElement) {
    let card = startElement;
    const maxDepth = 50;
    const skipClasses = ['padre-no-scroll', 'css-xek4ag', 'MuiModal-root', 'MuiBackdrop-root'];

    for (let depth = 0; depth < maxDepth; depth++) {
      card = card.parentElement;
      if (!card) break;

      // Early skip non-card elements
      if (card.getAttribute('tabindex') === '-1') break;
      for (const skipClass of skipClasses) {
        if (card.classList.contains(skipClass)) return null;
      }

      // Check for gridcell role
      if (card.getAttribute('role') === 'gridcell') return card;

      // Check for absolute positioning with community link
      const inlineStyle = card.style;
      if (inlineStyle.position === 'absolute' && inlineStyle.width && inlineStyle.height) {
        if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
          return card;
        }
      }

      // Check for gradient background
      if ((inlineStyle.background || card.getAttribute('style') || '').includes('linear-gradient')) {
        return card;
      }

      // Check computed style after depth 3
      if (depth > 3) {
        const style = window.getComputedStyle(card);
        if (style.position === 'absolute' &&
            style.height !== 'auto' && style.height !== '0px' &&
            style.width !== 'auto' && style.width !== '0px') {
          return card;
        }
      }
    }

    return null;
  }

  // ============================================
  // PERFORMANCE: Optimized styling application
  // Uses efficient token card finding, batches style updates
  // ============================================
  function applyTrackedAdminStyling(specificNodes = null, forceRefresh = false) {
    const settings = cachedSettings;
    const trackedUsernames = trackedUsernamesSet;
    const blacklistedUsernames = blacklistedUsernamesSet;
    const viewportHeight = window.innerHeight;

    const adminUsernameElements = specificNodes ||
      document.querySelectorAll('.admin-username');

    if (adminUsernameElements.length === 0) {
      return;
    }

    let styledCount = 0;
    let trackedCount = 0;

    // Use for...of loop for better performance than forEach
    for (const adminUsername of adminUsernameElements) {
      const username = adminUsername.textContent.replace('@', '').toLowerCase();
      const isTracked = trackedUsernames.has(username);
      const isBlacklisted = blacklistedUsernames.has(username);

      const card = findTokenCardFromElement(adminUsername);

      if (!card) {
        continue;
      }

      // Per-card alert tracking: play alert once per card per session
      if (isTracked && !card.hasAttribute('data-alert-played')) {
        card.setAttribute('data-alert-played', 'true');
        onTrackedAdminTokenDetected(username);
      }

      const rect = card.getBoundingClientRect();
      const isVisible = rect.top < viewportHeight && rect.bottom > 0;

      if (!isVisible) {
        continue;
      }

      // Check if card already has blacklist overlay for this admin
      const existingOverlay = card.querySelector('.blacklist-overlay');
      const existingOverlayUsername = existingOverlay?.getAttribute('data-blacklist-username');

      // Handle blacklist overlay
      if (isBlacklisted && !existingOverlay) {
        applyBlacklistOverlay(card, username);
      } else if (existingOverlay && !existingOverlay.classList.contains('revealed') && (forceRefresh || existingOverlayUsername !== username || !isBlacklisted)) {
        existingOverlay.remove();
        card.classList.remove('blacklisted-token');
      }

      // ===== SCORE ALERT LOGIC =====
      // Check admin score and apply overlay if score meets threshold
      // Use async IIFE since this requires async SheetsData lookup
      (async () => {
        if (!settings.scoreAlertEnabled) {
          return;
        }

        // Check if SheetsData is available
        if (typeof SheetsData === 'undefined') {
          return;
        }

        try {
          // Get admin stats
          const stats = await SheetsData.getAdminStats(username);
          if (!stats || stats.total_rating === undefined) {
            return;
          }

          const adminScore = stats.total_rating;
          const meetsScoreThreshold = adminScore <= settings.scoreAlertThreshold;

          if (!meetsScoreThreshold) {
            return;
          }

          // Trigger score alert sound (one-time per card)
          if (!card.hasAttribute('data-score-alert-played')) {
            card.setAttribute('data-score-alert-played', 'true');
            await onScoreThresholdMet(username, adminScore);
          }

          // Apply score alert overlay (gradient + border)
          const opacity = settings.scoreAlertGradientOpacity / 100;
          const scoreColor = hexToRgba(settings.scoreAlertGradientColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${scoreColor} 0%, transparent 50%)`, 'important');
          card.style.setProperty('border', `2px solid ${settings.scoreAlertBorderColor}`, 'important');
          card.style.setProperty('border-radius', `12px`, 'important');

          // Also apply border to wrapper elements
          const wrapperSelector = `div[style*="linear-gradient(to left"]`;
          const wrappers = card.querySelectorAll(wrapperSelector);
          wrappers.forEach(wrapper => {
            const style = wrapper.getAttribute('style') || '';
            if (style.includes('linear-gradient')) {
              wrapper.style.setProperty('border', `2px solid ${settings.scoreAlertBorderColor}`, 'important');
            }
          });
        } catch (err) {
          // Silently fail on score check errors
        }
      })();
      // ===== END SCORE ALERT LOGIC =====

      // Apply tracked admin styling - ALWAYS show border for tracked admins regardless of gradient setting
      if (isTracked) {
        if (settings.adminBackgroundEnabled && settings.trackedGradientEnabled) {
          const opacity = settings.trackedGradientOpacity / 100;
          const trackedColor = hexToRgba(settings.trackedGradientColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
        } else if (settings.adminBackgroundEnabled) {
          const opacity = settings.trackedGradientOpacity / 100;
          const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
          card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        }
        // ALWAYS apply border for tracked admins
        card.style.setProperty('border', `2px solid ${settings.trackedBorderColor}`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');

        // CRITICAL FIX: Also apply border to any wrapper elements that have the gradient background
        // This fixes the border overlay issue on padre where a separate wrapper div
        // contains the gradient background but doesn't inherit the border from the card
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', `2px solid ${settings.trackedBorderColor}`, 'important');
          }
        });

        trackedCount++;
        styledCount++;
      } else if (settings.adminBackgroundEnabled) {
        const opacity = settings.trackedGradientOpacity / 100;
        const normalColor = hexToRgba(settings.normalAdminColor, opacity * 0.5);
        card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
        card.style.setProperty('border', `none`, 'important');
        card.style.setProperty('border-radius', `12px`, 'important');

        // Also remove border from wrapper elements
        const wrapperSelector = `div[style*="linear-gradient(to left"]`;
        const wrappers = card.querySelectorAll(wrapperSelector);
        wrappers.forEach(wrapper => {
          const style = wrapper.getAttribute('style') || '';
          if (style.includes('linear-gradient')) {
            wrapper.style.setProperty('border', 'none', 'important');
          }
        });

        styledCount++;
      }
    }
  }

  // Apply blacklist overlay with blur and reveal button
  function applyBlacklistOverlay(card, username) {
    // Skip known non-card UI elements
    if (card.classList.contains('padre-no-scroll') ||
        card.classList.contains('css-xek4ag')) {
      return;
    }

    // Mark card as blacklisted
    card.classList.add('blacklisted-token');

    // Check if overlay already exists
    if (card.querySelector('.blacklist-overlay')) {
      return;
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'blacklist-overlay';
    overlay.setAttribute('data-blacklist-username', username);

    // Create reveal button
    const revealBtn = document.createElement('button');
    revealBtn.className = 'blacklist-reveal-btn';
    revealBtn.textContent = 'Show';
    revealBtn.title = 'This token is from a blacklisted admin';

    revealBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.classList.add('revealed');
    });

    overlay.appendChild(revealBtn);
    card.appendChild(overlay);
  }

  // Find admin username elements within new nodes only
  function findAdminUsernamesInNodes(nodes) {
    const adminElements = [];
    nodes.forEach(node => {
      if (node.nodeType === 1) { // Element node
        // Check if the node itself is an admin username
        if (node.classList && node.classList.contains('admin-username')) {
          adminElements.push(node);
        }
        // Check children for admin usernames
        if (node.querySelectorAll) {
          const found = node.querySelectorAll('.admin-username');
          adminElements.push(...Array.from(found));
        }
      }
    });
    return adminElements;
  }

  // ============================================
  // PERFORMANCE: Throttle utility for scroll events
  // Reduces function calls during rapid scrolling
  // ============================================
  function throttle(func, delay) {
    let lastCall = 0;
    let pendingFrame = null;
    return function(...args) {
      const now = Date.now();
      if (now - lastCall >= delay) {
        func.apply(this, args);
        lastCall = now;
      } else if (!pendingFrame) {
        pendingFrame = requestAnimationFrame(() => {
          func.apply(this, args);
          pendingFrame = null;
        });
      }
    };
  }

  // ============================================
  // PERFORMANCE: Intersection Observer for viewport-based lazy processing
  // Only processes cards that are visible or about to become visible
  // ============================================
  function setupIntersectionObserver() {
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          // Find and process admin username within this card
          const adminUsername = entry.target.querySelector('.admin-username');
          if (adminUsername) {
            applyTrackedAdminStyling([adminUsername]);
          }
        }
      }
    }, {
      rootMargin: '50px', // Process cards 50px before they enter viewport
      threshold: 0
    });

    return observer;
  }

  // Initialize
  async function init() {

    // Populate cache with initial data
    const [trackedAdmins, blacklistedAdmins, settings] = await Promise.all([
      getTrackedAdmins(),
      getBlacklistedAdmins(),
      getSettings()
    ]);
    updateCachedTrackedAdmins(trackedAdmins);
    updateCachedBlacklistedAdmins(blacklistedAdmins);
    Object.assign(cachedSettings, settings);

    // Initialize admin alert audio service
    await initAdminAlertAudio();

    // Wait for admin username elements to appear (with timeout)
    let attempts = 0;
    const maxAttempts = 50; // 5 seconds (reduced from 10 seconds)

    while (attempts < maxAttempts) {
      const adminUsernames = document.querySelectorAll('.admin-username');
      if (adminUsernames.length > 0) {
        break;
      }
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Apply initial styling - wait for cards to load, then apply styles
    console.log('[Honed] Waiting for token cards to load...');

    // Function to apply styling once cards are available
    const applyStylesOnce = () => {
      const tokenCards = document.querySelectorAll('[role="gridcell"]');
      console.log('[Honed] Found', tokenCards.length, 'gridcell elements');

      if (tokenCards.length === 0) return false;

      let styledCards = 0;
      let cardsWithAdmins = 0;

      for (const card of tokenCards) {
        // Verify this is a token card by checking for community link
        if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
          // Find admin username within this card
          const adminUsername = card.querySelector('.admin-username');
          if (adminUsername) {
            cardsWithAdmins++;
            const username = adminUsername.textContent.replace('@', '').toLowerCase();
            const isTracked = trackedUsernames.has(username);
            const isBlacklisted = blacklistedUsernames.has(username);

            console.log('[Honed] Card has admin:', username, 'tracked:', isTracked);

            // Apply the styling directly to this card
            if (!isBlacklisted) {
              if (isTracked) {
                if (cachedSettings.adminBackgroundEnabled && cachedSettings.trackedGradientEnabled) {
                  const opacity = cachedSettings.trackedGradientOpacity / 100;
                  const trackedColor = hexToRgba(cachedSettings.trackedGradientColor, opacity * 0.5);
                  card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
                } else if (cachedSettings.adminBackgroundEnabled) {
                  const opacity = cachedSettings.trackedGradientOpacity / 100;
                  const normalColor = hexToRgba(cachedSettings.normalAdminColor, opacity * 0.5);
                  card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
                }
                card.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor}`, 'important');
                card.style.setProperty('border-radius', `12px`, 'important');
              } else if (cachedSettings.adminBackgroundEnabled) {
                const opacity = cachedSettings.trackedGradientOpacity / 100;
                const normalColor = hexToRgba(cachedSettings.normalAdminColor, opacity * 0.5);
                card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
                card.style.setProperty('border', `none`, 'important');
                card.style.setProperty('border-radius', `12px`, 'important');
              }
              styledCards++;
            }
          }
        }
      }

      console.log('[Honed] Initial styling complete: styled', styledCards, 'cards out of', cardsWithAdmins, 'with admins');
      return styledCards > 0;
    };

    // Try immediately first
    if (!applyStylesOnce()) {
      // If no cards found, poll every 100ms for up to 10 seconds
      let attempts = 0;
      const maxAttempts = 100;
      const styleCheckInterval = setInterval(() => {
        attempts++;
        if (applyStylesOnce() || attempts >= maxAttempts) {
          clearInterval(styleCheckInterval);
          console.log('[Honed] Styling polling stopped after', attempts, 'attempts');
        }
      }, 100);
      cleanupState.styleCheckInterval = styleCheckInterval;
    }

    // Setup MutationObserver for DOM changes (more efficient than polling)
    const observer = new MutationObserver((mutations) => {
      const addedNodes = [];
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === 1) {
            addedNodes.push(node);
          }
        }
      }

      if (addedNodes.length === 0) return;

      const adminElements = findAdminUsernamesInNodes(addedNodes);
      if (adminElements.length > 0) {
        applyTrackedAdminStyling(adminElements);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    cleanupState.observer = observer;

    // ============================================
    // PERFORMANCE: Throttled scroll handler (100ms throttle)
    // Much more efficient than processing on every scroll event
    // ============================================
    const throttledScroll = throttle(() => {
      applyTrackedAdminStyling();
    }, 100);

    window.addEventListener('scroll', throttledScroll, { passive: true });

    // ============================================
    // PERFORMANCE: Intersection Observer for lazy processing
    // Replaces aggressive 100ms polling - reduces CPU usage by ~90%
    // ============================================
    const intersectionObserver = setupIntersectionObserver();
    cleanupState.intersectionObserver = intersectionObserver;

    // Observe existing token cards
    const observeTokenCards = () => {
      const tokenCards = document.querySelectorAll('[role="gridcell"]');
      for (const card of tokenCards) {
        // Only observe cards with community links (actual token cards)
        if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
          intersectionObserver.observe(card);
        }
      }
    };
    observeTokenCards();

    // Enhanced MutationObserver that also observes new token cards
    const finalObserver = new MutationObserver((mutations) => {
      const addedNodes = [];
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === 1) {
            addedNodes.push(node);
          }
        }
      }

      if (addedNodes.length === 0) return;

      // Process admin username elements
      const adminElements = findAdminUsernamesInNodes(addedNodes);
      if (adminElements.length > 0) {
        applyTrackedAdminStyling(adminElements);
      }

      // Also observe new token cards for IntersectionObserver
      observeTokenCards();
    });

    observer.disconnect();
    finalObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    cleanupState.observer = finalObserver;

    // ============================================
    // PERFORMANCE: Reduced polling interval from 100ms to 200ms
    // Only used as fallback for cards missed by IntersectionObserver
    // ============================================
    const periodicStylingScan = setInterval(() => {
      applyTrackedAdminStyling();
    }, 200); // 200ms instead of 100ms (2x less frequent, balances responsiveness and CPU usage)
    cleanupState.interval = periodicStylingScan;

    // Setup hot-reload listener for settings changes
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        const startTime = performance.now();

        const relevantKeys = [
          'trackedGradientEnabled',
          'adminBackgroundEnabled',
          'trackedBorderColor',
          'trackedGradientColor',
          'normalAdminColor',
          'trackedGradientOpacity',
          'adminAlertEnabled',
          'adminAlertVolume',
          // Score Alert settings
          'scoreAlertEnabled',
          'scoreAlertVolume',
          'scoreAlertThreshold',
          'scoreAlertBorderColor',
          'scoreAlertGradientColor',
          'scoreAlertGradientOpacity'
        ];

        const hasRelevantChange = Object.keys(changes).some(key => {
          if (!relevantKeys.includes(key)) return false;

          const setting = changes[key];
          const oldValue = setting.oldValue;
          const newValue = setting.newValue;


          // Update cached settings immediately
          cachedSettings[key] = newValue;

          // Update CSS custom properties for colors
          if (key === 'trackedBorderColor') {
            document.documentElement.style.setProperty('--tracked-border-color', newValue);
          }

          if (key === 'trackedGradientColor') {
            document.documentElement.style.setProperty('--tracked-gradient-color', newValue);
          }

          if (key === 'normalAdminColor') {
            document.documentElement.style.setProperty('--normal-admin-color', newValue);
          }

          // Update admin alert audio settings
          if (key === 'adminAlertEnabled' || key === 'adminAlertVolume') {
            initAdminAlertAudio();
          }

          // Update score alert audio settings
          if (key === 'scoreAlertEnabled' || key === 'scoreAlertVolume') {
            if (window.ScoreAlertAudio) {
              const volume = (cachedSettings.scoreAlertVolume || 50) / 100;
              window.ScoreAlertAudio.configure({
                enabled: cachedSettings.scoreAlertEnabled || false,
                volume: volume
              });
            }
          }

          return true;
        });

        if (hasRelevantChange) {
          // Clear existing inline styles and styling markers for clean reapplication
          document.querySelectorAll('[data-tracked-styled]').forEach(el => {
            el.removeAttribute('data-tracked-styled');
          });
          // Only clear styles from actual token cards (gridcells with community links)
          document.querySelectorAll('[role="gridcell"]').forEach(card => {
            // Verify this is a token card by checking for community link
            if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
              if (card.style.background || card.style.border) {
                // Use removeProperty to properly remove !important styles
                card.style.removeProperty('background');
                card.style.removeProperty('border');
                card.style.removeProperty('border-radius');
              }
            }
          });

          // Apply styles directly to gridcells (same as initial load)
          const tokenCards = document.querySelectorAll('[role="gridcell"]');
          for (const card of tokenCards) {
            // Verify this is a token card by checking for community link
            if (card.querySelector('a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]')) {
              // Find admin username within this card
              const adminUsername = card.querySelector('.admin-username');
              if (adminUsername) {
                const username = adminUsername.textContent.replace('@', '').toLowerCase();
                const isTracked = trackedUsernames.has(username);
                const isBlacklisted = blacklistedUsernames.has(username);

                // Apply the styling directly to this card
                if (!isBlacklisted) {
                  if (isTracked) {
                    if (cachedSettings.adminBackgroundEnabled && cachedSettings.trackedGradientEnabled) {
                      const opacity = cachedSettings.trackedGradientOpacity / 100;
                      const trackedColor = hexToRgba(cachedSettings.trackedGradientColor, opacity * 0.5);
                      card.style.setProperty('background', `linear-gradient(to left, ${trackedColor} 0%, transparent 50%)`, 'important');
                    } else if (cachedSettings.adminBackgroundEnabled) {
                      const opacity = cachedSettings.trackedGradientOpacity / 100;
                      const normalColor = hexToRgba(cachedSettings.normalAdminColor, opacity * 0.5);
                      card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
                    } else {
                      // Both disabled - remove background
                      card.style.removeProperty('background');
                    }
                    card.style.setProperty('border', `2px solid ${cachedSettings.trackedBorderColor}`, 'important');
                    card.style.setProperty('border-radius', `12px`, 'important');
                  } else if (cachedSettings.adminBackgroundEnabled) {
                    const opacity = cachedSettings.trackedGradientOpacity / 100;
                    const normalColor = hexToRgba(cachedSettings.normalAdminColor, opacity * 0.5);
                    card.style.setProperty('background', `linear-gradient(to left, ${normalColor} 0%, transparent 50%)`, 'important');
                    card.style.setProperty('border', `none`, 'important');
                    card.style.setProperty('border-radius', `12px`, 'important');
                  } else {
                    // Background disabled - remove background
                    card.style.removeProperty('background');
                  }
                }
              }
            }
          }

          const totalTime = performance.now() - startTime;
        } else {
          const totalTime = performance.now() - startTime;
        }
      }

      // Handle tracked admins list changes
      if (areaName === 'local' && changes.trackedAdmins) {
        const newAdmins = changes.trackedAdmins.newValue || [];
        const oldAdmins = changes.trackedAdmins.oldValue || [];
        // PERFORMANCE: Use incremental update instead of full rebuild
        updateTrackedAdminsIncremental(oldAdmins, newAdmins);
      }

      // Handle blacklisted admins list changes
      if (areaName === 'local' && changes.blacklistedAdmins) {
        const newBlacklist = changes.blacklistedAdmins.newValue || [];
        const oldBlacklist = changes.blacklistedAdmins.oldValue || [];
        // PERFORMANCE: Use incremental update instead of full rebuild
        updateBlacklistedAdminsIncremental(oldBlacklist, newBlacklist);
        // Force refresh to show/hide blacklist overlays
        applyTrackedAdminStyling(null, true);
      }
    });

  }

  // Run initialization
  init();
})();
