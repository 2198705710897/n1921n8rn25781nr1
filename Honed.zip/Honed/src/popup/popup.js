/**
 * Show a toast notification
 * @param {string} message - Message to display
 * @param {string} type - Type of toast ('success' or 'error')
 */
function showToast(message, type = 'success') {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  // Remove after delay
  setTimeout(() => {
    toast.classList.add('hiding');
    toast.addEventListener('animationend', () => toast.remove());
  }, 3000);
}

/**
 * Debounce utility function for performance optimization
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Admin data structure types
 *
 * TrackedAdmin (stored in trackedAdmins):
 * @typedef {Object} TrackedAdmin
 * @property {string} username - Username handle (e.g., "username")
 * @property {string} [userName] - Alternate username field (legacy)
 * @property {string} [screen_name] - Alternate username field (legacy Twitter API format)
 * @property {string} profileImage - Profile image URL
 * @property {string} [profilePicture] - Alternate profile image field (legacy)
 * @property {string} [profile_image_url_https] - Alternate profile image field (Twitter API format)
 * @property {number} [followersCount] - Follower count
 * @property {number} [followers] - Alternate follower count field
 * @property {number} [followers_count] - Alternate follower count field (Twitter API format)
 * @property {string} [name] - Display name
 * @property {string} [banner] - Banner image URL
 * @property {string} [description] - Bio/description
 * @property {number} [followingCount] - Following count
 * @property {number} [addedAt] - Timestamp when admin was added
 *
 * AdminProfileCache (stored in adminProfileCache, keyed by username):
 * @typedef {Object} AdminProfileCache
 * @property {string} userName - Username handle (e.g., "username")
 * @property {string} name - Display name
 * @property {string} profilePicture - Profile image URL
 * @property {number} followers - Follower count
 * @property {string} id - Twitter user ID
 * @property {string} [description] - Bio/description
 * @property {string} [coverPicture] - Banner image URL
 * @property {boolean} [isVerified] - Verification status
 * @property {boolean} [isBlueVerified] - Blue verification status
 * @property {number} [fetchedAt] - Timestamp when profile was fetched
 *
 * BundledJSONAdmin (from tracked-admins-*.json settings.adminAlertsList):
 * @typedef {Object} BundledJSONAdmin
 * @property {string} username - Username handle (e.g., "username")
 * @property {string} displayName - Display name with @ (e.g., "@username")
 * @property {boolean} verified - Verification status
 * @property {number} dateAdded - Timestamp when admin was added
 */

// Import shared modules
import { importData } from '../shared/import.js';
import { exportData } from '../shared/export.js';
import { setupAvatarErrorHandler } from '../shared/avatar-refresh.js';
import { ConfigShareUpload } from '../shared/config-share-upload.js';
import { ConfigShareBrowse } from '../shared/config-share-browse.js';

// Ensure modules are available globally for debugging
window.importData = importData;
window.exportData = exportData;

// License validator (will be initialized in init())
let licenseValidator = null;

// Default settings
const DEFAULT_SETTINGS = {
  xCommunityEnabled: true,
  tweetTrackingEnabled: true,
  showAdminInfo: true,
  showMemberPreview: true,
  showFollowerCount: true,
  showTrackBlacklistButtons: true,
  normalAdminColor: '#1a1a2e',
  trackedBorderColor: '#22d3ee',
  trackedGradientColor: '#22d3ee',
  trackedGradientOpacity: 20,
  adminAlertEnabled: false,
  adminAlertVolume: 50,
  adminAlertCustomSound: null,
  communityVerificationEnabled: true,
  showSheetScores: true,
  showChartScoreDistro: true,
  // Score Alert settings
  scoreAlertEnabled: false,
  scoreAlertThreshold: 2,
  scoreAlertVolume: 50,
  scoreAlertBorderColor: '#10b981',
  scoreAlertGradientColor: '#10b981',
  scoreAlertGradientOpacity: 20
};

// Audio state for popup (syncs with content script via storage)
let audioUnlocked = false;
let hasPlayedAdminAlert = false;

// Sheets sync state
let sheetsSyncInProgress = false;

// Admins tab state for two-level navigation
let currentAdminCategory = 'xcomm'; // 'xcomm' or 'tweets'
let currentAdminSubTab = 'tracked'; // 'tracked' or 'blacklist'

// Visuals tab state for category navigation
let currentVisualsCategory = 'xcomm'; // 'xcomm' or 'tweets'

// Load settings from storage
async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULT_SETTINGS, (settings) => {
      resolve(settings);
    });
  });
}

// Save setting to storage
async function saveSetting(key, value) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [key]: value }, () => {
      resolve();
    });
  });
}

// ============================================
// LICENSE VALIDATION SETUP
// ============================================

async function setupLicenseHandling() {
  try {
    // Import license validator
    const module = await import('../shared/license-validator.js');
    licenseValidator = module.licenseValidator;

    // Initialize the validator
    await licenseValidator.init();

    // Setup UI based on license status
    updateLicenseUI();

    // Listen for validation changes
    licenseValidator.onValidationChange((isValid, reason) => {
      updateLicenseUI();
    });

    // Setup license modal event listeners
    setupLicenseModalListeners();

  } catch (e) {
    console.warn('License validator not available:', e);
  }
}

function updateLicenseUI() {
  if (!licenseValidator) return;

  const isValid = licenseValidator.isLicenseValid();
  console.log('[updateLicenseUI] isValid:', isValid);
  const banner = document.getElementById('licenseBanner');
  const bannerMessage = document.getElementById('licenseBannerMessage');

  if (isValid) {
    // Hide banner, enable all functionality
    if (banner) banner.style.display = 'none';
    enableAllFunctionality();
  } else {
    // Show banner, disable functionality
    if (banner) {
      banner.style.display = 'block';
      if (bannerMessage) {
        bannerMessage.textContent = licenseValidator.getErrorMessage();
      }
    }
    disableAllFunctionality();
  }
}

function setupLicenseModalListeners() {
  const modal = document.getElementById('licenseModal');
  const bannerBtn = document.getElementById('licenseBannerBtn');
  const closeBtn = document.getElementById('closeLicenseModal');
  const cancelBtn = document.getElementById('cancelLicenseBtn');
  const saveBtn = document.getElementById('saveLicenseKeyBtn');
  const input = document.getElementById('licenseKeyInput');
  const errorDiv = document.getElementById('licenseError');

  // Show modal when banner button clicked
  bannerBtn?.addEventListener('click', () => {
    if (modal) {
      modal.style.display = 'flex';
      if (input) input.focus();
    }
  });

  // Close modal handlers
  const closeModal = () => {
    if (modal) {
      modal.style.display = 'none';
      if (input) input.value = '';
      if (errorDiv) errorDiv.style.display = 'none';
    }
  };

  closeBtn?.addEventListener('click', closeModal);
  cancelBtn?.addEventListener('click', closeModal);

  // Close when clicking outside modal
  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Save license key
  saveBtn?.addEventListener('click', async () => {
    const key = input?.value?.trim();
    if (!key) return;

    // Disable button while validating
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = 'Validating...';
    }

    // Validate the key
    const isValid = await licenseValidator.validate(key);

    if (isValid) {
      // Save the key
      await licenseValidator.saveLicenseKey(key);
      closeModal();
      // Show success message
      showToast('License activated successfully!', 'success');
      // Update UI to reflect valid license (small delay to ensure state is updated)
      setTimeout(() => updateLicenseUI(), 100);
    } else {
      // Show error
      if (errorDiv) {
        errorDiv.textContent = licenseValidator.getErrorMessage();
        errorDiv.style.display = 'block';
      }
    }

    // Re-enable button
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Activate License';
    }
  });

  // Allow Enter key to submit
  input?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      saveBtn?.click();
    }
  });
}

function disableAllFunctionality() {
  // Add a class to body to indicate license is invalid
  document.body.classList.add('license-invalid');
}

function enableAllFunctionality() {
  // Remove the class
  document.body.classList.remove('license-invalid');
}

  // Initialize popup
  async function init() {
    // Initialize license validator first
    await setupLicenseHandling();

    const settings = await loadSettings();

    // Set toggle states from loaded settings
    Object.keys(settings).forEach(key => {
      const checkbox = document.getElementById(key);
      if (checkbox) {
        checkbox.checked = settings[key];
      }
    });

    // Setup event listeners
    setupHelpButton();
    setupMainTabs();
    setupSettingsSubTabs();
    setupCategoryTabs();
    setupAdminsSubTabs();
    setupVisualsCategoryTabs();
    setupPlatformCards();
    setupSettingRows();
    setupClearCache();
    setupImportExport();
    setupSheetsSyncStatus();
    // Setup all four admin panels
    setupXcommTracked();
    setupXcommBlacklist();
    setupTweetsTracked();
    setupTweetsBlacklist();
    setupGradientControls();
    setupAdminAlertControls();
    setupScoreAlertControls();
    // Check for update notifications
    checkForUpdateNotification();
  }

  // Setup import/export buttons
  function setupImportExport() {
    const exportRow = document.getElementById('exportAdminsBtnRow');
    const importRow = document.getElementById('importAdminsBtnRow');
    const fileInput = document.getElementById('importFileInput');

    if (exportRow) {
      exportRow.addEventListener('click', () => exportTrackedAdmins());
    }

    if (importRow) {
      importRow.addEventListener('click', () => fileInput.click());
    }

    if (fileInput) {
      fileInput.addEventListener('change', (e) => importTrackedAdmins(e));
    }

    // Setup config share buttons
    const shareConfigBtnRow = document.getElementById('shareConfigBtnRow');
    if (shareConfigBtnRow) {
      shareConfigBtnRow.addEventListener('click', () => {
        const uploadModal = new ConfigShareUpload();
        uploadModal.show();
      });
    }

    const browseConfigsBtnRow = document.getElementById('browseConfigsBtnRow');
    if (browseConfigsBtnRow) {
      browseConfigsBtnRow.addEventListener('click', () => {
        const browseModal = new ConfigShareBrowse();
        browseModal.show();
      });
    }
  }

// Setup help button
function setupHelpButton() {
  const helpButton = document.getElementById('helpButton');
  if (helpButton) {
    helpButton.addEventListener('click', () => {
      // Check if HelpModal is available
      if (typeof HelpModal !== 'undefined') {
        const helpModal = new HelpModal();
        helpModal.show();
      } else {
        console.error('[Help] HelpModal not available. Make sure help-modal.js is loaded.');
        showToast('Help modal not available', 'error');
      }
    });
  }
}

// Setup main navigation tabs
function setupMainTabs() {
  const tabButtons = document.querySelectorAll('.main-tab-button');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.getAttribute('data-main-tab');

      // Remove active class from all buttons
      tabButtons.forEach(btn => btn.classList.remove('active'));
      // Add active class to clicked button
      button.classList.add('active');

      // Hide all tab panels
      document.querySelectorAll('.main-tab-panel').forEach(panel => {
        panel.classList.remove('active');
      });

      // Show target panel
      const targetPanel = document.getElementById(targetTab + 'Tab');
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

// Setup settings sub-tabs
function setupSettingsSubTabs() {
  const subTabButtons = document.querySelectorAll('.settings-sub-tab-button');

  subTabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.getAttribute('data-settings-tab');

      // Remove active class from all buttons
      subTabButtons.forEach(btn => btn.classList.remove('active'));
      // Add active class to clicked button
      button.classList.add('active');

      // Hide all sub-panels
      document.querySelectorAll('.settings-sub-panel').forEach(panel => {
        panel.classList.remove('active');
      });

      // Show target panel
      const targetPanel = document.getElementById(targetTab + 'Panel');
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

// Setup admins category tabs (Level 1: X Comm / Tweets)
function setupCategoryTabs() {
  const categoryTabs = document.querySelectorAll('.category-tab');

  categoryTabs.forEach((tab, index) => {
    const category = tab.getAttribute('data-category');

    tab.addEventListener('click', async () => {
      const targetCategory = tab.getAttribute('data-category');

      // Update state
      currentAdminCategory = targetCategory;

      // Remove active class from all category tabs
      categoryTabs.forEach(t => t.classList.remove('active'));
      // Add active class to clicked tab
      tab.classList.add('active');

      // Show the correct panel based on category and current sub-tab
      showAdminPanel(targetCategory, currentAdminSubTab);
    });
  });
}

// Show admin panel based on category and sub-tab
function showAdminPanel(category, subTab) {
  // Hide all admin panels
  document.querySelectorAll('.admins-sub-panel').forEach(panel => {
    panel.classList.remove('active');
  });

  // Show the target panel
  const panelId = `${category}${subTab.charAt(0).toUpperCase() + subTab.slice(1)}Panel`;
  const targetPanel = document.getElementById(panelId);
  if (targetPanel) {
    targetPanel.classList.add('active');

    // Load content for the panel
    setTimeout(async () => {
      if (category === 'xcomm' && subTab === 'tracked') {
        await loadXcommTracked();
      } else if (category === 'xcomm' && subTab === 'blacklist') {
        await loadXcommBlacklist();
      } else if (category === 'tweets' && subTab === 'tracked') {
        await loadTweetsTracked();
      } else if (category === 'tweets' && subTab === 'blacklist') {
        await loadTweetsBlacklist();
      }
    }, 100);
  }
}

// Setup admins sub-tabs (Level 2: Tracked/Blacklist)
function setupAdminsSubTabs() {
  const subTabButtons = document.querySelectorAll('.admins-sub-tab-button');

  subTabButtons.forEach((button, index) => {
    const tabName = button.getAttribute('data-admins-tab');

    button.addEventListener('click', async () => {
      const targetTab = button.getAttribute('data-admins-tab');

      // Update state
      currentAdminSubTab = targetTab;

      // Remove active class from all buttons
      subTabButtons.forEach(btn => btn.classList.remove('active'));
      // Add active class to clicked button
      button.classList.add('active');

      // Show the correct panel based on current category and new sub-tab
      showAdminPanel(currentAdminCategory, targetTab);
    });
  });
}

// Setup visuals category tabs (Level 1: X Comm / Tweets within Visuals panel)
function setupVisualsCategoryTabs() {
  const visualsCategoryTabs = document.querySelectorAll('#visualsPanel .category-tab');

  visualsCategoryTabs.forEach((tab, index) => {
    const category = tab.getAttribute('data-visuals-category');

    tab.addEventListener('click', () => {
      const targetCategory = tab.getAttribute('data-visuals-category');

      // Update state
      currentVisualsCategory = targetCategory;

      // Remove active class from all category tabs in visuals panel
      document.querySelectorAll('#visualsPanel .category-tab').forEach(t => t.classList.remove('active'));
      // Add active class to clicked tab
      tab.classList.add('active');

      // Hide all visuals sub-panels
      document.querySelectorAll('.visuals-sub-panel').forEach(panel => {
        panel.classList.remove('active');
      });

      // Show the target panel
      const panelId = `${targetCategory}VisualsPanel`;
      const targetPanel = document.getElementById(panelId);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}

// Setup toggle listeners
function setupToggleListeners() {
  // Find all checkboxes in the settings area
  const checkboxes = document.querySelectorAll('.settings-group input[type="checkbox"]');

  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', async (e) => {
      const key = e.target.id;
      const value = e.target.checked;

      // Save setting (content scripts will auto-update via storage listener)
      await saveSetting(key, value);
    });
  });
}

// Setup platform card click handlers
function setupPlatformCards() {
  const cards = document.querySelectorAll('.platform-card');

  cards.forEach(card => {
    const label = card.querySelector('label');
    if (label) {
      label.addEventListener('click', async (e) => {
        // Let the checkbox handle the click
        const checkbox = card.querySelector('input[type="checkbox"]');
        if (checkbox && e.target !== checkbox) {
          // Wait for the checkbox to toggle, then save
          setTimeout(async () => {
            await saveSetting(checkbox.id, checkbox.checked);
          }, 0);
        }
      });
    }
  });
}

// Setup setting row click handlers (for grid-style toggle buttons)
function setupSettingRows() {
  const settingRows = document.querySelectorAll('.setting-row[data-checkbox-id]');

  settingRows.forEach(row => {
    const checkboxId = row.getAttribute('data-checkbox-id');
    const checkbox = document.getElementById(checkboxId);

    if (checkbox) {
      // Add change listener to checkbox for direct changes
      checkbox.addEventListener('change', async (e) => {
        const newState = e.target.checked;
        await saveSetting(checkboxId, newState);
        // Send instant update to all tabs
        broadcastSettingChange(checkboxId, newState);
        // Add visual flash effect
        flashSettingRow(row, newState);
      });

      // Prevent default label behavior and handle clicks manually
      row.addEventListener('click', async (e) => {
        e.preventDefault();
        checkbox.checked = !checkbox.checked;
        // Trigger change event to save setting
        checkbox.dispatchEvent(new Event('change'));
      });
    }
  });
}

// Broadcast setting change to all active tabs for instant update
function broadcastSettingChange(key, value) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, {
        action: 'settingChanged',
        key: key,
        value: value
      }).catch(() => {
        // Ignore errors for tabs without content script
      });
    });
  });
}

// Add visual flash effect when setting is toggled
function flashSettingRow(row, enabled) {
  const settingContent = row.querySelector('.setting-content');
  if (!settingContent) return;

  // Store original values
  const originalTransform = settingContent.style.transform;
  const originalTransition = settingContent.style.transition;

  // Add flash effect
  settingContent.style.transition = 'all 0.15s ease';
  settingContent.style.transform = enabled ? 'scale(1.02)' : 'scale(0.98)';

  // Also add a subtle color flash to the setting name
  const settingName = settingContent.querySelector('span:first-child');
  if (settingName) {
    const originalColor = settingName.style.color;
    settingName.style.color = enabled ? 'var(--color-success)' : 'var(--color-danger)';

    setTimeout(() => {
      // Reset to original
      settingContent.style.transform = 'scale(1)';
      setTimeout(() => {
        settingContent.style.transform = originalTransform || '';
        settingContent.style.transition = originalTransition || '';
      }, 150);
      settingName.style.color = originalColor || '';
    }, 300);
  }
}

// Setup clear cache button
function setupClearCache() {
  const clearRow = document.getElementById('clearCacheRow');
  const clearBtn = document.getElementById('clearCache');

  if (clearRow) {
    clearRow.addEventListener('click', async () => {
      // Clear only API cache entries, not user data
      chrome.storage.local.get(null, (items) => {
        const cacheKeys = Object.keys(items).filter(key =>
          key.startsWith('community_cache_') ||
          key.startsWith('user_profile_') ||
          key.startsWith('mevx_token_')
        );
        chrome.storage.local.remove(cacheKeys, () => {
          // Show confirmation
          const content = clearRow.querySelector('.setting-content');
          if (content) {
            const originalHTML = content.innerHTML;
            content.innerHTML = '<span style="color: var(--color-success);">✓ Cleared!</span>';

            // Reset after 2 seconds
            setTimeout(() => {
              content.innerHTML = originalHTML;
            }, 2000);
          }
        });
      });
    });
  }
}

// Tracked Admins functionality
async function setupTrackedAdmins() {
  const addBtn = document.getElementById('addAdminBtn');
  const input = document.getElementById('adminUsernameInput');
  const exportBtn = document.getElementById('exportAdminsBtn');
  const importBtn = document.getElementById('importAdminsBtn');
  const exportRow = document.getElementById('exportAdminsBtnRow');
  const importRow = document.getElementById('importAdminsBtnRow');
  const fileInput = document.getElementById('importFileInput');
  const clearAllBtn = document.getElementById('clearAllAdminsBtn');
  const searchInput = document.getElementById('adminSearchInput');

  await loadTrackedAdmins();

  addBtn.addEventListener('click', () => addTrackedAdmin());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTrackedAdmin();
  });

  // Setup export/import row handlers
  exportRow.addEventListener('click', () => exportTrackedAdmins());
  importRow.addEventListener('click', () => fileInput.click());

  exportBtn.addEventListener('click', () => exportTrackedAdmins());
  importBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => importTrackedAdmins(e));

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllTrackedAdmins());
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => filterTrackedAdmins(e.target.value));
  }
}

// X Comm Tracked functionality (renamed from setupTrackedAdmins)
async function setupXcommTracked() {
  const addBtn = document.getElementById('addXcommBtn');
  const input = document.getElementById('xcommUsernameInput');
  const clearAllBtn = document.getElementById('clearAllXcommBtn');
  const searchInput = document.getElementById('xcommSearchInput');

  await loadXcommTracked();

  addBtn.addEventListener('click', () => addXcommTracked());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addXcommTracked();
  });

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllXcommTracked());
  }

  if (searchInput) {
    // Debounce search input to improve performance
    searchInput.addEventListener('input', debounce((e) => filterXcommTracked(e.target.value), 150));
  }
}

// Load X Comm tracked admins (same as loadTrackedAdmins but uses xcommTrackedList)
async function loadXcommTracked() {
  let admins = await getTrackedAdmins();

  // Filter out invalid entries and clean up storage
  const validAdmins = admins.filter(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const image = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
    return username && image && image !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validAdmins.length !== admins.length) {
    await saveTrackedAdmins(validAdmins);
    admins = validAdmins;
  }

  const container = document.getElementById('xcommTrackedList');
  if (!container) {
    return;
  }

  if (admins.length === 0) {
    container.innerHTML = '<div class="empty-state">No tracked admins yet. Add one above!</div>';
    const searchInput = document.getElementById('xcommSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterXcommTracked(searchInput.value);
    }
    return;
  }

  container.innerHTML = admins.map(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const displayName = admin.name || username;
    const profileImage = admin.profileImage || admin.profilePicture || admin.profile_image_url_https || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png';
    const followersCount = admin.followersCount || admin.followers || admin.followers_count || 0;

    return `
      <div class="tracked-admin-card" data-username="${escapeHtml(username)}">
        <img class="tracked-admin-avatar" src="${escapeHtml(profileImage)}" data-default="https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png">
        <div class="tracked-admin-info">
          <div class="tracked-admin-username">@${escapeHtml(username)}</div>
          <div class="tracked-admin-name">${escapeHtml(displayName)}</div>
          <div class="tracked-admin-followers">${formatFollowerCount(followersCount)} followers</div>
        </div>
        <button class="tracked-admin-remove" data-username="${escapeHtml(username)}">✕</button>
      </div>
    `;
  }).join('');

  // Add remove button listeners
  container.querySelectorAll('.tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', () => removeXcommTracked(btn.getAttribute('data-username')));
  });

  // Add image error handlers
  container.querySelectorAll('.tracked-admin-avatar').forEach(img => {
    img.addEventListener('error', () => {
      const defaultSrc = img.getAttribute('data-default');
      if (defaultSrc && img.src !== defaultSrc) {
        img.src = defaultSrc;
      }
    });
  });

  // Re-apply search filter if there's an active search
  const searchInput = document.getElementById('xcommSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterXcommTracked(searchInput.value);
  }
}

async function addXcommTracked() {
  const input = document.getElementById('xcommUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const admins = await getTrackedAdmins();
  const existingAdmin = admins.find(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingAdmin) {
    input.value = '';
    return;
  }

  const addBtn = document.getElementById('addXcommBtn');
  input.disabled = true;
  addBtn.classList.add('loading');

  try {
    const profileData = await fetchUserProfile(username);

    const admin = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      banner: profileData.coverPicture || profileData.profile_banner_url,
      description: profileData.description,
      followingCount: profileData.following || profileData.friends_count,
      addedAt: Date.now()
    };

    admins.push(admin);
    await saveTrackedAdmins(admins);
    await loadXcommTracked();

    input.value = '';
  } catch (error) {
    console.error('Error adding admin:', error);
    alert(`Failed to add admin: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  addBtn.classList.remove('loading');
}

async function removeXcommTracked(username) {
  const admins = await getTrackedAdmins();
  const filtered = admins.filter(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername !== username;
  });
  await saveTrackedAdmins(filtered);
  await loadXcommTracked();
}

async function clearAllXcommTracked() {
  if (confirm('Are you sure you want to remove all tracked admins?')) {
    await saveTrackedAdmins([]);
    await loadXcommTracked();
  }
}

function filterXcommTracked(query) {
  const container = document.getElementById('xcommTrackedList');
  if (!container) return;

  const cards = container.querySelectorAll('.tracked-admin-card');
  const normalizedQuery = query.toLowerCase().trim();

  cards.forEach(card => {
    const username = card.getAttribute('data-username').toLowerCase();
    const displayName = card.querySelector('.tracked-admin-name')?.textContent.toLowerCase() || '';

    if (username.includes(normalizedQuery) || displayName.includes(normalizedQuery)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

async function addTrackedAdmin() {
  const input = document.getElementById('adminUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const admins = await getTrackedAdmins();
  const existingAdmin = admins.find(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingAdmin) {
    input.value = '';
    return;
  }

  input.disabled = true;
  document.getElementById('addAdminBtn').disabled = true;

  try {
    const profileData = await fetchUserProfile(username);

    // Handle both new API format (userName, profilePicture, followers) and old format (screen_name, profile_image_url_https, followers_count)
    const admin = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      banner: profileData.coverPicture || profileData.profile_banner_url,
      description: profileData.description,
      followingCount: profileData.following || profileData.friends_count,
      addedAt: Date.now()
    };

    // Validate we have the minimum required data
    if (!admin.username || !admin.profileImage) {
      throw new Error('Invalid profile data received from API');
    }

    admins.push(admin);
    await saveTrackedAdmins(admins);
    await loadTrackedAdmins();

    input.value = '';
  } catch (error) {
    console.error('Error adding admin:', error);
    alert(`Failed to add admin: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  document.getElementById('addAdminBtn').disabled = false;
}

async function fetchUserProfile(username) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      action: 'fetchUserProfile',
      username: username
    }, (response) => {
      if (response.success) {
        // API returns {status: "success", data: {...}}
        const userData = response.data?.data || response.data;
        // Accept data if it has either userName (new) or screen_name (old)
        if (userData && (userData.userName || userData.screen_name)) {
          resolve(userData);
        } else {
          console.error('Invalid API response:', userData);
          reject(new Error('Invalid API response format - missing username'));
        }
      } else {
        reject(new Error(response.error || 'Unknown error'));
      }
    });
  });
}

async function removeTrackedAdmin(username) {
  const admins = await getTrackedAdmins();
  const filtered = admins.filter(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername !== username;
  });
  await saveTrackedAdmins(filtered);
  await loadTrackedAdmins();
}

async function clearAllTrackedAdmins() {
  if (confirm('Are you sure you want to remove all tracked admins?')) {
    await saveTrackedAdmins([]);
    await loadTrackedAdmins();
  }
}

async function getTrackedAdmins() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['trackedAdmins'], (result) => {
      resolve(result.trackedAdmins || []);
    });
  });
}

async function saveTrackedAdmins(admins) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ trackedAdmins: admins }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

async function loadTrackedAdmins() {
  let admins = await getTrackedAdmins();

  // Filter out invalid entries and clean up storage
  const validAdmins = admins.filter(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const image = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
    return username && image && image !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validAdmins.length !== admins.length) {
    await saveTrackedAdmins(validAdmins);
    admins = validAdmins;
  }

  const container = document.getElementById('trackedAdminsList');
  if (!container) {
    // Container might not be visible if we're on a different tab
    return;
  }

  if (admins.length === 0) {
    container.innerHTML = '<div class="empty-state">No tracked admins yet. Add one above!</div>';
    // Re-apply search filter if there's an active search
    const searchInput = document.getElementById('adminSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterTrackedAdmins(searchInput.value);
    }
    return;
  }

  container.innerHTML = admins.map(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const image = admin.profileImage || admin.profilePicture || admin.profile_image_url_https;
    const followers = admin.followersCount || admin.followers || admin.followers_count;
    const name = admin.name;

    // Build the info section with optional display name
    let infoHtml = `
      <div class="tracked-admin-username">@${username}</div>
    `;
    if (name && name !== username) {
      infoHtml += `<div class="tracked-admin-name">${escapeHtml(name)}</div>`;
    }
    infoHtml += `<div class="tracked-admin-followers">${formatFollowerCount(followers)} followers</div>`;

    return `
    <div class="tracked-admin-card" data-username="${username}">
      <img src="${image}" alt="${username}" class="tracked-admin-avatar" data-fallback="true">
      <div class="tracked-admin-info">
        ${infoHtml}
      </div>
      <button class="tracked-admin-remove" data-username="${username}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
    `;
  }).join('');

  // Add error handlers for images with avatar refresh
  container.querySelectorAll('.tracked-admin-avatar[data-fallback]').forEach(img => {
    const username = img.getAttribute('alt');
    if (username && username !== 'Admin') {
      setupAvatarErrorHandler(img, username);
    } else {
      img.addEventListener('error', function() {
        this.src = chrome.runtime.getURL('icons/icon48.png');
        this.removeAttribute('data-fallback');
      });
    }
  });

  document.querySelectorAll('.tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const username = e.currentTarget.getAttribute('data-username');
      removeTrackedAdmin(username);
    });
  });

  // Re-apply search filter if there's an active search
  const searchInput = document.getElementById('adminSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterTrackedAdmins(searchInput.value);
  }
}

/**
 * Escape HTML to prevent XSS when rendering user-provided content
 * Uses cached DOM element for better performance
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
const escapeHtmlDiv = document.createElement('div');
function escapeHtml(text) {
  escapeHtmlDiv.textContent = text;
  return escapeHtmlDiv.innerHTML;
}

function formatFollowerCount(count) {
  if (!count || isNaN(count)) return '0';
  count = Number(count);
  if (count >= 1000000) {
    return (count / 1000000).toFixed(1) + 'M';
  }
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'K';
  }
  return count.toString();
}

/**
 * Export tracked admins using the single export primitive
 * @async
 */
async function exportTrackedAdmins() {
  try {
    const result = await exportData({
      includeAdmins: true,
      includeSettings: true,
      includeBlacklist: true,
      includeProfileCache: true,
      includeTweets: true,
      includeTweetsBlacklist: true
    });

    if (result.success) {
      // Show brief success message
      const exportRow = document.getElementById('exportAdminsBtnRow');
      if (exportRow) {
        const content = exportRow.querySelector('.setting-content');
        if (content) {
          const originalHTML = content.innerHTML;
          content.innerHTML = '<span style="color: var(--color-success);">✓ Exported!</span>';
          setTimeout(() => {
            content.innerHTML = originalHTML;
          }, 2000);
        }
      }
    } else {
      throw new Error('Export failed');
    }
  } catch (error) {
    console.error('[Export] Failed:', error);
    alert(`Failed to export: ${error.message || 'Unknown error'}`);
  }
}

/**
 * Import tracked admins using the single import primitive
 * @async
 */
async function importTrackedAdmins(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const result = await importData(file, {
      mergeWithExisting: true,
      importSettings: true,
      importBlacklist: true,
      importProfileCache: true
    });

    // Wait a brief moment to ensure chrome.storage.sync is fully updated
    // This ensures the chrome.storage.onChanged event has fired and completed
    await new Promise(resolve => setTimeout(resolve, 100));

    // Reload all lists AFTER settings are fully persisted
    await loadTrackedAdmins();
    await loadTweetsTracked();
    await loadTweetsBlacklist();

    // Refresh visual controls to show imported settings
    // This now happens after all data loading is complete
    await updateVisualControlsFromStorage();

    // Show result message
    if (result.success) {
      const message = result.messages.join('\n');
      if (result.messages.some(m => m.includes('failed') || m.includes('skipped'))) {
        alert(`✓ ${message}\n\n💡 Tip: Profile cache can be rebuilt by hovering over admin usernames.`);
      } else if (message !== 'No data found to import') {
        alert(`✓ ${message}`);
      }

      // Show brief success message in UI
      const importRow = document.getElementById('importAdminsBtnRow');
      if (importRow) {
        const content = importRow.querySelector('.setting-content');
        if (content) {
          const originalHTML = content.innerHTML;
          content.innerHTML = '<span style="color: var(--color-success);">✓ Imported!</span>';
          setTimeout(() => {
            content.innerHTML = originalHTML;
          }, 2000);
        }
      }
    } else {
      alert(result.messages[0] || 'Import failed');
    }
  } catch (error) {
    console.error('[Import] Failed:', error);
    alert(`Failed to import: ${error.message || 'Unknown error'}`);
  }

  // Reset file input
  event.target.value = '';
}

/**
 * Filter the tracked admins list based on search query
 * @param {string} query - Search query (filters username, display name, and handle)
 */
function filterTrackedAdmins(query) {
  const container = document.getElementById('trackedAdminsList');
  const adminCards = container.querySelectorAll('.tracked-admin-card');
  const emptyState = container.querySelector('.empty-state');

  if (!query || query.trim() === '') {
    // Show all admins when search is cleared
    adminCards.forEach(card => {
      card.style.display = 'flex';
    });

    // Hide search-related empty state, but preserve "no admins yet" message
    if (emptyState) {
      const emptyText = emptyState.textContent;
      if (emptyText.includes('matching your search')) {
        emptyState.style.display = 'none';
      } else if (adminCards.length > 0) {
        // Hide "no admins yet" message if there are actually admins
        emptyState.style.display = 'none';
      } else {
        // Show "no admins yet" message
        emptyState.style.display = 'block';
      }
    }
    return;
  }

  const lowerQuery = query.toLowerCase().trim();
  let visibleCount = 0;

  adminCards.forEach(card => {
    const username = card.getAttribute('data-username') || '';
    const usernameElement = card.querySelector('.tracked-admin-username');
    const nameElement = card.querySelector('.tracked-admin-name');

    const usernameText = usernameElement?.textContent || '';
    const nameText = nameElement?.textContent || '';

    // Match against username (with and without @), display name
    const matches =
      username.toLowerCase().includes(lowerQuery) ||
      usernameText.toLowerCase().includes(lowerQuery) ||
      nameText.toLowerCase().includes(lowerQuery);

    if (matches) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  // Show "no results" message if no admins match
  if (visibleCount === 0) {
    if (!emptyState) {
      const noResults = document.createElement('div');
      noResults.className = 'empty-state';
      noResults.textContent = 'No admins found matching your search.';
      container.appendChild(noResults);
    } else {
      emptyState.textContent = 'No admins found matching your search.';
      emptyState.style.display = 'block';
    }
  } else if (emptyState) {
    emptyState.style.display = 'none';
  }
}

// ========== Blacklist Admins Functionality ==========

// Blacklist Admins functionality
async function setupBlacklistAdmins() {
  const addBtn = document.getElementById('addBlacklistBtn');
  const input = document.getElementById('blacklistUsernameInput');
  const clearAllBtn = document.getElementById('clearAllBlacklistBtn');
  const searchInput = document.getElementById('blacklistSearchInput');

  await loadBlacklistAdmins();

  addBtn.addEventListener('click', () => addBlacklistAdmin());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addBlacklistAdmin();
  });

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllBlacklistAdmins());
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => filterBlacklistAdmins(e.target.value));
  }
}

async function addBlacklistAdmin() {
  const input = document.getElementById('blacklistUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const blacklist = await getBlacklistAdmins();
  const existingAdmin = blacklist.find(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingAdmin) {
    input.value = '';
    return;
  }

  input.disabled = true;
  document.getElementById('addBlacklistBtn').disabled = true;

  try {
    const profileData = await fetchUserProfile(username);

    // Handle both new API format (userName, profilePicture, followers) and old format (screen_name, profile_image_url_https, followers_count)
    const admin = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      banner: profileData.coverPicture || profileData.profile_banner_url,
      description: profileData.description,
      followingCount: profileData.following || profileData.friends_count,
      addedAt: Date.now()
    };

    // Validate we have the minimum required data
    if (!admin.username || !admin.profileImage) {
      throw new Error('Invalid profile data received from API');
    }

    blacklist.push(admin);
    await saveBlacklistAdmins(blacklist);
    await loadBlacklistAdmins();

    input.value = '';
  } catch (error) {
    console.error('Error adding blacklist admin:', error);
    alert(`Failed to add blacklist admin: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  document.getElementById('addBlacklistBtn').disabled = false;
}

async function removeBlacklistAdmin(username) {
  const blacklist = await getBlacklistAdmins();
  const filtered = blacklist.filter(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername !== username;
  });
  await saveBlacklistAdmins(filtered);
  await loadBlacklistAdmins();
}

async function clearAllBlacklistAdmins() {
  if (confirm('Are you sure you want to remove all blacklisted admins?')) {
    await saveBlacklistAdmins([]);
    await loadBlacklistAdmins();
  }
}

async function getBlacklistAdmins() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['blacklistedAdmins'], (result) => {
      resolve(result.blacklistedAdmins || []);
    });
  });
}

async function saveBlacklistAdmins(blacklist) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ blacklistedAdmins: blacklist }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

async function loadBlacklistAdmins() {
  let blacklist = await getBlacklistAdmins();

  // Filter out invalid entries - only require username, image is optional
  const validBlacklist = blacklist.filter(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    // Accept admin if they have at least a username - image is optional
    return username && username !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validBlacklist.length !== blacklist.length) {
    await saveBlacklistAdmins(validBlacklist);
    blacklist = validBlacklist;
  }

  const container = document.getElementById('blacklistAdminsList');
  if (!container) {
    console.error('blacklistAdminsList container not found');
    return;
  }

  if (blacklist.length === 0) {
    container.innerHTML = '<div class="empty-state">No blacklisted admins yet. Add one above!</div>';
    // Re-apply search filter if there's an active search
    const searchInput = document.getElementById('blacklistSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterBlacklistAdmins(searchInput.value);
    }
    return;
  }

  container.innerHTML = blacklist.map(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const image = admin.profileImage || admin.profilePicture || admin.profile_image_url_https || chrome.runtime.getURL('icons/icon48.png');
    const followers = admin.followersCount || admin.followers || admin.followers_count || 0;
    const name = admin.name;

    // Build the info section with optional display name
    let infoHtml = `
      <div class="tracked-admin-username">@${username}</div>
    `;
    if (name && name !== username) {
      infoHtml += `<div class="tracked-admin-name">${escapeHtml(name)}</div>`;
    }
    infoHtml += `<div class="tracked-admin-followers">${formatFollowerCount(followers)} followers</div>`;

    return `
    <div class="tracked-admin-card blacklist-card" data-username="${username}">
      <img src="${image}" alt="${username}" class="tracked-admin-avatar" data-fallback="true">
      <div class="tracked-admin-info">
        ${infoHtml}
      </div>
      <button class="tracked-admin-remove" data-username="${username}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
    `;
  }).join('');

  // Add error handlers for images with avatar refresh
  container.querySelectorAll('.tracked-admin-avatar[data-fallback]').forEach(img => {
    const username = img.getAttribute('alt');
    if (username && username !== 'Admin') {
      setupAvatarErrorHandler(img, username, 'blacklist');
    } else {
      img.addEventListener('error', function() {
        this.src = chrome.runtime.getURL('icons/icon48.png');
        this.removeAttribute('data-fallback');
      });
    }
  });

  document.querySelectorAll('.blacklist-card .tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const username = e.currentTarget.getAttribute('data-username');
      removeBlacklistAdmin(username);
    });
  });

  // Re-apply search filter if there's an active search
  const searchInput = document.getElementById('blacklistSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterBlacklistAdmins(searchInput.value);
  }
}

function filterBlacklistAdmins(query) {
  const container = document.getElementById('blacklistAdminsList');
  const adminCards = container.querySelectorAll('.blacklist-card');
  const emptyState = container.querySelector('.empty-state');

  if (!query || query.trim() === '') {
    // Show all admins when search is cleared
    adminCards.forEach(card => {
      card.style.display = 'flex';
    });

    // Hide search-related empty state, but preserve "no admins yet" message
    if (emptyState) {
      const emptyText = emptyState.textContent;
      if (emptyText.includes('matching your search')) {
        emptyState.style.display = 'none';
      } else if (adminCards.length > 0) {
        // Hide "no admins yet" message if there are actually admins
        emptyState.style.display = 'none';
      } else {
        // Show "no admins yet" message
        emptyState.style.display = 'block';
      }
    }
    return;
  }

  const lowerQuery = query.toLowerCase().trim();
  let visibleCount = 0;

  adminCards.forEach(card => {
    const username = card.getAttribute('data-username') || '';
    const usernameElement = card.querySelector('.tracked-admin-username');
    const nameElement = card.querySelector('.tracked-admin-name');

    const usernameText = usernameElement?.textContent || '';
    const nameText = nameElement?.textContent || '';

    // Match against username (with and without @), display name
    const matches =
      username.toLowerCase().includes(lowerQuery) ||
      usernameText.toLowerCase().includes(lowerQuery) ||
      nameText.toLowerCase().includes(lowerQuery);

    if (matches) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  // Show "no results" message if no admins match
  if (visibleCount === 0) {
    if (!emptyState) {
      const noResults = document.createElement('div');
      noResults.className = 'empty-state';
      noResults.textContent = 'No admins found matching your search.';
      container.appendChild(noResults);
    } else {
      emptyState.textContent = 'No admins found matching your search.';
      emptyState.style.display = 'block';
    }
  } else if (emptyState) {
    emptyState.style.display = 'none';
  }
}

// X Comm Blacklist functionality
async function setupXcommBlacklist() {
  const addBtn = document.getElementById('addXcommBlacklistBtn');
  const input = document.getElementById('xcommBlacklistUsernameInput');
  const clearAllBtn = document.getElementById('clearAllXcommBlacklistBtn');
  const searchInput = document.getElementById('xcommBlacklistSearchInput');

  await loadXcommBlacklist();

  addBtn.addEventListener('click', () => addXcommBlacklist());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addXcommBlacklist();
  });

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllXcommBlacklist());
  }

  if (searchInput) {
    // Debounce search input to improve performance
    searchInput.addEventListener('input', debounce((e) => filterXcommBlacklist(e.target.value), 150));
  }
}

async function loadXcommBlacklist() {
  let blacklist = await getBlacklistAdmins();

  // Filter out invalid entries - only require username, image is optional
  const validBlacklist = blacklist.filter(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    return username && username !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validBlacklist.length !== blacklist.length) {
    await saveBlacklistAdmins(validBlacklist);
    blacklist = validBlacklist;
  }

  const container = document.getElementById('xcommBlacklistList');
  if (!container) {
    console.error('xcommBlacklistList container not found');
    return;
  }

  if (blacklist.length === 0) {
    container.innerHTML = '<div class="empty-state">No blacklisted admins yet. Add one above!</div>';
    const searchInput = document.getElementById('xcommBlacklistSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterXcommBlacklist(searchInput.value);
    }
    return;
  }

  container.innerHTML = blacklist.map(admin => {
    const username = admin.username || admin.userName || admin.screen_name;
    const image = admin.profileImage || admin.profilePicture || admin.profile_image_url_https || chrome.runtime.getURL('icons/icon48.png');
    const followers = admin.followersCount || admin.followers || admin.followers_count || 0;
    const name = admin.name;

    let infoHtml = `<div class="tracked-admin-username">@${username}</div>`;
    if (name && name !== username) {
      infoHtml += `<div class="tracked-admin-name">${escapeHtml(name)}</div>`;
    }
    infoHtml += `<div class="tracked-admin-followers">${formatFollowerCount(followers)} followers</div>`;

    return `
    <div class="tracked-admin-card blacklist-card" data-username="${username}">
      <img src="${image}" alt="${username}" class="tracked-admin-avatar" data-fallback="true">
      <div class="tracked-admin-info">
        ${infoHtml}
      </div>
      <button class="tracked-admin-remove" data-username="${username}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
    `;
  }).join('');

  // Add error handlers for images with avatar refresh
  container.querySelectorAll('.tracked-admin-avatar[data-fallback]').forEach(img => {
    const username = img.getAttribute('alt');
    if (username && username !== 'Admin') {
      setupAvatarErrorHandler(img, username, 'blacklist');
    } else {
      img.addEventListener('error', function() {
        this.src = chrome.runtime.getURL('icons/icon48.png');
        this.removeAttribute('data-fallback');
      });
    }
  });

  document.querySelectorAll('#xcommBlacklistList .blacklist-card .tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const username = e.currentTarget.getAttribute('data-username');
      removeXcommBlacklist(username);
    });
  });

  const searchInput = document.getElementById('xcommBlacklistSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterXcommBlacklist(searchInput.value);
  }
}

async function addXcommBlacklist() {
  const input = document.getElementById('xcommBlacklistUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const blacklist = await getBlacklistAdmins();
  const existingAdmin = blacklist.find(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername && adminUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingAdmin) {
    input.value = '';
    return;
  }

  const addBtn = document.getElementById('addXcommBlacklistBtn');
  input.disabled = true;
  addBtn.classList.add('loading');

  try {
    const profileData = await fetchUserProfile(username);

    const admin = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      addedAt: Date.now()
    };

    blacklist.push(admin);
    await saveBlacklistAdmins(blacklist);
    await loadXcommBlacklist();

    input.value = '';
  } catch (error) {
    console.error('Error adding blacklist admin:', error);
    alert(`Failed to add blacklist admin: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  addBtn.classList.remove('loading');
}

async function removeXcommBlacklist(username) {
  const blacklist = await getBlacklistAdmins();
  const filtered = blacklist.filter(a => {
    const adminUsername = a.username || a.userName || a.screen_name;
    return adminUsername !== username;
  });
  await saveBlacklistAdmins(filtered);
  await loadXcommBlacklist();
}

async function clearAllXcommBlacklist() {
  if (confirm('Are you sure you want to remove all blacklisted admins?')) {
    await saveBlacklistAdmins([]);
    await loadXcommBlacklist();
  }
}

function filterXcommBlacklist(query) {
  const container = document.getElementById('xcommBlacklistList');
  const adminCards = container.querySelectorAll('.blacklist-card');
  const emptyState = container.querySelector('.empty-state');

  if (!query || query.trim() === '') {
    adminCards.forEach(card => {
      card.style.display = 'flex';
    });

    if (emptyState) {
      const emptyText = emptyState.textContent;
      if (emptyText.includes('matching your search')) {
        emptyState.style.display = 'none';
      } else if (adminCards.length > 0) {
        emptyState.style.display = 'none';
      } else {
        emptyState.style.display = 'block';
      }
    }
    return;
  }

  const lowerQuery = query.toLowerCase().trim();
  let visibleCount = 0;

  adminCards.forEach(card => {
    const username = card.getAttribute('data-username') || '';
    const usernameElement = card.querySelector('.tracked-admin-username');
    const nameElement = card.querySelector('.tracked-admin-name');

    const usernameText = usernameElement?.textContent || '';
    const nameText = nameElement?.textContent || '';

    const matches =
      username.toLowerCase().includes(lowerQuery) ||
      usernameText.toLowerCase().includes(lowerQuery) ||
      nameText.toLowerCase().includes(lowerQuery);

    if (matches) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  if (visibleCount === 0) {
    if (!emptyState) {
      const noResults = document.createElement('div');
      noResults.className = 'empty-state';
      noResults.textContent = 'No admins found matching your search.';
      container.appendChild(noResults);
    } else {
      emptyState.textContent = 'No admins found matching your search.';
      emptyState.style.display = 'block';
    }
  } else if (emptyState) {
    emptyState.style.display = 'none';
  }
}

// Tweets Tracked functionality
async function setupTweetsTracked() {
  const addBtn = document.getElementById('addTweetBtn');
  const input = document.getElementById('tweetUsernameInput');
  const clearAllBtn = document.getElementById('clearAllTweetsBtn');
  const searchInput = document.getElementById('tweetSearchInput');

  await loadTweetsTracked();

  addBtn.addEventListener('click', () => addTweetTracked());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTweetTracked();
  });

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllTweetsTracked());
  }

  if (searchInput) {
    // Debounce search input to improve performance
    searchInput.addEventListener('input', debounce((e) => filterTweetsTracked(e.target.value), 150));
  }
}

async function loadTweetsTracked() {
  let tweets = await getTrackedTweets();

  // Filter out invalid entries
  const validTweets = tweets.filter(tweet => {
    const username = tweet.username || tweet.userName || tweet.screen_name;
    return username && username !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validTweets.length !== tweets.length) {
    await saveTrackedTweets(validTweets);
    tweets = validTweets;
  }

  const container = document.getElementById('tweetsTrackedList');
  if (!container) {
    return;
  }

  if (tweets.length === 0) {
    container.innerHTML = '<div class="empty-state">No tracked tweets yet. Add one above!</div>';
    const searchInput = document.getElementById('tweetSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterTweetsTracked(searchInput.value);
    }
    return;
  }

  container.innerHTML = tweets.map(tweet => {
    const username = tweet.username || tweet.userName || tweet.screen_name;
    const profileImage = tweet.profileImage || tweet.profilePicture || tweet.profile_image_url_https || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png';
    const followersCount = tweet.followersCount || tweet.followers || tweet.followers_count || 0;
    const name = tweet.name || username;

    return `
      <div class="tracked-admin-card" data-username="${escapeHtml(username)}">
        <img class="tracked-admin-avatar" src="${escapeHtml(profileImage)}" data-default="https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png">
        <div class="tracked-admin-info">
          <div class="tracked-admin-username">@${escapeHtml(username)}</div>
          <div class="tracked-admin-name">${escapeHtml(name)}</div>
          <div class="tracked-admin-followers">${formatFollowerCount(followersCount)} followers</div>
        </div>
        <button class="tracked-admin-remove" data-username="${escapeHtml(username)}">✕</button>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', () => removeTweetTracked(btn.getAttribute('data-username')));
  });

  // Add image error handlers
  container.querySelectorAll('.tracked-admin-avatar').forEach(img => {
    img.addEventListener('error', () => {
      const defaultSrc = img.getAttribute('data-default');
      if (defaultSrc && img.src !== defaultSrc) {
        img.src = defaultSrc;
      }
    });
  });

  const searchInput = document.getElementById('tweetSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterTweetsTracked(searchInput.value);
  }
}

async function addTweetTracked() {
  const input = document.getElementById('tweetUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const tweets = await getTrackedTweets();
  const existingTweet = tweets.find(t => {
    const tweetUsername = t.username || t.userName || t.screen_name;
    return tweetUsername && tweetUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingTweet) {
    input.value = '';
    return;
  }

  const addBtn = document.getElementById('addTweetBtn');
  input.disabled = true;
  addBtn.classList.add('loading');

  try {
    const profileData = await fetchUserProfile(username);

    const tweet = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      addedAt: Date.now()
    };

    tweets.push(tweet);
    await saveTrackedTweets(tweets);
    await loadTweetsTracked();

    input.value = '';
  } catch (error) {
    console.error('Error adding tracked tweet:', error);
    alert(`Failed to add tracked tweet: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  addBtn.classList.remove('loading');
}

async function removeTweetTracked(username) {
  const tweets = await getTrackedTweets();
  const filtered = tweets.filter(t => {
    const tweetUsername = t.username || t.userName || t.screen_name;
    return tweetUsername !== username;
  });
  await saveTrackedTweets(filtered);
  await loadTweetsTracked();
}

async function clearAllTweetsTracked() {
  if (confirm('Are you sure you want to remove all tracked tweets?')) {
    await saveTrackedTweets([]);
    await loadTweetsTracked();
  }
}

function filterTweetsTracked(query) {
  const container = document.getElementById('tweetsTrackedList');
  if (!container) return;

  const cards = container.querySelectorAll('.tracked-admin-card');
  const normalizedQuery = query.toLowerCase().trim();

  cards.forEach(card => {
    const username = card.getAttribute('data-username').toLowerCase();
    const displayName = card.querySelector('.tracked-admin-name')?.textContent.toLowerCase() || '';

    if (username.includes(normalizedQuery) || displayName.includes(normalizedQuery)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// Tweets Blacklist functionality
async function setupTweetsBlacklist() {
  const addBtn = document.getElementById('addTweetBlacklistBtn');
  const input = document.getElementById('tweetBlacklistUsernameInput');
  const clearAllBtn = document.getElementById('clearAllTweetsBlacklistBtn');
  const searchInput = document.getElementById('tweetBlacklistSearchInput');

  await loadTweetsBlacklist();

  addBtn.addEventListener('click', () => addTweetBlacklist());
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTweetBlacklist();
  });

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => clearAllTweetsBlacklist());
  }

  if (searchInput) {
    // Debounce search input to improve performance
    searchInput.addEventListener('input', debounce((e) => filterTweetsBlacklist(e.target.value), 150));
  }
}

async function loadTweetsBlacklist() {
  let blacklist = await getBlacklistedTweets();

  // Filter out invalid entries - only require username, image is optional
  const validBlacklist = blacklist.filter(tweet => {
    const username = tweet.username || tweet.userName || tweet.screen_name;
    return username && username !== 'undefined';
  });

  // If we filtered out invalid entries, save the cleaned list
  if (validBlacklist.length !== blacklist.length) {
    await saveBlacklistedTweets(validBlacklist);
    blacklist = validBlacklist;
  }

  const container = document.getElementById('tweetsBlacklistList');
  if (!container) {
    console.error('tweetsBlacklistList container not found');
    return;
  }

  if (blacklist.length === 0) {
    container.innerHTML = '<div class="empty-state">No blacklisted tweets yet. Add one above!</div>';
    const searchInput = document.getElementById('tweetBlacklistSearchInput');
    if (searchInput && searchInput.value.trim()) {
      filterTweetsBlacklist(searchInput.value);
    }
    return;
  }

  container.innerHTML = blacklist.map(tweet => {
    const username = tweet.username || tweet.userName || tweet.screen_name;
    const image = tweet.profileImage || tweet.profilePicture || tweet.profile_image_url_https || chrome.runtime.getURL('icons/icon48.png');
    const followers = tweet.followersCount || tweet.followers || tweet.followers_count || 0;
    const name = tweet.name;

    let infoHtml = `<div class="tracked-admin-username">@${username}</div>`;
    if (name && name !== username) {
      infoHtml += `<div class="tracked-admin-name">${escapeHtml(name)}</div>`;
    }
    infoHtml += `<div class="tracked-admin-followers">${formatFollowerCount(followers)} followers</div>`;

    return `
    <div class="tracked-admin-card blacklist-card" data-username="${username}">
      <img src="${image}" alt="${username}" class="tracked-admin-avatar">
      <div class="tracked-admin-info">
        ${infoHtml}
      </div>
      <button class="tracked-admin-remove" data-username="${username}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
    `;
  }).join('');

  document.querySelectorAll('#tweetsBlacklistList .blacklist-card .tracked-admin-remove').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const username = e.currentTarget.getAttribute('data-username');
      removeTweetBlacklist(username);
    });
  });

  const searchInput = document.getElementById('tweetBlacklistSearchInput');
  if (searchInput && searchInput.value.trim()) {
    filterTweetsBlacklist(searchInput.value);
  }
}

async function addTweetBlacklist() {
  const input = document.getElementById('tweetBlacklistUsernameInput');
  const username = input.value.trim().replace('@', '');

  if (!username) return;

  const blacklist = await getBlacklistedTweets();
  const existingTweet = blacklist.find(t => {
    const tweetUsername = t.username || t.userName || t.screen_name;
    return tweetUsername && tweetUsername.toLowerCase() === username.toLowerCase();
  });
  if (existingTweet) {
    input.value = '';
    return;
  }

  const addBtn = document.getElementById('addTweetBlacklistBtn');
  input.disabled = true;
  addBtn.classList.add('loading');

  try {
    const profileData = await fetchUserProfile(username);

    const tweet = {
      username: profileData.userName || profileData.screen_name,
      profileImage: profileData.profilePicture || profileData.profile_image_url_https,
      followersCount: profileData.followers || profileData.followers_count,
      name: profileData.name,
      addedAt: Date.now()
    };

    blacklist.push(tweet);
    await saveBlacklistedTweets(blacklist);
    await loadTweetsBlacklist();

    input.value = '';
  } catch (error) {
    console.error('Error adding tweet blacklist:', error);
    alert(`Failed to add tweet blacklist: ${error.message || 'Unknown error'}`);
  }

  input.disabled = false;
  addBtn.classList.remove('loading');
}

async function removeTweetBlacklist(username) {
  const blacklist = await getBlacklistedTweets();
  const filtered = blacklist.filter(t => {
    const tweetUsername = t.username || t.userName || t.screen_name;
    return tweetUsername !== username;
  });
  await saveBlacklistedTweets(filtered);
  await loadTweetsBlacklist();
}

async function clearAllTweetsBlacklist() {
  if (confirm('Are you sure you want to remove all blacklisted tweets?')) {
    await saveBlacklistedTweets([]);
    await loadTweetsBlacklist();
  }
}

function filterTweetsBlacklist(query) {
  const container = document.getElementById('tweetsBlacklistList');
  const adminCards = container.querySelectorAll('.blacklist-card');
  const emptyState = container.querySelector('.empty-state');

  if (!query || query.trim() === '') {
    adminCards.forEach(card => {
      card.style.display = 'flex';
    });

    if (emptyState) {
      const emptyText = emptyState.textContent;
      if (emptyText.includes('matching your search')) {
        emptyState.style.display = 'none';
      } else if (adminCards.length > 0) {
        emptyState.style.display = 'none';
      } else {
        emptyState.style.display = 'block';
      }
    }
    return;
  }

  const lowerQuery = query.toLowerCase().trim();
  let visibleCount = 0;

  adminCards.forEach(card => {
    const username = card.getAttribute('data-username') || '';
    const usernameElement = card.querySelector('.tracked-admin-username');
    const nameElement = card.querySelector('.tracked-admin-name');

    const usernameText = usernameElement?.textContent || '';
    const nameText = nameElement?.textContent || '';

    const matches =
      username.toLowerCase().includes(lowerQuery) ||
      usernameText.toLowerCase().includes(lowerQuery) ||
      nameText.toLowerCase().includes(lowerQuery);

    if (matches) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  if (visibleCount === 0) {
    if (!emptyState) {
      const noResults = document.createElement('div');
      noResults.className = 'empty-state';
      noResults.textContent = 'No tweets found matching your search.';
      container.appendChild(noResults);
    } else {
      emptyState.textContent = 'No tweets found matching your search.';
      emptyState.style.display = 'block';
    }
  } else if (emptyState) {
    emptyState.style.display = 'none';
  }
}

// Storage helper functions for tweets
async function getTrackedTweets() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['trackedTweets'], (result) => {
      resolve(result.trackedTweets || []);
    });
  });
}

async function saveTrackedTweets(tweets) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ trackedTweets: tweets }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

async function getBlacklistedTweets() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['blacklistedTweets'], (result) => {
      resolve(result.blacklistedTweets || []);
    });
  });
}

async function saveBlacklistedTweets(tweets) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ blacklistedTweets: tweets }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

// Gradient Controls
async function setupGradientControls() {
  const settings = await loadSettings();

  // Communities/Admins controls
  const opacitySlider = document.getElementById('trackedGradientOpacity');
  const opacityValue = document.getElementById('gradientOpacityValue');
  const borderColorInput = document.getElementById('trackedBorderColor');
  const gradientColorInput = document.getElementById('trackedGradientColor');
  const normalAdminColorInput = document.getElementById('normalAdminColor');

  // Tweets-specific controls
  const tweetsGradientEnabledToggle = document.getElementById('tweetsGradientEnabled');
  const tweetsShowOverlayToggle = document.getElementById('tweetsShowOverlay');
  const tweetsBorderColorInput = document.getElementById('tweetsBorderColor');
  const tweetsGradientColorInput = document.getElementById('tweetsGradientColor');
  const tweetsOpacitySlider = document.getElementById('tweetsGradientOpacity');
  const tweetsOpacityValue = document.getElementById('tweetsGradientOpacityValue');

  // Set initial values for Communities/Admins
  if (opacitySlider && settings.trackedGradientOpacity !== undefined) {
    opacitySlider.value = settings.trackedGradientOpacity;
    if (opacityValue) {
      opacityValue.textContent = settings.trackedGradientOpacity + '%';
    }
  }

  if (borderColorInput && settings.trackedBorderColor) {
    borderColorInput.value = settings.trackedBorderColor;
  }

  if (gradientColorInput && settings.trackedGradientColor) {
    gradientColorInput.value = settings.trackedGradientColor;
  }

  if (normalAdminColorInput && settings.normalAdminColor) {
    normalAdminColorInput.value = settings.normalAdminColor;
  }

  // Set initial values for Tweets
  if (tweetsGradientEnabledToggle) {
    tweetsGradientEnabledToggle.checked = settings.tweetsGradientEnabled ?? true;
  }

  if (tweetsShowOverlayToggle) {
    tweetsShowOverlayToggle.checked = settings.tweetsShowOverlay ?? true;
  }

  if (tweetsBorderColorInput && settings.tweetsBorderColor) {
    tweetsBorderColorInput.value = settings.tweetsBorderColor;
  }

  if (tweetsGradientColorInput && settings.tweetsGradientColor) {
    tweetsGradientColorInput.value = settings.tweetsGradientColor;
  }

  if (tweetsOpacitySlider && settings.tweetsGradientOpacity !== undefined) {
    tweetsOpacitySlider.value = settings.tweetsGradientOpacity;
    if (tweetsOpacityValue) {
      tweetsOpacityValue.textContent = settings.tweetsGradientOpacity + '%';
    }
  }

  // Communities/Admins event handlers
  if (opacitySlider) {
    opacitySlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      opacityValue.textContent = value + '%';
      await saveSetting('trackedGradientOpacity', parseInt(value));
      updateGradientPreview();
    });
  }

  if (borderColorInput) {
    borderColorInput.addEventListener('change', async (e) => {
      await saveSetting('trackedBorderColor', e.target.value);
      updateGradientPreview();
    });
  }

  if (gradientColorInput) {
    gradientColorInput.addEventListener('change', async (e) => {
      await saveSetting('trackedGradientColor', e.target.value);
      updateGradientPreview();
    });
  }

  if (normalAdminColorInput) {
    normalAdminColorInput.addEventListener('change', async (e) => {
      await saveSetting('normalAdminColor', e.target.value);
    });
  }

  // Note: gradientEnabledToggle, adminBgEnabledToggle, tweetsGradientEnabledToggle,
  // and tweetsShowOverlayToggle are handled by setupSettingRows() via data-checkbox-id attribute

  if (tweetsBorderColorInput) {
    tweetsBorderColorInput.addEventListener('change', async (e) => {
      await saveSetting('tweetsBorderColor', e.target.value);
    });
  }

  if (tweetsGradientColorInput) {
    tweetsGradientColorInput.addEventListener('change', async (e) => {
      await saveSetting('tweetsGradientColor', e.target.value);
    });
  }

  if (tweetsOpacitySlider) {
    tweetsOpacitySlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      tweetsOpacityValue.textContent = value + '%';
      await saveSetting('tweetsGradientOpacity', parseInt(value));
    });
  }

  // Score Alert controls
  const scoreAlertBorderColorInput = document.getElementById('scoreAlertBorderColor');
  const scoreAlertGradientColorInput = document.getElementById('scoreAlertGradientColor');
  const scoreAlertOpacitySlider = document.getElementById('scoreAlertGradientOpacity');
  const scoreAlertOpacityValue = document.getElementById('scoreAlertGradientOpacityValue');

  // Set initial values for Score Alert
  if (scoreAlertBorderColorInput) {
    scoreAlertBorderColorInput.value = settings.scoreAlertBorderColor ?? '#10b981';
  }

  if (scoreAlertGradientColorInput) {
    scoreAlertGradientColorInput.value = settings.scoreAlertGradientColor ?? '#10b981';
  }

  if (scoreAlertOpacitySlider) {
    const opacityValueToUse = settings.scoreAlertGradientOpacity ?? 20;
    scoreAlertOpacitySlider.value = opacityValueToUse;
    if (scoreAlertOpacityValue) {
      scoreAlertOpacityValue.textContent = opacityValueToUse + '%';
    }
  }

  // Score Alert event handlers
  if (scoreAlertBorderColorInput) {
    scoreAlertBorderColorInput.addEventListener('change', async (e) => {
      await saveSetting('scoreAlertBorderColor', e.target.value);
    });
  }

  if (scoreAlertGradientColorInput) {
    scoreAlertGradientColorInput.addEventListener('change', async (e) => {
      await saveSetting('scoreAlertGradientColor', e.target.value);
    });
  }

  if (scoreAlertOpacitySlider) {
    scoreAlertOpacitySlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      scoreAlertOpacityValue.textContent = value + '%';
      await saveSetting('scoreAlertGradientOpacity', parseInt(value));
    });
  }

  updateGradientPreview();

  // CRITICAL FIX: Broadcast initial color values to ensure content scripts apply colors on first install
  // This fixes the issue where colors don't appear until the user manually moves the color picker
  await chrome.storage.sync.set({
    normalAdminColor: settings.normalAdminColor ?? '#1a1a2e',
    trackedGradientColor: settings.trackedGradientColor ?? '#22d3ee',
    trackedBorderColor: settings.trackedBorderColor ?? '#22d3ee',
    trackedGradientOpacity: settings.trackedGradientOpacity ?? 20
  });
}

// Listen for sync storage changes to update UI controls
// This handles settings changes from import, browse configs, etc.
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    // Visual settings that need UI updates
    const visualSettingsKeys = [
      'trackedGradientOpacity',
      'trackedBorderColor',
      'trackedGradientColor',
      'normalAdminColor',
      'tweetsGradientEnabled',
      'tweetsShowOverlay',
      'tweetsBorderColor',
      'tweetsGradientColor',
      'tweetsGradientOpacity',
      'scoreAlertBorderColor',
      'scoreAlertGradientColor',
      'scoreAlertGradientOpacity',
      'scoreAlertGradientEnabled',
      'adminAlertVolume'
    ];

    const hasVisualChange = Object.keys(changes).some(key => visualSettingsKeys.includes(key));

    if (hasVisualChange) {
      // Update UI controls with new values
      updateVisualControlsFromStorage();
    }
  }
});

// Function to refresh all visual controls from current storage values
async function updateVisualControlsFromStorage() {
  const settings = await loadSettings();

  // Communities/Admins controls
  const opacitySlider = document.getElementById('trackedGradientOpacity');
  const opacityValue = document.getElementById('gradientOpacityValue');
  const borderColorInput = document.getElementById('trackedBorderColor');
  const gradientColorInput = document.getElementById('trackedGradientColor');
  const gradientEnabledToggle = document.getElementById('trackedGradientEnabled');
  const adminBgEnabledToggle = document.getElementById('adminBackgroundEnabled');
  const normalAdminColorInput = document.getElementById('normalAdminColor');

  // Tweets controls
  const tweetsGradientEnabledToggle = document.getElementById('tweetsGradientEnabled');
  const tweetsShowOverlayToggle = document.getElementById('tweetsShowOverlay');
  const tweetsBorderColorInput = document.getElementById('tweetsBorderColor');
  const tweetsGradientColorInput = document.getElementById('tweetsGradientColor');
  const tweetsOpacitySlider = document.getElementById('tweetsGradientOpacity');
  const tweetsOpacityValue = document.getElementById('tweetsGradientOpacityValue');

  // Score Alert controls
  const scoreAlertBorderColorInput = document.getElementById('scoreAlertBorderColor');
  const scoreAlertGradientColorInput = document.getElementById('scoreAlertGradientColor');
  const scoreAlertOpacitySlider = document.getElementById('scoreAlertGradientOpacity');
  const scoreAlertOpacityValue = document.getElementById('scoreAlertGradientOpacityValue');

  // Update Communities/Admins controls
  if (opacitySlider && settings.trackedGradientOpacity !== undefined) {
    opacitySlider.value = settings.trackedGradientOpacity;
    if (opacityValue) opacityValue.textContent = settings.trackedGradientOpacity + '%';
  }

  if (borderColorInput && settings.trackedBorderColor) {
    borderColorInput.value = settings.trackedBorderColor;
  }

  if (gradientColorInput && settings.trackedGradientColor) {
    gradientColorInput.value = settings.trackedGradientColor;
  }

  if (normalAdminColorInput && settings.normalAdminColor) {
    normalAdminColorInput.value = settings.normalAdminColor;
  }

  // Update Tweets controls
  if (tweetsGradientEnabledToggle && tweetsGradientEnabledToggle.checked !== (settings.tweetsGradientEnabled ?? true)) {
    tweetsGradientEnabledToggle.checked = settings.tweetsGradientEnabled ?? true;
  }

  if (tweetsShowOverlayToggle && tweetsShowOverlayToggle.checked !== (settings.tweetsShowOverlay ?? true)) {
    tweetsShowOverlayToggle.checked = settings.tweetsShowOverlay ?? true;
  }

  if (tweetsBorderColorInput && settings.tweetsBorderColor) {
    tweetsBorderColorInput.value = settings.tweetsBorderColor;
  }

  if (tweetsGradientColorInput && settings.tweetsGradientColor) {
    tweetsGradientColorInput.value = settings.tweetsGradientColor;
  }

  if (tweetsOpacitySlider && settings.tweetsGradientOpacity !== undefined) {
    tweetsOpacitySlider.value = settings.tweetsGradientOpacity;
    if (tweetsOpacityValue) tweetsOpacityValue.textContent = settings.tweetsGradientOpacity + '%';
  }

  // Update Score Alert controls
  if (scoreAlertBorderColorInput) {
    scoreAlertBorderColorInput.value = settings.scoreAlertBorderColor ?? '#10b981';
  }

  if (scoreAlertGradientColorInput) {
    scoreAlertGradientColorInput.value = settings.scoreAlertGradientColor ?? '#10b981';
  }

  if (scoreAlertOpacitySlider) {
    const opacityValueToUse = settings.scoreAlertGradientOpacity ?? 20;
    scoreAlertOpacitySlider.value = opacityValueToUse;
    if (scoreAlertOpacityValue) {
      scoreAlertOpacityValue.textContent = opacityValueToUse + '%';
    }
  }

  // Update preview
  updateGradientPreview();
}

async function updateGradientPreview() {
  const settings = await loadSettings();
  const preview = document.getElementById('gradientPreview');
  const borderColor = settings.trackedBorderColor || '#22d3ee';
  const gradientColor = settings.trackedGradientColor || '#22d3ee';
  const opacity = (settings.trackedGradientOpacity || 20) / 100;

  if (preview) {
    preview.style.borderColor = borderColor;

    const afterStyle = preview.querySelector('style') || document.createElement('style');
    afterStyle.textContent = `
      #gradientPreview::after {
        background: linear-gradient(to left, ${hexToRgba(gradientColor, opacity)}, transparent) !important;
      }
    `;
    if (!preview.querySelector('style')) {
      preview.appendChild(afterStyle);
    }
  }
}

function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// Admin Alert Controls
async function setupAdminAlertControls() {
  const settings = await loadSettings();
  const enabledCheckbox = document.getElementById('adminAlertEnabled');
  const volumeSlider = document.getElementById('adminAlertVolume');
  const volumeValue = document.getElementById('adminAlertVolumeValue');
  const testButton = document.getElementById('testAdminAlertSound');
  const resetButton = document.getElementById('resetAdminAlertFlag');
  const statusDiv = document.getElementById('adminAlertStatus');
  const statusText = statusDiv ? statusDiv.querySelector('.admin-alert-status-text') : null;

  // Set initial values
  if (enabledCheckbox) {
    enabledCheckbox.checked = settings.adminAlertEnabled || false;
  }
  if (volumeSlider && settings.adminAlertVolume !== undefined) {
    volumeSlider.value = settings.adminAlertVolume;
    if (volumeValue) {
      volumeValue.textContent = settings.adminAlertVolume + '%';
    }
  }

  // Create audio element for testing
  let audioElement = null;

  function getAudioElement() {
    if (!audioElement) {
      audioElement = new Audio();
      audioElement.preload = 'auto';
      const customSound = settings.adminAlertCustomSound;
      audioElement.src = customSound || chrome.runtime.getURL('Sounds/admin-alert.mp3');
    }
    return audioElement;
  }

  // Toggle enabled
  if (enabledCheckbox) {
    enabledCheckbox.addEventListener('change', async (e) => {
      await saveSetting('adminAlertEnabled', e.target.checked);
      if (e.target.checked && !audioUnlocked) {
        // Try to unlock audio when enabling
        const audio = getAudioElement();
        audio.volume = 0.01;
        audio.muted = true;
        try {
          await audio.play();
          audio.pause();
          audio.currentTime = 0;
          audio.muted = false;
          audioUnlocked = true;
        } catch (err) {
          // Will be unlocked on test button
        }
      }
      updateAdminAlertStatus();
    });
  }

  // Volume slider
  if (volumeSlider) {
    volumeSlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      if (volumeValue) {
        volumeValue.textContent = value + '%';
      }
    });

    volumeSlider.addEventListener('change', async (e) => {
      await saveSetting('adminAlertVolume', parseInt(e.target.value));
    });
  }

  // Test sound button
  if (testButton) {
    testButton.addEventListener('click', async () => {
      const audio = getAudioElement();
      // Reload settings to get current volume
      const currentSettings = await loadSettings();
      const volume = currentSettings.adminAlertVolume / 100;
      audio.volume = volume;

      // Try to unlock if not already
      if (!audioUnlocked) {
        audio.volume = 0.01;
        audio.muted = true;
        try {
          await audio.play();
          audio.pause();
          audio.currentTime = 0;
          audio.muted = false;
          audioUnlocked = true;
          // Signal to content scripts that audio is unlocked
          chrome.storage.local.set({ adminAlertAudioUnlocked: true });
        } catch (err) {
          audio.muted = false;
        }
      }

      audio.volume = volume;
      try {
        await audio.play();
        showAdminAlertStatus('Sound played!', 'success');
      } catch (error) {
        showAdminAlertStatus('Error: ' + error.message, 'error');
      }
    });
  }

  // Reset session button
  if (resetButton) {
    resetButton.addEventListener('click', async () => {
      hasPlayedAdminAlert = false;
      // Signal to content scripts via storage
      await chrome.storage.local.set({ adminAlertPlayedThisSession: false });
      showAdminAlertStatus('Session flag reset - sound will play on next tracked admin', 'success');
      setTimeout(() => {
        if (statusDiv) statusDiv.style.display = 'none';
      }, 3000);
    });
  }

  // Check storage for played flag
  chrome.storage.local.get(['adminAlertPlayedThisSession'], (result) => {
    hasPlayedAdminAlert = result.adminAlertPlayedThisSession || false;
    updateAdminAlertStatus();
  });

  // Listen for storage changes from content script
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.adminAlertPlayedThisSession) {
      hasPlayedAdminAlert = changes.adminAlertPlayedThisSession.newValue;
      updateAdminAlertStatus();
    }
  });

  function updateAdminAlertStatus() {
    if (!statusDiv || !statusText) return;

    const enabled = enabledCheckbox ? enabledCheckbox.checked : false;
    if (!enabled) {
      statusDiv.style.display = 'none';
      return;
    }

    if (hasPlayedAdminAlert) {
      showAdminAlertStatus('Already played this session', 'info');
    } else if (!audioUnlocked) {
      showAdminAlertStatus('Click Test Sound to enable alerts', 'warning');
    } else {
      showAdminAlertStatus('Ready to play on next tracked admin', 'success');
    }
  }

  function showAdminAlertStatus(message, type) {
    if (!statusDiv || !statusText) return;
    statusText.textContent = message;
    statusDiv.className = 'setting-row admin-alert-status';
    statusDiv.classList.add('status-' + type);
    statusDiv.style.display = 'flex';
  }

  // Initial status update
  updateAdminAlertStatus();
}

// Score Alert Controls
async function setupScoreAlertControls() {
  const settings = await loadSettings();
  const enabledCheckbox = document.getElementById('scoreAlertEnabled');
  const thresholdSlider = document.getElementById('scoreAlertThreshold');
  const thresholdValue = document.getElementById('scoreAlertThresholdValue');
  const volumeSlider = document.getElementById('scoreAlertVolume');
  const volumeValue = document.getElementById('scoreAlertVolumeValue');
  const testButton = document.getElementById('testScoreAlert');

  // Set initial values
  if (enabledCheckbox) {
    enabledCheckbox.checked = settings.scoreAlertEnabled || false;
  }
  if (thresholdSlider) {
    const thresholdValueToUse = settings.scoreAlertThreshold ?? 2;
    thresholdSlider.value = thresholdValueToUse;
    if (thresholdValue) {
      thresholdValue.textContent = thresholdValueToUse;
    }
  }
  if (volumeSlider) {
    const volumeValueToUse = settings.scoreAlertVolume ?? 50;
    volumeSlider.value = volumeValueToUse;
    if (volumeValue) {
      volumeValue.textContent = volumeValueToUse + '%';
    }
  }

  // Toggle enabled
  if (enabledCheckbox) {
    enabledCheckbox.addEventListener('change', async (e) => {
      await saveSetting('scoreAlertEnabled', e.target.checked);
    });
  }

  // Threshold slider
  if (thresholdSlider) {
    thresholdSlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      if (thresholdValue) {
        thresholdValue.textContent = value;
      }
    });

    thresholdSlider.addEventListener('change', async (e) => {
      await saveSetting('scoreAlertThreshold', parseInt(e.target.value));
    });
  }

  // Volume slider
  if (volumeSlider) {
    volumeSlider.addEventListener('input', async (e) => {
      const value = e.target.value;
      if (volumeValue) {
        volumeValue.textContent = value + '%';
      }
    });

    volumeSlider.addEventListener('change', async (e) => {
      await saveSetting('scoreAlertVolume', parseInt(e.target.value));
    });
  }

  // Test sound button - send message to content script
  if (testButton) {
    testButton.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'testScoreAlert' });
          // Brief visual feedback
          const originalText = testButton.textContent;
          testButton.textContent = 'Playing...';
          testButton.disabled = true;
          setTimeout(() => {
            testButton.textContent = originalText;
            testButton.disabled = false;
          }, 1000);
        } catch (error) {
          console.error('Failed to send test message:', error);
          testButton.textContent = 'Error - Try on a valid page';
          setTimeout(() => {
            testButton.textContent = 'Test Score Alert Sound';
          }, 2000);
        }
      }
    });
  }
}

// Sheets Sync Status
function setupSheetsSyncStatus() {
  const syncBtn = document.getElementById('syncSheetsNow');
  const testBtn = document.getElementById('testSheetsConnection');

  if (syncBtn) {
    syncBtn.addEventListener('click', async () => {
      if (sheetsSyncInProgress) return;

      syncBtn.disabled = true;
      syncBtn.textContent = 'Syncing...';
      sheetsSyncInProgress = true;

      try {
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'syncSheetsNow' },
            (response) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(response);
              }
            }
          );
        });

        if (response?.success) {
          syncBtn.textContent = 'Updated!';
          setTimeout(() => {
            syncBtn.disabled = false;
            syncBtn.textContent = 'Sync Now';
            updateSheetsSyncStatus();
          }, 1500);
        } else {
          throw new Error(response?.error || 'Sync failed');
        }
      } catch (error) {
        console.error('[Popup] Sheets sync failed:', error);
        syncBtn.textContent = 'Failed';
        setTimeout(() => {
          syncBtn.disabled = false;
          syncBtn.textContent = 'Sync Now';
        }, 2000);
      } finally {
        sheetsSyncInProgress = false;
      }
    });
  }

  if (testBtn) {
    testBtn.addEventListener('click', async () => {
      testBtn.disabled = true;
      testBtn.textContent = 'Testing...';

      try {
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'testSheetsConnection' },
            (response) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(response);
              }
            }
          );
        });

        if (response?.success) {
          testBtn.textContent = 'Connected!';
          setTimeout(() => {
            testBtn.disabled = false;
            testBtn.textContent = 'Test Connection';
          }, 1500);
        } else {
          throw new Error(response?.error || 'Connection failed');
        }
      } catch (error) {
        console.error('[Popup] Connection test failed:', error);
        testBtn.textContent = 'Failed';
        setTimeout(() => {
          testBtn.disabled = false;
          testBtn.textContent = 'Test Connection';
        }, 2000);
      }
    });
  }

  // Initial update
  updateSheetsSyncStatus();

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      if (changes.sheetsLastSync || changes.sheetsSyncError) {
        updateSheetsSyncStatus();
      }
    }
  });
}

function updateSheetsSyncStatus() {
  const lastSyncEl = document.getElementById('sheetsLastSync');
  if (!lastSyncEl) return;

  chrome.storage.local.get(['sheetsLastSync', 'sheetsSyncError'], (result) => {
    if (result.sheetsSyncError) {
      lastSyncEl.textContent = 'Error: ' + result.sheetsSyncError;
      lastSyncEl.style.color = '#ef4444';
    } else if (result.sheetsLastSync) {
      const lastSync = new Date(result.sheetsLastSync);
      const now = new Date();
      const diffMs = now - lastSync;
      const diffMins = Math.floor(diffMs / 60000);

      if (diffMins < 1) {
        lastSyncEl.textContent = 'Just now';
        lastSyncEl.style.color = '#10b981';
      } else if (diffMins < 60) {
        lastSyncEl.textContent = `${diffMins} min ago`;
        lastSyncEl.style.color = diffMins < 2 ? '#10b981' : '#fbbf24';
      } else if (diffMins < 1440) {
        const hours = Math.floor(diffMins / 60);
        lastSyncEl.textContent = `${hours} hour${hours > 1 ? 's' : ''} ago`;
        lastSyncEl.style.color = '#fbbf24';
      } else {
        const days = Math.floor(diffMins / 1440);
        lastSyncEl.textContent = `${days} day${days > 1 ? 's' : ''} ago`;
        lastSyncEl.style.color = '#ef4444';
      }
    } else {
      lastSyncEl.textContent = 'Never';
      lastSyncEl.style.color = '#888';
    }
  });
}

// Check for update notification
function checkForUpdateNotification() {
  chrome.storage.local.get(['pendingUpdateNotification', 'updateRequired', 'updateInfo'], (result) => {
    // Check both old format (pendingUpdateNotification) and new format (updateRequired)
    const updateData = result.updateInfo || result.pendingUpdateNotification;
    
    if (result.updateRequired || result.pendingUpdateNotification) {
      const banner = document.getElementById('updateNotificationBanner');
      const messageEl = document.getElementById('updateNotificationMessage');
      const downloadBtn = document.getElementById('downloadUpdateBtn');

      if (banner && messageEl) {
        messageEl.textContent = updateData?.message || 'An update is required to continue using Honed.';
        banner.style.display = 'block';

        // Download button is always visible now
        if (downloadBtn) {
          downloadBtn.style.display = 'inline-flex';
          downloadBtn.onclick = () => {
            const url = updateData?.downloadUrl || updateData?.download_url;
            if (url) {
              chrome.tabs.create({ url });
            }
          };
        }

        // If update is required, disable main content
        if (result.updateRequired) {
          const container = document.querySelector('.container');
          const licenseBanner = document.getElementById('licenseBanner');
          const licenseModal = document.getElementById('licenseModal');
          if (container) {
            container.style.opacity = '0.3';
            container.style.pointerEvents = 'none';
          }
          if (licenseBanner) {
            licenseBanner.style.opacity = '0.3';
            licenseBanner.style.pointerEvents = 'none';
          }
          // Hide license modal if open
          if (licenseModal) licenseModal.style.display = 'none';
        }
      }
    }
  });
}


// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);
