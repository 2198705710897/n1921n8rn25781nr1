/**
 * Admin Alert Audio Service
 * Plays alert sound when tracked admins create tokens
 *
 * Features:
 * - Plays sound every time when tracked admin creates token
 * - Configurable volume and custom sound support
 * - Preloads audio on first user interaction (click/scroll/touch)
 * - Uses standard HTML5 Audio element
 */

(function(window) {
  'use strict';

  /**
   * Admin Alert Audio Service Class
   */
  class AdminAlertAudioService {
    constructor() {
      // Audio element
      this.adminAudio = null;
      this.audioInitialized = false;

      // Current configuration
      this.config = {
        enabled: false,
        volume: 0.5,
        customSoundUrl: null
      };

      // Default sound URL
      this.defaultSoundUrl = this.getRuntimeURL('Sounds/admin-alert.mp3');

      // Initialize audio on first user interaction
      this.initAudioOnInteraction();
    }

    /**
     * Get runtime URL for extension resources
     * @param {string} path - Relative path from extension root
     * @returns {string} Runtime URL
     */
    getRuntimeURL(path) {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        return chrome.runtime.getURL(path);
      }
      if (typeof browser !== 'undefined' && browser.runtime) {
        return browser.runtime.getURL(path);
      }
      return path;
    }

    /**
     * Initialize audio on first user interaction
     * This bypasses Chrome's autoplay policy
     */
    initAudioOnInteraction() {
      const initAudio = () => {
        if (this.audioInitialized) return;

        try {
          const soundUrl = this.config.customSoundUrl || this.defaultSoundUrl;
          this.adminAudio = new Audio(soundUrl);
          this.adminAudio.volume = this.config.volume;
          this.adminAudio.load(); // Important: preloads the audio
          this.audioInitialized = true;
          console.log('[AdminAlertAudio] Audio preloaded successfully');
        } catch (error) {
          console.error('[AdminAlertAudio] Failed to preload audio:', error);
        }
      };

      // Initialize on any user interaction
      const events = ['click', 'keydown', 'scroll', 'touchstart'];
      events.forEach(event => {
        document.addEventListener(event, initAudio, { once: true, passive: true });
      });
    }

    /**
     * Configure the audio service with settings
     *
     * @param {Object} options - Configuration options
     * @param {boolean} options.enabled - Whether admin alert sound is enabled
     * @param {number} options.volume - Volume level (0.0 to 1.0)
     * @param {string|null} options.customSoundUrl - URL to custom sound file, or null for default
     */
    configure(options = {}) {
      // Update configuration
      if (typeof options.enabled === 'boolean') {
        this.config.enabled = options.enabled;
        // Save to storage
        chrome.storage.local.set({ audioEnabled: this.config.enabled });
      }
      if (typeof options.volume === 'number') {
        this.config.volume = Math.max(0, Math.min(1, options.volume));
        // Update volume on existing audio element
        if (this.adminAudio) {
          this.adminAudio.volume = this.config.volume;
        }
      }
      if (typeof options.customSoundUrl === 'string' || options.customSoundUrl === null) {
        this.config.customSoundUrl = options.customSoundUrl;
        // Reload audio if already initialized
        if (this.audioInitialized) {
          const soundUrl = this.config.customSoundUrl || this.defaultSoundUrl;
          this.adminAudio = new Audio(soundUrl);
          this.adminAudio.volume = this.config.volume;
          this.adminAudio.load();
        }
      }

      console.log('[AdminAlertAudio] Configured:', {
        enabled: this.config.enabled,
        volume: this.config.volume,
        hasCustomSound: !!this.config.customSoundUrl
      });
    }

    /**
     * Play the admin alert sound
     *
     * @returns {Promise<boolean>} True if sound was played
     */
    async playAdminAlert() {
      // Check if enabled
      if (!this.config.enabled) {
        console.log('[AdminAlertAudio] Sound disabled, skipping');
        return false;
      }

      try {
        // Use preloaded audio if available, otherwise create new
        const audio = this.adminAudio || new Audio(this.config.customSoundUrl || this.defaultSoundUrl);
        audio.volume = this.config.volume;
        audio.currentTime = 0; // Reset to beginning

        await audio.play();
        console.log('[AdminAlertAudio] Played admin alert sound');
        return true;
      } catch (error) {
        console.error('[AdminAlertAudio] Failed to play:', {
          name: error.name,
          message: error.message
        });
        return false;
      }
    }

    /**
     * Test the admin alert sound
     * This is for the "Test Sound" button in settings
     *
     * @returns {Promise<boolean>} True if sound was played
     */
    async testSound() {
      try {
        const audio = this.adminAudio || new Audio(this.config.customSoundUrl || this.defaultSoundUrl);
        audio.volume = this.config.volume;
        audio.currentTime = 0;

        await audio.play();
        console.log('[AdminAlertAudio] Test sound played');
        return true;
      } catch (error) {
        console.error('[AdminAlertAudio] Test sound failed:', error);
        return false;
      }
    }

    /**
     * Get current state
     * @returns {Object} Current state
     */
    getState() {
      return {
        enabled: this.config.enabled,
        volume: this.config.volume,
        audioInitialized: this.audioInitialized,
        hasCustomSound: !!this.config.customSoundUrl
      };
    }

    /**
     * Check if sound can be played
     * @returns {boolean} True if all conditions are met
     */
    canPlay() {
      return this.config.enabled;
    }
  }

  // Create singleton instance
  const adminAlertAudio = new AdminAlertAudioService();

  // Export for use in content scripts and popup
  if (typeof window !== 'undefined') {
    window.AdminAlertAudio = adminAlertAudio;
  }

})(typeof window !== 'undefined' ? window : global);
