/**
 * Score Alert Audio Service
 * Plays alert sound when token admin meets score threshold
 *
 * Features:
 * - Plays sound when admin score is better than or equal to threshold
 * - Configurable volume and independent from admin alerts
 * - Preloads audio on first user interaction (click/scroll/touch)
 * - Uses standard HTML5 Audio element
 */

(function(window) {
  'use strict';

  /**
   * Score Alert Audio Service Class
   */
  class ScoreAlertAudioService {
    constructor() {
      // Audio element
      this.scoreAudio = null;
      this.audioInitialized = false;

      // Current configuration
      this.config = {
        enabled: false,
        volume: 0.5,
        customSoundUrl: null
      };

      // Default sound URL - uses alert2.mp3 for score alerts
      this.defaultSoundUrl = this.getRuntimeURL('Sounds/alert2.mp3');

      // Initialize audio on first user interaction
      this.initAudioOnInteraction();
    }

    /**
     * Get runtime URL for extension resources
     * @param {string} path - Relative path from extension root
     * @returns {string} Runtime URL
     */
    getRuntimeURL(path) {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        return chrome.runtime.getURL(path);
      }
      if (typeof browser !== 'undefined' && browser.runtime) {
        return browser.runtime.getURL(path);
      }
      return path;
    }

    /**
     * Initialize audio on first user interaction
     * This bypasses Chrome's autoplay policy
     */
    initAudioOnInteraction() {
      const initAudio = () => {
        if (this.audioInitialized) return;

        try {
          const soundUrl = this.config.customSoundUrl || this.defaultSoundUrl;
          this.scoreAudio = new Audio(soundUrl);
          this.scoreAudio.volume = this.config.volume;
          this.scoreAudio.load(); // Important: preloads the audio
          this.audioInitialized = true;
          console.log('[ScoreAlertAudio] Audio preloaded successfully');
        } catch (error) {
          console.error('[ScoreAlertAudio] Failed to preload audio:', error);
        }
      };

      // Initialize on any user interaction
      const events = ['click', 'keydown', 'scroll', 'touchstart'];
      events.forEach(event => {
        document.addEventListener(event, initAudio, { once: true, passive: true });
      });
    }

    /**
     * Configure the audio service with settings
     *
     * @param {Object} options - Configuration options
     * @param {boolean} options.enabled - Whether score alert sound is enabled
     * @param {number} options.volume - Volume level (0.0 to 1.0)
     * @param {string|null} options.customSoundUrl - URL to custom sound file, or null for default
     */
    configure(options = {}) {
      // Update configuration
      if (typeof options.enabled === 'boolean') {
        this.config.enabled = options.enabled;
        // Save to storage
        chrome.storage.local.set({ scoreAlertAudioEnabled: this.config.enabled });
      }
      if (typeof options.volume === 'number') {
        this.config.volume = Math.max(0, Math.min(1, options.volume));
        // Update volume on existing audio element
        if (this.scoreAudio) {
          this.scoreAudio.volume = this.config.volume;
        }
      }
      if (typeof options.customSoundUrl === 'string' || options.customSoundUrl === null) {
        this.config.customSoundUrl = options.customSoundUrl;
        // Reload audio if already initialized
        if (this.audioInitialized) {
          const soundUrl = this.config.customSoundUrl || this.defaultSoundUrl;
          this.scoreAudio = new Audio(soundUrl);
          this.scoreAudio.volume = this.config.volume;
          this.scoreAudio.load();
        }
      }

      console.log('[ScoreAlertAudio] Configured:', {
        enabled: this.config.enabled,
        volume: this.config.volume,
        hasCustomSound: !!this.config.customSoundUrl
      });
    }

    /**
     * Play the score alert sound
     *
     * @returns {Promise<boolean>} True if sound was played
     */
    async playScoreAlert() {
      // Check if enabled
      if (!this.config.enabled) {
        console.log('[ScoreAlertAudio] Sound disabled, skipping');
        return false;
      }

      try {
        // Use preloaded audio if available, otherwise create new
        const audio = this.scoreAudio || new Audio(this.config.customSoundUrl || this.defaultSoundUrl);
        audio.volume = this.config.volume;
        audio.currentTime = 0; // Reset to beginning

        await audio.play();
        console.log('[ScoreAlertAudio] Played score alert sound');
        return true;
      } catch (error) {
        console.error('[ScoreAlertAudio] Failed to play:', {
          name: error.name,
          message: error.message
        });
        return false;
      }
    }

    /**
     * Test the score alert sound
     * This is for the "Test Sound" button in settings
     *
     * @returns {Promise<boolean>} True if sound was played
     */
    async testSound() {
      try {
        const audio = this.scoreAudio || new Audio(this.config.customSoundUrl || this.defaultSoundUrl);
        audio.volume = this.config.volume;
        audio.currentTime = 0;

        await audio.play();
        console.log('[ScoreAlertAudio] Test sound played');
        return true;
      } catch (error) {
        console.error('[ScoreAlertAudio] Test sound failed:', error);
        return false;
      }
    }

    /**
     * Get current state
     * @returns {Object} Current state
     */
    getState() {
      return {
        enabled: this.config.enabled,
        volume: this.config.volume,
        audioInitialized: this.audioInitialized,
        hasCustomSound: !!this.config.customSoundUrl
      };
    }

    /**
     * Check if sound can be played
     * @returns {boolean} True if all conditions are met
     */
    canPlay() {
      return this.config.enabled;
    }
  }

  // Create singleton instance
  const scoreAlertAudio = new ScoreAlertAudioService();

  // Export for use in content scripts and popup
  if (typeof window !== 'undefined') {
    window.ScoreAlertAudio = scoreAlertAudio;
  }

})(typeof window !== 'undefined' ? window : global);
