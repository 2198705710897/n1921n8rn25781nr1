// Config Share Upload Module

// API URL - using the same Vercel API as the rest of the extension
function getApiUrl() {
  return 'https://n1921n8rn25781nr1.vercel.app/api';
}

// Toast notification helper (defined locally since popup.js has its own)
function showToast(message, type = 'success') {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  // Remove after delay
  setTimeout(() => {
    toast.classList.add('hiding');
    toast.addEventListener('animationend', () => toast.remove());
  }, 3000);
}

export class ConfigShareUpload {
  constructor() {
    this.overlay = null;
    this.modal = null;
    this.isVisible = false;
    this.configData = null;
    this.configStats = null;
  }

  async show() {
    if (this.isVisible) return;
    this.isVisible = true;

    // Export current config first
    this.configData = await this.exportConfig();
    this.configStats = this.calculateStats(this.configData);

    this.createOverlay();
    document.body.appendChild(this.overlay);
    this.overlay.classList.add('active');
  }

  hide() {
    if (!this.isVisible) return;
    this.isVisible = false;
    this.overlay.classList.remove('active');
    setTimeout(() => {
      if (this.overlay && this.overlay.parentNode) {
        this.overlay.parentNode.removeChild(this.overlay);
      }
      this.overlay = null;
      this.modal = null;
    }, 200);
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'config-share-overlay';
    this.overlay.innerHTML = this.getModalHTML();

    this.modal = this.overlay.querySelector('.config-share-modal');

    // Add event listeners
    const closeBtn = this.overlay.querySelector('.config-share-close');
    closeBtn.addEventListener('click', () => this.hide());

    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.hide();
      }
    });

    const cancelBtn = this.overlay.querySelector('.config-share-btn-secondary');
    cancelBtn.addEventListener('click', () => this.hide());

    const uploadBtn = this.overlay.querySelector('.config-share-btn-primary');
    uploadBtn.addEventListener('click', () => this.handleUpload());

    // Close on Escape key
    this.escapeHandler = (e) => {
      if (e.key === 'Escape') {
        this.hide();
      }
    };
    document.addEventListener('keydown', this.escapeHandler);
  }

  getModalHTML() {
    const stats = this.configStats;
    const sizeInMB = (stats.sizeBytes / (1024 * 1024)).toFixed(2);

    return `
      <div class="config-share-modal">
        <div class="config-share-header">
          <h2>Share Config</h2>
          <button class="config-share-close">&times;</button>
        </div>
        <div class="config-share-body">
          <div class="config-share-stats">
            <h3>Your Config Stats</h3>
            <div class="config-share-stats-grid">
              <div class="config-share-stat-item">
                <div class="config-share-stat-value">${stats.admins}</div>
                <div class="config-share-stat-label">Admins</div>
              </div>
              <div class="config-share-stat-item">
                <div class="config-share-stat-value">${stats.tweets}</div>
                <div class="config-share-stat-label">Tweets</div>
              </div>
              <div class="config-share-stat-item">
                <div class="config-share-stat-value">${stats.blacklist}</div>
                <div class="config-share-stat-label">Blacklist</div>
              </div>
            </div>
          </div>

          <div class="config-share-form-group">
            <label for="configDisplayName">Display Name</label>
            <input type="text" id="configDisplayName" placeholder="My Awesome Config" maxlength="100">
          </div>

          <div class="config-share-form-group">
            <label for="configDescription">Description (optional)</label>
            <textarea id="configDescription" placeholder="Describe your config..." maxlength="500"></textarea>
          </div>

          <div class="config-share-toggle-row">
            <div class="config-share-toggle-label">Make this config public</div>
            <label class="config-share-toggle">
              <input type="checkbox" id="configPublicToggle">
              <span class="config-share-toggle-slider"></span>
            </label>
          </div>

          <p style="font-size: 12px; color: #8899a6; margin: 0;">
            Config size: ${sizeInMB} MB • Public configs can be browsed and copied by others
          </p>
        </div>
        <div class="config-share-footer">
          <button class="config-share-btn config-share-btn-secondary">Cancel</button>
          <button class="config-share-btn config-share-btn-primary">Upload Config</button>
        </div>
      </div>
    `;
  }

  calculateStats(configData) {
    const settings = configData?.settings || {};
    return {
      admins: settings.adminAlertsList?.length || 0,
      tweets: settings.trackedTweetsList?.length || 0,
      blacklist: settings.adminBlacklistList?.length || 0,
      sizeBytes: JSON.stringify(configData).length
    };
  }

  async handleUpload() {
    const displayName = document.getElementById('configDisplayName').value.trim();
    const description = document.getElementById('configDescription').value.trim();
    const isPublic = document.getElementById('configPublicToggle').checked;

    if (!displayName) {
      showToast('Please enter a display name', 'error');
      return;
    }

    // Show loading state
    const uploadBtn = this.overlay.querySelector('.config-share-btn-primary');
    const originalText = uploadBtn.textContent;
    uploadBtn.textContent = 'Uploading...';
    uploadBtn.disabled = true;

    try {
      const response = await fetch(`${getApiUrl()}/config-share?action=upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          displayName,
          description,
          isPublic,
          configData: this.configData
        })
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Upload failed');
      }

      showToast('Config uploaded successfully!', 'success');
      this.hide();

    } catch (error) {
      console.error('Upload error:', error);
      showToast(error.message || 'Failed to upload config', 'error');
    } finally {
      uploadBtn.textContent = originalText;
      uploadBtn.disabled = false;
    }
  }

  exportConfig() {
    // Get current settings from storage
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (data) => {
        const config = {
          exportedAt: new Date().toISOString(),
          version: '1.0',
          settings: {
            detectXCommunity: data.xCommunityEnabled ?? true,
            adminAlertSound: data.adminAlertEnabled ?? false,
            showAdminInfo: data.showAdminInfo ?? true,
            adminAlertsList: data.trackedAdmins || [],
            adminBlacklistList: data.blacklistedAdmins || [],
            trackedTweetsList: data.trackedTweets || [],
            blacklistedTweetsList: data.blacklistedTweets || []
          },
          adminProfileCache: data.adminProfileCache || {}
        };
        resolve(config);
      });
    });
  }
}
