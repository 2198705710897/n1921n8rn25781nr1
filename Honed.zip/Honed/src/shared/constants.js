/**
 * Shared constants for the X Community Detector extension
 */

// Guard against duplicate script loading
if (typeof window.API_CONFIG !== 'undefined') {
  console.log('[Constants] Already loaded, skipping...');
} else {

/**
 * API configuration
 */
const API_CONFIG = {
  BASE_URL: 'https://api.twitterapi.io/twitter',
  COMMUNITY_ENDPOINT: '/community/info',
  USER_ENDPOINT: '/user/info',
  KEY: 'new1_899820ce8857459c942560025f491007'
};

/**
 * Cache key prefixes
 */
const CACHE_PREFIXES = {
  COMMUNITY: 'community_cache_',
  USER_PROFILE: 'user_profile_'
};

/**
 * Storage keys
 */
const STORAGE_KEYS = {
  CORE_ADMINS: 'coreAdmins'
};

/**
 * Default color values
 */
const DEFAULT_COLORS = {
  ACCENT_PRIMARY: '#22d3ee',
  ACCENT_PRIMARY_DIM: 'rgba(34, 211, 238, 0.15)',
  ACCENT_PRIMARY_HOVER: '#06b6d4',
  NORMAL_ADMIN: '#1a1a2e',
  TRACKED_BORDER: '#22d3ee',
  TRACKED_GRADIENT: '#22d3ee'
};

/**
 * DOM selectors
 */
const SELECTORS = {
  GRID_CELL: '[role="gridcell"]',
  COMMUNITY_LINK: 'a[href*="x.com/i/communities"], a[href*="twitter.com/i/communities"]',
  ADMIN_USERNAME: '.admin-username',
  MUI_STACK: '.MuiStack-root'
};

/**
 * Processing configuration
 */
const PROCESSING_CONFIG = {
  BATCH_SIZE: 5,
  BATCH_DELAY: 100,
  MUTATION_DEBOUNCE: 500
};

/**
 * Target website
 */
const TARGET_URL = 'https://trade.padre.gg/trenches*';

/**
 * Export as object for content scripts (non-module contexts)
 */
const CONSTANTS = {
  API_CONFIG,
  CACHE_PREFIXES,
  STORAGE_KEYS,
  DEFAULT_COLORS,
  SELECTORS,
  PROCESSING_CONFIG,
  TARGET_URL
};

// Make available globally for content scripts
if (typeof window !== 'undefined') {
  window.API_CONFIG = API_CONFIG;
  window.CACHE_PREFIXES = CACHE_PREFIXES;
  window.STORAGE_KEYS = STORAGE_KEYS;
  window.DEFAULT_COLORS = DEFAULT_COLORS;
  window.SELECTORS = SELECTORS;
  window.PROCESSING_CONFIG = PROCESSING_CONFIG;
  window.TARGET_URL = TARGET_URL;
  window.CONSTANTS = CONSTANTS;
}

} // End of duplicate load guard
