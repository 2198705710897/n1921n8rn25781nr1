/**
 * Daily Stats Data Access Layer
 * Follows the same pattern as SheetsData
 */

if (typeof window.DailyStatsData !== 'undefined') {
  console.log('[DailyStatsData] Already loaded, skipping...');
} else {

class DailyStatsData {
  static _cache = null;
  static _cachePromise = null;
  static _cacheTimestamp = 0;
  static _CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  static async _ensureCache() {
    if (this._cache && (Date.now() - this._cacheTimestamp) < this._CACHE_TTL) {
      return this._cache;
    }
    if (this._cachePromise) {
      return this._cachePromise;
    }
    this._cachePromise = this._loadAllStats();
    try {
      const stats = await this._cachePromise;
      this._cache = stats;
      this._cacheTimestamp = Date.now();
      return stats;
    } finally {
      this._cachePromise = null;
    }
  }

  static async _loadAllStats() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: 'getAllDailyStats' },
        (response) => {
          if (response?.success && response.dailyStats) {
            resolve(response.dailyStats);
          } else {
            resolve([]);
          }
        }
      );
    });
  }

  /**
   * Get stats for a specific date
   * @param {string} date - Date in YYYY-MM-DD format
   * @returns {Object|null} Daily stats object or null
   */
  static async getStatsForDate(date) {
    const cache = await this._ensureCache();
    return cache.find(stat => stat.date === date) || null;
  }

  /**
   * Get all daily stats
   * @returns {Array} Array of daily stats objects
   */
  static async getAllStats() {
    return this._ensureCache();
  }

  /**
   * Get date range (first and last dates with data)
   * @returns {Object} { firstDate: string, lastDate: string }
   */
  static async getDateRange() {
    const stats = await this._ensureCache();
    if (stats.length === 0) return { firstDate: null, lastDate: null };

    const sorted = [...stats].sort((a, b) => a.date.localeCompare(b.date));
    return {
      firstDate: sorted[0].date,
      lastDate: sorted[sorted.length - 1].date
    };
  }

  /**
   * Get color class based on average score
   * @param {number} avgScore - Average score (0-6)
   * @returns {Object} { class: string, color: string, hex: string }
   */
  static getScoreColor(avgScore) {
    if (avgScore <= 1.0) return { class: 'score-excellent', color: '#10b981', hex: '#10b981' }; // Green
    if (avgScore <= 1.8) return { class: 'score-good', color: '#22d3ee', hex: '#22d3ee' };     // Cyan
    if (avgScore <= 2.6) return { class: 'score-fair', color: '#60a5fa', hex: '#60a5fa' };     // Blue
    if (avgScore <= 3.4) return { class: 'score-mixed', color: '#fbbf24', hex: '#fbbf24' };    // Yellow
    if (avgScore <= 4.2) return { class: 'score-poor', color: '#fb923c', hex: '#fb923c' };     // Orange
    return { class: 'score-bad', color: '#ef4444', hex: '#ef4444' };                          // Red
  }

  /**
   * Invalidate cache (call when data is refreshed)
   */
  static invalidateCache() {
    this._cache = null;
    this._cacheTimestamp = 0;
  }
}

if (typeof window !== 'undefined') {
  window.DailyStatsData = DailyStatsData;
}

} // End of duplicate load guard
