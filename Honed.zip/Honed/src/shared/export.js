/**
 * Single Export Primitive
 *
 * Centralized export functionality for all data exports.
 * Exports tracked admins, settings, blacklist, and profile cache.
 */

/**
 * Export options
 * @typedef {Object} ExportOptions
 * @property {boolean} [includeAdmins=true] - Include tracked admins
 * @property {boolean} [includeSettings=true] - Include extension settings
 * @property {boolean} [includeBlacklist=true] - Include blacklist if exists
 * @property {boolean} [includeProfileCache=true] - Include profile cache if exists
 * @property {boolean} [includeTweets=true] - Include tracked tweets if exists
 * @property {boolean} [includeTweetsBlacklist=true] - Include tweets blacklist if exists
 * @property {string} [filename='honed-export'] - Base filename (without extension)
 * @property {string} [format='json'] - Export format ('json' or 'txt')
 */

const DEFAULT_EXPORT_OPTIONS = {
  includeAdmins: true,
  includeSettings: true,
  includeBlacklist: true,
  includeProfileCache: true,
  includeTweets: true,
  includeTweetsBlacklist: true,
  filename: 'honed-export',
  format: 'json'
};

/**
 * Get tracked admins from storage
 * @returns {Promise<Array>} Tracked admins
 */
function getTrackedAdmins() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['trackedAdmins'], (result) => {
      resolve(result.trackedAdmins || []);
    });
  });
}

/**
 * Get settings from sync storage
 * @returns {Promise<Object>} Extension settings
 */
function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({
      xCommunityEnabled: true,
      showAdminInfo: true,
      showMemberPreview: true,
      showFollowerCount: true,
      adminBackgroundEnabled: true,
      normalAdminColor: '#1a1a2e',
      trackedGradientEnabled: true,
      trackedBorderColor: '#22d3ee',
      trackedGradientColor: '#22d3ee',
      trackedGradientOpacity: 20,
      adminAlertEnabled: false,
      adminAlertVolume: 50,
      adminAlertCustomSound: null,
      communityVerificationEnabled: true
    }, (settings) => {
      resolve(settings);
    });
  });
}

/**
 * Get blacklist from storage
 * @returns {Promise<Array>} Blacklist
 */
function getBlacklist() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['blacklistedAdmins'], (result) => {
      resolve(result.blacklistedAdmins || []);
    });
  });
}

/**
 * Get profile cache from storage
 * @returns {Promise<Object>} Profile cache
 */
function getProfileCache() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['adminProfileCache'], (result) => {
      resolve(result.adminProfileCache || {});
    });
  });
}

/**
 * Get tracked tweets from storage
 * @returns {Promise<Array>} Tracked tweets
 */
function getTrackedTweets() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['trackedTweets'], (result) => {
      resolve(result.trackedTweets || []);
    });
  });
}

/**
 * Get tweets blacklist from storage
 * @returns {Promise<Array>} Tweets blacklist
 */
function getTweetsBlacklist() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['blacklistedTweets'], (result) => {
      resolve(result.blacklistedTweets || []);
    });
  });
}

/**
 * Prepare export data structure
 * Matches the format of tracked-admins-*.json files:
 * {
 *   "settings": {
 *     "adminAlertsList": [...],
 *     "adminBlacklistList": [...],
 *     "trackedTweetsList": [...],
 *     "blacklistedTweetsList": [...],
 *     ...otherSettings
 *   },
 *   "adminProfileCache": {
 *     "username1": {...},
 *     "username2": {...}
 *   }
 * }
 * @param {Object} data - Data to export
 * @returns {Object} Formatted export object
 */
function prepareExportData(data) {
  // Create settings object with all settings
  const settings = {};

  // Map and add extension settings
  if (data.settings) {
    Object.keys(data.settings).forEach(key => {
      const exportKey = key === 'xCommunityEnabled' ? 'detectXCommunity' :
                       key === 'adminAlertEnabled' ? 'adminAlertSound' : key;
      settings[exportKey] = data.settings[key];
    });
  }

  // Add tracked admins list to settings
  if (data.admins && data.admins.length > 0) {
    settings.adminAlertsList = data.admins;
  }

  // Add blacklist to settings
  if (data.blacklist && data.blacklist.length > 0) {
    settings.adminBlacklistList = data.blacklist;
  }

  // Add tracked tweets to settings
  if (data.tweets && data.tweets.length > 0) {
    settings.trackedTweetsList = data.tweets;
  }

  // Add tweets blacklist to settings
  if (data.tweetsBlacklist && data.tweetsBlacklist.length > 0) {
    settings.blacklistedTweetsList = data.tweetsBlacklist;
  }

  // Build the export object
  const exportData = {
    exportedAt: new Date().toISOString(),
    version: '1.0',
    settings: settings
  };

  // Add profile cache at root level (not nested under settings)
  if (data.profileCache && Object.keys(data.profileCache).length > 0) {
    exportData.adminProfileCache = data.profileCache;
  }

  return exportData;
}

/**
 * Trigger browser download
 * @param {Object} data - Data to download
 * @param {string} filename - Filename
 * @param {string} format - File format ('json' or 'txt')
 */
function triggerDownload(data, filename, format) {
  const dataStr = JSON.stringify(data, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}-${Date.now()}.${format}`;
  a.style.display = 'none';

  // Add to DOM to ensure it works in Chrome extension popup context
  document.body.appendChild(a);
  a.click();

  // Small delay before cleanup to ensure download starts
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

/**
 * Main export function - single entry point for all exports
 *
 * @param {ExportOptions} options - Export options
 * @returns {Promise<Object>} Export result with data and metadata
 *
 * @example
 * // Export all data
 * const result = await exportData();
 *
 * @example
 * // Export only admins
 * const result = await exportData({ includeSettings: false, includeProfileCache: false });
 *
 * @example
 * // Export with custom filename
 * const result = await exportData({ filename: 'my-backup' });
 */
export async function exportData(options = {}) {
  const opts = { ...DEFAULT_EXPORT_OPTIONS, ...options };

  // Gather data based on options
  const data = {};

  if (opts.includeAdmins) {
    data.admins = await getTrackedAdmins();
  }

  if (opts.includeSettings) {
    data.settings = await getSettings();
  }

  if (opts.includeBlacklist) {
    data.blacklist = await getBlacklist();
  }

  if (opts.includeProfileCache) {
    data.profileCache = await getProfileCache();
  }

  if (opts.includeTweets) {
    data.tweets = await getTrackedTweets();
  }

  if (opts.includeTweetsBlacklist) {
    data.tweetsBlacklist = await getTweetsBlacklist();
  }

  // Prepare export structure
  const exportData = prepareExportData(data);

  // Calculate summary
  const summary = {
    admins: data.admins ? data.admins.length : 0,
    blacklist: data.blacklist ? data.blacklist.length : 0,
    tweets: data.tweets ? data.tweets.length : 0,
    tweetsBlacklist: data.tweetsBlacklist ? data.tweetsBlacklist.length : 0,
    profileCache: data.profileCache ? Object.keys(data.profileCache).length : 0,
    settings: data.settings ? Object.keys(data.settings).length : 0,
    timestamp: exportData.exportedAt
  };

  // Trigger download
  triggerDownload(exportData, opts.filename, opts.format);

  return {
    success: true,
    data: exportData,
    summary
  };
}

// Export for use in non-module contexts
if (typeof window !== 'undefined') {
  window.ExportModule = { exportData };
}
