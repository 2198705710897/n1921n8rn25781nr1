/**
 * Help Modal Module
 * Help documentation modal with tabbed interface
 */

// Guard against duplicate script loading
if (typeof window.HelpModal !== 'undefined') {
  console.log('[HelpModal] Already loaded, skipping...');
} else {

class HelpModal {
  constructor() {
    this.backdrop = null;
    this.container = null;
    this.currentTab = 'gettingStarted';
    this.isOpen = false;
    this.escapeHandlerBound = null;
  }

  /**
   * Show the help modal
   * @param {string} initialTab - Optional tab ID to open directly
   */
  show(initialTab = null) {
    if (this.isOpen) return;

    this.isOpen = true;
    if (initialTab) {
      this.currentTab = initialTab;
    }
    this._createModal();

    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Bind ESC handler
    this.escapeHandlerBound = this._handleEscape.bind(this);
    document.addEventListener('keydown', this.escapeHandlerBound);

    this._renderContent(this.currentTab);
    this._setupTabs();
    this._setupSearch();
  }

  /**
   * Hide the help modal
   */
  hide() {
    if (!this.isOpen) return;

    // Remove ESC handler
    if (this.escapeHandlerBound) {
      document.removeEventListener('keydown', this.escapeHandlerBound);
      this.escapeHandlerBound = null;
    }

    // Remove backdrop
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
      this.backdrop.style.display = 'none';
    }

    try {
      if (this.backdrop && this.backdrop.parentNode) {
        this.backdrop.parentNode.removeChild(this.backdrop);
      }
    } catch (e) {
      console.error('[HelpModal] Error removing backdrop:', e);
    }

    document.body.classList.remove('modal-open');
    this.isOpen = false;
    this.backdrop = null;
    this.container = null;
  }

  /**
   * Create the modal DOM structure
   * @private
   */
  _createModal() {
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'help-modal-backdrop';

    this.container = document.createElement('div');
    this.container.className = 'help-modal-container';

    const topics = typeof HelpContent !== 'undefined' ? HelpContent.getTopics() : {};

    this.container.innerHTML = `
      <div class="help-modal-header">
        <div class="help-modal-title">
          <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 4C9.243 4 7 6.243 7 9h2c0-1.654 1.346-3 3-3s3 1.346 3 3c0 1.069-.454 1.465-1.481 2.255-.382.294-.813.626-1.226 1.038C10.981 13.604 10.995 14.897 11 15v2h2v-2.009c0-.024.023-.601.707-1.284.32-.32.682-.598 1.031-.867C15.798 12.024 17 11.1 17 9c0-2.757-2.243-5-5-5zm-1 14h2v2h-2z"/>
          </svg>
          Help & Documentation
        </div>
        <div class="help-modal-search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <input type="text" id="helpSearchInput" placeholder="">
        </div>
        <button class="help-modal-close-button" id="helpModalCloseBtn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <div class="help-modal-tabs" id="helpModalTabs">
        ${Object.entries(topics).map(([id, topic]) => `
          <button class="help-tab-button ${id === this.currentTab ? 'active' : ''}" data-tab="${id}">
            ${topic.icon}
            <span>${topic.title}</span>
          </button>
        `).join('')}
      </div>

      <div class="help-modal-content" id="helpModalContent">
        <!-- Content will be rendered here -->
      </div>

      <div class="help-modal-search-results" id="helpSearchResults" style="display: none;">
        <!-- Search results will be shown here -->
      </div>
    `;

    this.backdrop.appendChild(this.container);

    // Add event listeners
    this._setupEventListeners();
  }

  /**
   * Setup event listeners for modal controls
   * @private
   */
  _setupEventListeners() {
    // Close button
    const closeBtn = this.container.querySelector('#helpModalCloseBtn');
    closeBtn.addEventListener('click', () => this.hide());

    // Backdrop click to close
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });
  }

  /**
   * Setup tab navigation
   * @private
   */
  _setupTabs() {
    const tabsContainer = this.container.querySelector('#helpModalTabs');
    const tabButtons = tabsContainer.querySelectorAll('.help-tab-button');

    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        const tabId = button.getAttribute('data-tab');
        this._switchTab(tabId);
      });
    });
  }

  /**
   * Setup search functionality
   * @private
   */
  _setupSearch() {
    const searchInput = this.container.querySelector('#helpSearchInput');
    const searchResults = this.container.querySelector('#helpSearchResults');
    const tabsContainer = this.container.querySelector('#helpModalTabs');
    const contentContainer = this.container.querySelector('#helpModalContent');

    let searchTimeout = null;

    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.trim();

      clearTimeout(searchTimeout);

      if (query.length === 0) {
        // Show normal tabs and content
        tabsContainer.style.display = 'flex';
        contentContainer.style.display = 'block';
        searchResults.style.display = 'none';
        return;
      }

      searchTimeout = setTimeout(() => {
        this._performSearch(query);
      }, 300);
    });

    // Clear search on escape
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        searchInput.value = '';
        tabsContainer.style.display = 'flex';
        contentContainer.style.display = 'block';
        searchResults.style.display = 'none';
      }
    });
  }

  /**
   * Perform search and display results
   * @private
   * @param {string} query - Search query
   */
  _performSearch(query) {
    const results = typeof HelpContent !== 'undefined' ? HelpContent.search(query) : [];
    const searchResults = this.container.querySelector('#helpSearchResults');
    const tabsContainer = this.container.querySelector('#helpModalTabs');
    const contentContainer = this.container.querySelector('#helpModalContent');

    // Hide tabs and content, show results
    tabsContainer.style.display = 'none';
    contentContainer.style.display = 'none';
    searchResults.style.display = 'block';

    if (results.length === 0) {
      searchResults.innerHTML = `
        <div class="help-search-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <p>No results found for "${this._escapeHtml(query)}"</p>
          <p>Try different keywords or browse the topics above</p>
        </div>
      `;
      return;
    }

    searchResults.innerHTML = `
      <div class="help-search-results-header">
        ${results.length} result${results.length !== 1 ? 's' : ''} for "${this._escapeHtml(query)}"
      </div>
      <div class="help-search-results-list">
        ${results.map(result => `
          <div class="help-search-result-item" data-topic="${result.topicId}">
            <div class="help-search-result-topic">${result.topicTitle}</div>
            <div class="help-search-result-title">${result.sectionTitle}</div>
          </div>
        `).join('')}
      </div>
    `;

    // Add click handlers to results
    const resultItems = searchResults.querySelectorAll('.help-search-result-item');
    resultItems.forEach(item => {
      item.addEventListener('click', () => {
        const topicId = item.getAttribute('data-topic');
        this._switchTab(topicId);

        // Clear search
        const searchInput = this.container.querySelector('#helpSearchInput');
        searchInput.value = '';
        tabsContainer.style.display = 'flex';
        contentContainer.style.display = 'block';
        searchResults.style.display = 'none';
      });
    });
  }

  /**
   * Switch to a specific tab
   * @private
   * @param {string} tabId - The tab ID to switch to
   */
  _switchTab(tabId) {
    // Update active state on tab buttons
    const tabButtons = this.container.querySelectorAll('.help-tab-button');
    tabButtons.forEach(button => {
      if (button.getAttribute('data-tab') === tabId) {
        button.classList.add('active');
      } else {
        button.classList.remove('active');
      }
    });

    this.currentTab = tabId;
    this._renderContent(tabId);
  }

  /**
   * Render content for a specific tab
   * @private
   * @param {string} tabId - The tab ID to render
   */
  _renderContent(tabId) {
    const contentContainer = this.container.querySelector('#helpModalContent');
    const topic = typeof HelpContent !== 'undefined' ? HelpContent.getTopic(tabId) : null;

    if (!topic) {
      contentContainer.innerHTML = `
        <div class="help-empty-state">
          <p>Topic not found</p>
        </div>
      `;
      return;
    }

    contentContainer.innerHTML = `
      <div class="help-content-header">
        ${topic.icon}
        <h2>${topic.title}</h2>
      </div>
      <div class="help-content-body">
        ${topic.sections.map(section => this._renderSection(section)).join('')}
      </div>
    `;

    // Add click handlers for screenshot lightbox
    this._setupScreenshotLightbox();
  }

  /**
   * Render a single section
   * @private
   * @param {Object} section - Section data
   * @returns {string} HTML for the section
   */
  _renderSection(section) {
    let html = `
      <div class="help-section">
        <h3 class="help-section-title">${section.title}</h3>
        <div class="help-section-content">${section.content}</div>
    `;

    if (section.screenshot) {
      html += `
        <div class="help-screenshot" data-screenshot="${this._escapeHtml(section.screenshot)}">
          <div class="help-skeleton-loader">
            <div class="skeleton-line"></div>
            <div class="skeleton-line"></div>
            <div class="skeleton-line"></div>
          </div>
          <img src="${this._escapeHtml(section.screenshot)}" alt="${this._escapeHtml(section.title)}" loading="lazy" />
          <div class="help-screenshot-hint">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M15 3h6v6"></path>
              <path d="M10 14L21 3"></path>
            </svg>
            Click to enlarge
          </div>
        </div>
      `;
    }

    html += `</div>`;
    return html;
  }

  /**
   * Setup screenshot lightbox functionality
   * @private
   */
  _setupScreenshotLightbox() {
    const screenshots = this.container.querySelectorAll('.help-screenshot img');

    screenshots.forEach(img => {
      img.addEventListener('load', () => {
        const skeleton = img.parentElement.querySelector('.help-skeleton-loader');
        if (skeleton) skeleton.remove();
      });

      img.addEventListener('error', () => {
        const screenshotContainer = img.closest('.help-screenshot');
        if (screenshotContainer) {
          screenshotContainer.innerHTML = `
            <div class="help-screenshot-error">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <circle cx="8.5" cy="8.5" r="1.5"></circle>
                <polyline points="21 15 16 10 5 21"></polyline>
              </svg>
              <p>Image not available</p>
            </div>
          `;
        }
      });

      img.addEventListener('click', () => {
        this._openLightbox(img.src);
      });
    });
  }

  /**
   * Open lightbox for screenshot
   * @private
   * @param {string} src - Image source URL
   */
  _openLightbox(src) {
    const lightbox = document.createElement('div');
    lightbox.className = 'help-lightbox-backdrop';
    lightbox.innerHTML = `
      <div class="help-lightbox-container">
        <button class="help-lightbox-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
        <img src="${this._escapeHtml(src)}" alt="Screenshot" />
      </div>
    `;

    document.body.appendChild(lightbox);

    // Close handlers
    const closeHandler = () => {
      lightbox.remove();
      document.removeEventListener('keydown', escapeHandler);
    };

    const escapeHandler = (e) => {
      if (e.key === 'Escape') closeHandler();
    };

    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox || e.target.closest('.help-lightbox-close')) {
        closeHandler();
      }
    });

    document.addEventListener('keydown', escapeHandler);
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape(e) {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   * @param {string} text - Text to escape
   * @returns {string} Escaped text
   */
  _escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.HelpModal = HelpModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HelpModal;
}

} // End of duplicate load guard
