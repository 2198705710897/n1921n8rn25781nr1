class LicenseValidator {
  constructor() {
    this.validationUrl = 'https://n1921n8rn25781nr1.vercel.app/api/validate';
    this.checkIntervalMinutes = 5; // Use minutes for chrome.alarms
    this.checkTimer = null;
    this.alarmName = 'licenseValidatorHeartbeat';
    this.isValid = false;
    this.lastReason = null;
    this.listeners = [];
    this.initialized = false;
    this.deviceId = null;
    this.authToken = null;
    this.updateRequired = false;
    this.updateInfo = null;
  }

  async getDeviceId() {
    if (this.deviceId) return this.deviceId;

    return new Promise((resolve) => {
      chrome.storage.local.get(['honedDeviceId'], async (result) => {
        if (result.honedDeviceId) {
          this.deviceId = result.honedDeviceId;
          resolve(this.deviceId);
        } else {
          // Generate a stable device fingerprint from browser characteristics
          // This persists across extension reinstalls
          const fingerprint = await this._generateFingerprint();
          const newDeviceId = `fp-${fingerprint}`;

          chrome.storage.local.set({ honedDeviceId: newDeviceId }, () => {
            this.deviceId = newDeviceId;
            console.log('[LicenseValidator] Generated device fingerprint:', newDeviceId);
            resolve(newDeviceId);
          });
        }
      });
    });
  }

  /**
   * Generate a stable device fingerprint from browser/system characteristics.
   * This fingerprint will be the same across extension reinstalls on the same device.
   */
  async _generateFingerprint() {
    const components = [];

    // Platform info from Chrome API (most stable)
    try {
      const platformInfo = await chrome.runtime.getPlatformInfo();
      components.push(platformInfo.os);
      components.push(platformInfo.arch);
    } catch (e) {
      // Fallback to navigator
      components.push(navigator.platform || 'unknown');
    }

    // Hardware info (stable across reinstalls)
    components.push(`cores-${navigator.hardwareConcurrency || 'unknown'}`);
    components.push(`lang-${navigator.language || 'unknown'}`);

    // Screen characteristics (change only if display changes)
    components.push(`screen-${screen.width}x${screen.height}`);
    components.push(`color-${screen.colorDepth}`);
    components.push(`dpi-${Math.round(window.devicePixelRatio * 100)}`);

    // Timezone (rarely changes)
    try {
      components.push(`tz-${Intl.DateTimeFormat().resolvedOptions().timeZone}`);
    } catch (e) {
      components.push(`tz-unknown`);
    }

    // Create a hash from all components
    const fingerprintString = components.join('|');
    const hash = await this._hashFingerprint(fingerprintString);
    
    // Return first 16 chars of hash (sufficient entropy)
    return hash.substring(0, 16);
  }

  /**
   * Create a simple hash from a string
   */
  async _hashFingerprint(str) {
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(str);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (e) {
      // Fallback: simple string hash if crypto not available
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
      }
      return Math.abs(hash).toString(16).padStart(16, '0');
    }
  }

  async init() {
    if (this.initialized) return;

    console.log('[LicenseValidator] Initializing...');

    await this.getDeviceId();

    const storedKey = await this.getLicenseKey();

    if (storedKey) {
      await this.validate(storedKey);
    } else {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
    }

    this.startPeriodicCheck();
    this.initialized = true;

    console.log('[LicenseValidator] Initialized. Valid:', this.isValid, 'Reason:', this.lastReason);
  }

  async getLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseKey'], (result) => {
        resolve(result.licenseKey || null);
      });
    });
  }

  async saveLicenseKey(key) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ licenseKey: key }, () => {
        console.log('[LicenseValidator] License key saved');
        resolve();
      });
    });
  }

  async clearLicenseKey() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(['licenseKey'], () => {
        console.log('[LicenseValidator] License key cleared');
        resolve();
      });
    });
  }

  async validate(key = null) {
    const keyToCheck = key || await this.getLicenseKey();

    if (!keyToCheck) {
      this.isValid = false;
      this.lastReason = 'NO_KEY';
      this.notifyListeners();
      await this._updateStorage(false);
      return false;
    }

    try {
      const deviceId = await this.getDeviceId();
      
      // Get extension version from manifest
      const extensionVersion = chrome.runtime?.getManifest?.()?.version || '1.0';

      console.log('[LicenseValidator] Validating license key for device:', deviceId, 'version:', extensionVersion);
      const response = await fetch(`${this.validationUrl}?key=${encodeURIComponent(keyToCheck)}&deviceId=${encodeURIComponent(deviceId)}&version=${encodeURIComponent(extensionVersion)}`);
      const data = await response.json();

      console.log('[LicenseValidator] Validation response:', data);

      this.isValid = data.valid;
      this.lastReason = data.reason;

      if (data.token) {
        this.authToken = data.token;
        await this._storeToken(data.token);
      }

      // Check for update notification
      if (data.updateNotification && data.updateNotification.active) {
        await this._handleUpdateNotification(data.updateNotification);
        // Mark update as required - extension will be disabled until updated
        this.updateRequired = true;
        this.updateInfo = data.updateNotification;
        console.log('[LicenseValidator] ⚠️ Update required - extension disabled until updated');
      } else {
        this.updateRequired = false;
        this.updateInfo = null;
      }

      await this._updateStorage(this.isValid);

      this.notifyListeners();

      if (this.isValid) {
        console.log('[LicenseValidator] ✅ License valid');
      } else {
        console.warn('[LicenseValidator] ❌ License invalid:', data.message);
      }

      return this.isValid;

    } catch (error) {
      console.error('[LicenseValidator] Validation error:', error);
      console.warn('[LicenseValidator] Network error, allowing continued use');
      await this._updateStorage(true);
      return true;
    }
  }

  // Removed: No longer storing licenseValid/validUntil in storage
  // Always validate with server instead of trusting client-side storage
  async _updateStorage(isValid) {
    // Storage update removed - validation state now comes from server only
    return Promise.resolve();
  }

  async _storeToken(token) {
    return new Promise((resolve) => {
      const tokenExpiry = Date.now() + (5 * 60 * 1000);

      chrome.storage.local.set({
        licenseToken: token,
        licenseTokenExpiry: tokenExpiry
      }, () => {
        console.log('[LicenseValidator] Token stored');
        resolve();
      });
    });
  }

  async getAuthToken() {
    if (this.authToken && this.isValid) {
      return this.authToken;
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(['licenseToken', 'licenseTokenExpiry'], (result) => {
        const token = result.licenseToken;
        const expiry = result.licenseTokenExpiry || 0;
        const now = Date.now();

        if (token && expiry > now) {
          this.authToken = token;
          resolve(token);
        } else {
          resolve(null);
        }
      });
    });
  }

  startPeriodicCheck() {
    // Clear any existing interval
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }

    // Use chrome.alarms for persistence across service worker restarts
    chrome.alarms.create(this.alarmName, {
      delayInMinutes: this.checkIntervalMinutes,
      periodInMinutes: this.checkIntervalMinutes
    });

    console.log('[LicenseValidator] Periodic checks started using chrome.alarms');
  }

  stopPeriodicCheck() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }

    // Clear the alarm
    chrome.alarms.clear(this.alarmName);

    console.log('[LicenseValidator] Periodic checks stopped');
  }

  isLicenseValid() {
    return this.isValid;
  }

  getValidationReason() {
    return this.lastReason;
  }

  onValidationChange(callback) {
    this.listeners.push(callback);
  }

  removeValidationListener(callback) {
    this.listeners = this.listeners.filter(cb => cb !== callback);
  }

  notifyListeners() {
    this.listeners.forEach(callback => {
      try {
        callback(this.isValid, this.lastReason);
      } catch (error) {
        console.error('[LicenseValidator] Listener error:', error);
      }
    });
  }

  getErrorMessage() {
    switch (this.lastReason) {
      case 'NO_KEY':
        return 'Please enter your license key to use this extension.';
      case 'INVALID':
        return 'Invalid license key. Please purchase a license to use this extension.';
      case 'REVOKED':
        return 'Your license has been revoked. Please contact support.';
      case 'MAINTENANCE':
        return 'Extension is temporarily disabled for maintenance. Please check back later.';
      case 'DEVICE_MISMATCH':
        return 'This license key is already bound to another device. Each key can only be used on one device.';
      default:
        return 'License validation failed. Please try again later.';
    }
  }

  checkFeature(featureName = 'feature') {
    if (this.updateRequired) {
      console.warn(`[LicenseValidator] Feature "${featureName}" blocked - update required`);
      return false;
    }
    if (!this.isValid) {
      console.warn(`[LicenseValidator] Feature "${featureName}" blocked - license invalid`);
      return false;
    }
    return true;
  }

  isUpdateRequired() {
    return this.updateRequired;
  }

  getUpdateInfo() {
    return this.updateInfo;
  }

  async _handleUpdateNotification(notification) {
    const storage = await this._getNotificationStorage();
    // Include version (updated_at timestamp) in hash so re-enabling shows again
    const notificationHash = await this._hashNotification(notification.message + (notification.version || ''));

    if (storage.lastShownHash !== notificationHash) {
      console.log('[LicenseValidator] 📢 Update notification:', notification.message);

      // Store in chrome.storage for popup to access
      await new Promise((resolve) => {
        chrome.storage.local.set({
          pendingUpdateNotification: {
            message: notification.message,
            downloadUrl: notification.downloadUrl || null,
            timestamp: Date.now()
          }
        }, resolve);
      });

      await this._setNotificationStorage(notificationHash);
    }
  }

  async _getNotificationStorage() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['updateNotificationStorage'], (result) => {
        resolve(result.updateNotificationStorage || { lastShownHash: null });
      });
    });
  }

  async _setNotificationStorage(hash) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        updateNotificationStorage: {
          lastShownHash: hash,
          updatedAt: Date.now()
        }
      }, resolve);
    });
  }

  async _hashNotification(message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }
}

const licenseValidator = new LicenseValidator();

// Listen for alarm events (persists across service worker restarts)
if (typeof chrome !== 'undefined' && chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === licenseValidator.alarmName) {
      console.log('[LicenseValidator] Alarm triggered - periodic validation check');
      licenseValidator.validate().catch(err => {
        console.error('[LicenseValidator] Periodic validation failed:', err);
      });
    }
  });
}

if (typeof window !== 'undefined') {
  window.LicenseValidator = LicenseValidator;
  window.licenseValidator = licenseValidator;
}

export { licenseValidator, LicenseValidator };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { licenseValidator, LicenseValidator };
}
