/**
 * MEVX API Client
 * Fetches token details from MEVX API with caching and batch processing
 * API Endpoint: https://api.mevx.io/api/v1/pools/search?q=tokenaddress
 */

// Guard against duplicate script loading
if (typeof window.MevxApiClient !== 'undefined') {
  console.log('[MevxApiClient] Already loaded, skipping...');
} else {

class MevxApiClient {
  constructor() {
    this.baseUrl = 'https://api.mevx.io/api/v1/pools';
    this.cachePrefix = 'mevx_token_';
    this.cacheTTL = 5 * 60 * 1000; // 5 minutes - refresh market caps more frequently
    this.maxCacheSize = 1000;
    this.batchSize = 15; // Increased from 5 to 15 concurrent requests
    this.latencyHistory = [];
    this.requestTimeout = 10000; // 10 seconds
  }

  /**
   * Fetch token details for a single token address
   * @param {string} tokenAddress - Solana token address
   * @returns {Promise<Object|null>} Token details or null
   */
  async fetchTokenDetails(tokenAddress) {
    if (!tokenAddress) {
      return null;
    }

    // Check cache first
    const cached = await this._getFromCache(tokenAddress);
    if (cached) {
      return cached;
    }

    // Fetch from API
    try {
      const data = await this._fetchFromApi(tokenAddress);
      if (data) {
        await this._setCache(tokenAddress, data);
      }
      return data;
    } catch (error) {
      console.error(`[MevxApi] Failed to fetch ${tokenAddress}:`, error.message);
      return null;
    }
  }

  /**
   * Fetch token details for multiple token addresses (batched)
   * @param {Array<string>} tokenAddresses - Array of token addresses
   * @param {Function} onProgress - Callback for progress updates (optional)
   * @returns {Promise<Map<string, Object>>} Map of tokenAddress -> tokenDetails
   */
  async fetchBatchTokens(tokenAddresses, onProgress = null) {
    if (!tokenAddresses || tokenAddresses.length === 0) {
      return new Map();
    }

    const results = new Map();
    const toFetch = [];
    let cacheHits = 0;

    // Check cache for all addresses first
    for (const address of tokenAddresses) {
      const cached = await this._getFromCache(address);
      if (cached) {
        results.set(address, cached);
        cacheHits++;
      } else {
        toFetch.push(address);
      }
    }

    // Notify progress for cache hits
    if (onProgress && cacheHits > 0) {
      onProgress(cacheHits, tokenAddresses.length);
    }

    // Fetch remaining in batches
    for (let i = 0; i < toFetch.length; i += this.batchSize) {
      const batchSize = this._getOptimalBatchSize();
      const batch = toFetch.slice(i, i + batchSize);
      const batchStartTime = Date.now();

      const batchResults = await Promise.all(
        batch.map(async (address) => {
          try {
            const data = await this._fetchFromApi(address);
            if (data) {
              await this._setCache(address, data);
              results.set(address, data);
            }
            return { address, data };
          } catch (error) {
            console.error(`[MevxApi] Batch fetch failed for ${address}:`, error.message);
            return { address, data: null };
          }
        })
      );

      // Track latency for adaptive sizing
      const batchLatency = Date.now() - batchStartTime;
      this._updateLatencyMetrics(batchSize, batchLatency);

      // Notify progress after each batch
      if (onProgress) {
        const fetched = results.size;
        onProgress(fetched, tokenAddresses.length);
      }
    }

    return results;
  }

  /**
   * Get optimal batch size based on historical latency
   * @private
   * @returns {number} Optimal batch size
   */
  _getOptimalBatchSize() {
    if (this.latencyHistory.length < 5) {
      return this.batchSize; // Use default (15) until we have enough data
    }

    const avgLatency = this.latencyHistory.slice(-5)
      .reduce((sum, lat) => sum + lat, 0) / 5;

    if (avgLatency < 1000) {
      // Fast: increase batch size
      return Math.min(Math.round(this.batchSize * 1.5), 25);
    } else if (avgLatency > 3000) {
      // Slow: decrease batch size
      return Math.max(Math.round(this.batchSize * 0.7), 5);
    }

    return this.batchSize; // Normal: use 15
  }

  /**
   * Update latency metrics for adaptive batch sizing
   * @private
   * @param {number} batchSize - Batch size used
   * @param {number} latency - Total latency in ms
   */
  _updateLatencyMetrics(batchSize, latency) {
    // Track average latency per request in the batch
    const avgLatencyPerRequest = latency / batchSize;
    this.latencyHistory.push(avgLatencyPerRequest);

    // Keep only last 20 measurements
    if (this.latencyHistory.length > 20) {
      this.latencyHistory.shift();
    }
  }

  /**
   * Fetch data from MEVX API via background script (to bypass CORS)
   * @param {string} tokenAddress - Token address
   * @returns {Promise<Object|null>} Token data or null
   * @private
   */
  async _fetchFromApi(tokenAddress) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: 'fetchMevxTokenData', tokenAddress },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          if (response && response.success && response.data) {
            // Extract relevant data from response
            const extracted = this._extractTokenData(response.data, tokenAddress);
            resolve(extracted);
          } else {
            reject(new Error(response?.error || 'Failed to fetch MEVX token data'));
          }
        }
      );
    });
  }

  /**
   * Extract relevant token data from MEVX API response
   * @param {Object} data - Raw API response
   * @param {string} tokenAddress - Token address for fallback
   * @returns {Object|null} Extracted token data
   * @private
   */
  _extractTokenData(data, tokenAddress) {
    // Handle different response structures
    let pools = [];

    if (data && data.data && Array.isArray(data.data)) {
      pools = data.data;
    } else if (data && Array.isArray(data)) {
      pools = data;
    } else if (data && data.pools && Array.isArray(data.pools)) {
      pools = data.pools;
    } else {
      return null;
    }

    if (pools.length === 0) {
      return null;
    }

    const poolData = pools[0];

    // Handle different base token info structures
    const baseTokenInfo = poolData.baseTokenInfo || poolData.base_token_info || poolData.baseToken;

    if (!baseTokenInfo) {
      return null;
    }

    // Extract logo from various possible fields
    let logo = baseTokenInfo.logoUri || baseTokenInfo.logo_uri || baseTokenInfo.logo || baseTokenInfo.icon || null;

    const extracted = {
      symbol: baseTokenInfo.symbol || '',
      name: baseTokenInfo.name || '',
      logo: logo,
      socials: {
        twitter: baseTokenInfo.social?.twitter || baseTokenInfo.twitter || null,
        website: baseTokenInfo.social?.website || baseTokenInfo.website || null,
        telegram: baseTokenInfo.social?.telegram || baseTokenInfo.telegram || null
      },
      decimals: baseTokenInfo.decimals || 0,
      totalSupply: baseTokenInfo.totalSupply || '0'
    };

    return extracted;
  }

  /**
   * Get token data from cache
   * @param {string} tokenAddress - Token address
   * @returns {Promise<Object|null>} Cached data or null
   * @private
   */
  async _getFromCache(tokenAddress) {
    return new Promise((resolve) => {
      const cacheKey = this.cachePrefix + tokenAddress;
      chrome.storage.local.get([cacheKey], (result) => {
        if (chrome.runtime.lastError) {
          console.error('[MevxApi] Cache get error:', chrome.runtime.lastError);
          resolve(null);
          return;
        }

        const cached = result[cacheKey];
        if (!cached) {
          resolve(null);
          return;
        }

        // Check if cache is still valid
        const now = Date.now();
        if (now - cached.timestamp > this.cacheTTL) {
          // Cache expired, remove it
          chrome.storage.local.remove(cacheKey);
          resolve(null);
          return;
        }

        resolve(cached.data);
      });
    });
  }

  /**
   * Set token data in cache
   * @param {string} tokenAddress - Token address
   * @param {Object} data - Token data to cache
   * @returns {Promise<void>}
   * @private
   */
  async _setCache(tokenAddress, data) {
    return new Promise((resolve) => {
      // Clean old cache entries before setting new one
      this._cleanCache().then(() => {
        const cacheKey = this.cachePrefix + tokenAddress;
        const cacheEntry = {
          timestamp: Date.now(),
          data: data
        };

        chrome.storage.local.set({ [cacheKey]: cacheEntry }, () => {
          if (chrome.runtime.lastError) {
            console.error('[MevxApi] Cache set error:', chrome.runtime.lastError);
          }
          resolve();
        });
      });
    });
  }

  /**
   * Clean old cache entries to maintain max cache size
   * Uses LRU (Least Recently Used) eviction strategy
   * @returns {Promise<void>}
   * @private
   */
  async _cleanCache() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (result) => {
        if (chrome.runtime.lastError) {
          resolve();
          return;
        }

        // Get all MEVX cache entries
        const cacheEntries = [];
        for (const key in result) {
          if (key.startsWith(this.cachePrefix)) {
            cacheEntries.push({
              key: key,
              timestamp: result[key].timestamp
            });
          }
        }

        // If under limit, no need to clean
        if (cacheEntries.length <= this.maxCacheSize) {
          resolve();
          return;
        }

        // Sort by timestamp (oldest first) and remove excess
        cacheEntries.sort((a, b) => a.timestamp - b.timestamp);
        const toRemove = cacheEntries.slice(0, cacheEntries.length - this.maxCacheSize);
        const keysToRemove = toRemove.map(entry => entry.key);

        chrome.storage.local.remove(keysToRemove, () => {
          resolve();
        });
      });
    });
  }

  /**
   * Clear all MEVX cache entries
   * @returns {Promise<void>}
   */
  async clearCache() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (result) => {
        if (chrome.runtime.lastError) {
          resolve();
          return;
        }

        const keysToRemove = Object.keys(result).filter(key => key.startsWith(this.cachePrefix));

        if (keysToRemove.length === 0) {
          resolve();
          return;
        }

        chrome.storage.local.remove(keysToRemove, () => {
          resolve();
        });
      });
    });
  }

  /**
   * Get cache statistics
   * @returns {Promise<Object>} Cache stats
   */
  async getCacheStats() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (result) => {
        if (chrome.runtime.lastError) {
          resolve({ total: 0, valid: 0, expired: 0 });
          return;
        }

        const now = Date.now();
        let valid = 0;
        let expired = 0;

        for (const key in result) {
          if (key.startsWith(this.cachePrefix)) {
            if (now - result[key].timestamp > this.cacheTTL) {
              expired++;
            } else {
              valid++;
            }
          }
        }

        resolve({
          total: valid + expired,
          valid,
          expired
        });
      });
    });
  }

  /**
   * Force refresh token details (bypass cache)
   * @param {string} tokenAddress - Solana token address
   * @returns {Promise<Object|null>} Token details or null
   */
  async forceRefresh(tokenAddress) {
    if (!tokenAddress) {
      return null;
    }

    // Clear cache for this address
    const cacheKey = this.cachePrefix + tokenAddress;
    await new Promise(resolve => chrome.storage.local.remove(cacheKey, resolve));

    // Fetch from API
    try {
      const data = await this._fetchFromApi(tokenAddress);
      if (data) {
        await this._setCache(tokenAddress, data);
      }
      return data;
    } catch (error) {
      console.error(`[MevxApi] Failed to force refresh ${tokenAddress}:`, error.message);
      return null;
    }
  }

  /**
   * Force refresh multiple tokens (bypass cache)
   * @param {Array<string>} tokenAddresses - Array of token addresses
   * @param {Function} onProgress - Callback for progress updates (optional)
   * @returns {Promise<Map<string, Object>>} Map of tokenAddress -> tokenDetails
   */
  async forceRefreshBatch(tokenAddresses, onProgress = null) {
    if (!tokenAddresses || tokenAddresses.length === 0) {
      return new Map();
    }

    const results = new Map();

    // Clear cache for all addresses first
    const cacheKeys = tokenAddresses.map(addr => this.cachePrefix + addr);
    await new Promise(resolve => chrome.storage.local.remove(cacheKeys, resolve));

    // Fetch all in batches
    for (let i = 0; i < tokenAddresses.length; i += this.batchSize) {
      const batch = tokenAddresses.slice(i, i + this.batchSize);
      const batchResults = await Promise.all(
        batch.map(async (address) => {
          try {
            const data = await this._fetchFromApi(address);
            if (data) {
              await this._setCache(address, data);
              results.set(address, data);
            }
            return { address, data };
          } catch (error) {
            console.error(`[MevxApi] Batch force refresh failed for ${address}:`, error.message);
            return { address, data: null };
          }
        })
      );

      // Notify progress after each batch
      if (onProgress) {
        onProgress(results.size, tokenAddresses.length);
      }
    }

    return results;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.MevxApiClient = MevxApiClient;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MevxApiClient;
}

} // End of duplicate load guard
