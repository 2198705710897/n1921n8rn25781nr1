/**
 * Onboarding Popup Module
 * First-time user onboarding popup for the Honed extension
 */

// Guard against duplicate script loading
if (typeof window.OnboardingPopup !== 'undefined') {
  console.log('[OnboardingPopup] Already loaded, skipping...');
} else {

class OnboardingPopup {
  static STORAGE_KEY = 'onboardingCompleted';
  static VERSION_KEY = 'onboardingVersion';
  static CURRENT_VERSION = 1;

  constructor() {
    this.backdrop = null;
    this.container = null;
    this.currentStep = 0;
    this.totalSteps = 4;
    this.isOpen = false;
    this.escapeHandlerBound = null;

    // Onboarding steps content
    this.steps = [
      {
        title: 'Welcome to Honed!',
        content: `
          <p>Honed helps you track <strong>X (Twitter) community admins</strong> on Solana memecoin trading platforms.</p>
          <p>Get notified when your favorite admins launch new tokens, see their performance scores, and avoid scams.</p>
          <p>Let's take a quick tour to get you started!</p>
        `,
        icon: null,
        screenshot: null
      },
      {
        title: 'Track Community Admins',
        content: `
          <p><strong>Click the ⭐ star icon</strong> on any admin card to start tracking them.</p>
          <p>Tracked admins' tokens will be highlighted with a colored border, and you'll get an audio alert when they launch new tokens!</p>
          <p>You can also add admins manually in the extension popup under the <strong>Admins</strong> tab.</p>
        `,
        icon: null,
        screenshot: chrome.runtime.getURL('help-images/add-admin.png')
      },
      {
        title: 'Understand Admin Scores',
        content: `
          <p>Scores range from <strong>0-6</strong> based on historical performance.</p>
          <p><strong>Lower scores = Better performance!</strong></p>
          <ul>
            <li><span style="color: #10b981;">●</span> Score 0 = Excellent ($100k+ ATH)</li>
            <li><span style="color: #a0a0a0;">●</span> Score 1-2 = Fast/Slow migration</li>
            <li><span style="color: #ef4444;">●</span> Score 6 = Failed</li>
          </ul>
          <p>Check the <strong>?</strong> button in the popup for more details!</p>
        `,
        icon: null,
        screenshot: chrome.runtime.getURL('help-images/score-system.png')
      },
      {
        title: 'You\'re All Set!',
        content: `
          <p>Here's a quick recap:</p>
          <ul>
            <li><strong>⭐ Track admins</strong> by clicking the star icon</li>
            <li><strong>🔊 Enable alerts</strong> in Settings to get notified</li>
            <li><strong>🚫 Blacklist</strong> admins to hide their tokens</li>
            <li><strong>❓ Click the ? button</strong> anytime for help</li>
          </ul>
          <p>Happy trading! 🚀</p>
        `,
        icon: null,
        screenshot: null
      }
    ];
  }

  /**
   * Check if onboarding should be shown
   * @returns {Promise<boolean>} True if onboarding should be shown
   */
  async shouldShow() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        ['onboardingCompleted', 'onboardingVersion'],
        (result) => {
          const completed = result['onboardingCompleted'];
          const version = result['onboardingVersion'] || 0;
          resolve(!completed || version < 1);
        }
      );
    });
  }

  /**
   * Show the onboarding popup
   */
  async show() {
    if (this.isOpen || !(await this.shouldShow())) return;

    this.isOpen = true;
    this.currentStep = 0;
    this._createModal();

    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Bind ESC handler
    this.escapeHandlerBound = this._handleEscape.bind(this);
    document.addEventListener('keydown', this.escapeHandlerBound);

    this._renderStep(this.currentStep);
  }

  /**
   * Hide the onboarding popup
   */
  hide() {
    if (!this.isOpen) return;

    // Remove ESC handler
    if (this.escapeHandlerBound) {
      document.removeEventListener('keydown', this.escapeHandlerBound);
      this.escapeHandlerBound = null;
    }

    // Remove backdrop
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
      this.backdrop.style.display = 'none';
    }

    try {
      if (this.backdrop && this.backdrop.parentNode) {
        this.backdrop.parentNode.removeChild(this.backdrop);
      }
    } catch (e) {
      console.error('[OnboardingPopup] Error removing backdrop:', e);
    }

    document.body.classList.remove('modal-open');
    this.isOpen = false;
    this.backdrop = null;
    this.container = null;
  }

  /**
   * Mark onboarding as completed
   */
  async markCompleted() {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        'onboardingCompleted': true,
        'onboardingVersion': 1
      }, resolve);
    });
  }

  /**
   * Create the modal DOM structure
   * @private
   */
  _createModal() {
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'onboarding-modal-backdrop';

    this.container = document.createElement('div');
    this.container.className = 'onboarding-modal-container';

    this.container.innerHTML = `
      <button class="onboarding-close-button" id="onboardingCloseBtn" title="Skip">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <div class="onboarding-content">
        <div class="onboarding-icon" id="onboardingIcon"></div>
        <h2 class="onboarding-title" id="onboardingTitle"></h2>
        <div class="onboarding-body" id="onboardingBody"></div>

        <div class="onboarding-screenshot" id="onboardingScreenshot" style="display: none;">
          <div class="onboarding-skeleton-loader">
            <div class="skeleton-line"></div>
            <div class="skeleton-line"></div>
            <div class="skeleton-line"></div>
          </div>
          <img id="onboardingScreenshotImg" alt="Screenshot" />
        </div>

        <div class="onboarding-dots" id="onboardingDots"></div>
      </div>

      <div class="onboarding-footer">
        <button class="onboarding-button onboarding-back-button" id="onboardingBackBtn" style="display: none;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
          Back
        </button>
        <button class="onboarding-button onboarding-skip-button" id="onboardingSkipBtn">Skip</button>
        <button class="onboarding-button onboarding-next-button" id="onboardingNextBtn">
          Next
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </button>
      </div>
    `;

    this.backdrop.appendChild(this.container);

    // Add event listeners
    this._setupEventListeners();
  }

  /**
   * Setup event listeners for modal controls
   * @private
   */
  _setupEventListeners() {
    // Close button
    const closeBtn = this.container.querySelector('#onboardingCloseBtn');
    closeBtn.addEventListener('click', () => this._skip());

    // Back button
    const backBtn = this.container.querySelector('#onboardingBackBtn');
    backBtn.addEventListener('click', () => this._previousStep());

    // Skip button
    const skipBtn = this.container.querySelector('#onboardingSkipBtn');
    skipBtn.addEventListener('click', () => this._skip());

    // Next button
    const nextBtn = this.container.querySelector('#onboardingNextBtn');
    nextBtn.addEventListener('click', () => this._nextStep());

    // Backdrop click to close
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this._skip();
      }
    });
  }

  /**
   * Render a specific step
   * @private
   * @param {number} step - Step number to render
   */
  _renderStep(step) {
    const stepData = this.steps[step];
    if (!stepData) return;

    const content = this.container.querySelector('.onboarding-content');
    const screenshotContainer = this.container.querySelector('#onboardingScreenshot');

    // Add fade-out class
    content.classList.add('step-transition-out');

    // Wait for fade-out to complete, then update content and fade in
    setTimeout(() => {
      // Update icon
      const iconEl = this.container.querySelector('#onboardingIcon');
      if (stepData.icon) {
        iconEl.innerHTML = stepData.icon;
        iconEl.style.display = 'flex';
      } else {
        iconEl.style.display = 'none';
      }

      // Update title
      const titleEl = this.container.querySelector('#onboardingTitle');
      titleEl.textContent = stepData.title;

      // Update body content
      const bodyEl = this.container.querySelector('#onboardingBody');
      bodyEl.innerHTML = stepData.content;

      // Handle screenshot
      const screenshotImg = this.container.querySelector('#onboardingScreenshotImg');

      if (stepData.screenshot) {
        screenshotContainer.style.display = 'block';
        screenshotImg.src = stepData.screenshot;
        screenshotImg.style.display = 'none';

        // Show image when loaded
        screenshotImg.onload = () => {
          screenshotImg.style.display = 'block';
          this.container.querySelector('.onboarding-skeleton-loader')?.remove();
        };

        screenshotImg.onerror = () => {
          screenshotContainer.style.display = 'none';
        };
      } else {
        screenshotContainer.style.display = 'none';
      }

      // Update dots
      const dotsContainer = this.container.querySelector('#onboardingDots');
      dotsContainer.innerHTML = '';
      for (let i = 0; i < this.totalSteps; i++) {
        const dot = document.createElement('div');
        dot.className = 'onboarding-dot' + (i === step ? ' active' : '');
        dotsContainer.appendChild(dot);
      }

      // Update buttons
      const backBtn = this.container.querySelector('#onboardingBackBtn');
      const skipBtn = this.container.querySelector('#onboardingSkipBtn');
      const nextBtn = this.container.querySelector('#onboardingNextBtn');

      // Show/hide back button
      backBtn.style.display = step > 0 ? 'flex' : 'none';

      // Show/hide skip button (hide on last step)
      skipBtn.style.display = step < this.totalSteps - 1 ? 'inline-block' : 'none';

      // Update next button text
      if (step === this.totalSteps - 1) {
        nextBtn.innerHTML = 'Get Started <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>';
      } else {
        nextBtn.innerHTML = 'Next <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>';
      }

      // Remove fade-out and add fade-in
      content.classList.remove('step-transition-out');
      content.classList.add('step-transition-in');

      // Remove fade-in class after animation completes
      setTimeout(() => {
        content.classList.remove('step-transition-in');
      }, 200);
    }, 150);
  }

  /**
   * Go to next step
   * @private
   */
  async _nextStep() {
    if (this.currentStep < this.totalSteps - 1) {
      this.currentStep++;
      this._renderStep(this.currentStep);
    } else {
      await this._complete();
    }
  }

  /**
   * Go to previous step
   * @private
   */
  _previousStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this._renderStep(this.currentStep);
    }
  }

  /**
   * Skip onboarding
   * @private
   */
  async _skip() {
    await this.markCompleted();
    this.hide();
  }

  /**
   * Complete onboarding
   * @private
   */
  async _complete() {
    await this.markCompleted();
    this.hide();
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape(e) {
    if (e.key === 'Escape' && this.isOpen) {
      this._skip();
    }
  }
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.OnboardingPopup = OnboardingPopup;

  // Auto-initialize onboarding when this script loads
  // Run after a delay to ensure page is ready
  setTimeout(async () => {
    try {
      console.log('[OnboardingPopup] Checking if onboarding should show...');
      const onboarding = new OnboardingPopup();
      const shouldShow = await onboarding.shouldShow();
      console.log('[OnboardingPopup] shouldShow:', shouldShow);
      if (shouldShow) {
        console.log('[OnboardingPopup] Showing onboarding popup...');
        onboarding.show();
      } else {
        console.log('[OnboardingPopup] Onboarding already completed');
      }
    } catch (error) {
      console.error('[OnboardingPopup] Error initializing onboarding:', error);
    }
  }, 3500); // 3.5 second delay to ensure page is fully loaded
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OnboardingPopup;
}

} // End of duplicate load guard
