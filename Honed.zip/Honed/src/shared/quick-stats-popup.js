/**
 * Quick Stats Popup
 * Draggable, minimizable popup window for admin stats on chart pages
 */

class QuickStatsPopup {
  constructor() {
    // State
    this.isOpen = false;
    this.isMinimized = false;
    this.isDragging = false;
    this.currentUsername = null;
    this.position = { x: 20, y: 100 };
    this.dragOffset = { x: 0, y: 0 };
    this.settings = {};

    // Elements
    this.backdrop = null;
    this.container = null;
    this.header = null;
    this.content = null;

    // Bind methods
    this._handleDragStart = this._handleDragStart.bind(this);
    this._handleDragMove = this._handleDragMove.bind(this);
    this._handleDragEnd = this._handleDragEnd.bind(this);
    this._handleEscape = this._handleEscape.bind(this);
  }

  /**
   * Show popup for admin username
   * @param {string} username - Admin username
   * @param {Object} settings - Settings object
   */
  async show(username, settings = {}) {
    this.settings = settings;

    // Clean up any stale popups first (in case of page navigation)
    this._cleanupStalePopups();

    if (this.isOpen) {
      // If same username, just ensure visible
      if (this.currentUsername === username) {
        if (this.isMinimized) {
          this.expand();
        }
        return;
      }
      // Different username, close and reopen
      this.hide();
    }

    this.currentUsername = username;
    this.isOpen = true;

    // Load saved position
    await this._loadPosition();

    // Create popup structure
    this._createPopup();

    // Add to DOM
    document.body.appendChild(this.backdrop);

    // Listen for ESC key
    document.addEventListener('keydown', this._handleEscape);

    // Load and render data
    await this._fetchAndRenderData(username);

    // Start periodic validation check (auto-closes if page changes)
    this._startValidationCheck();
  }

  /**
   * Start periodic validation to ensure popup should still be visible
   * @private
   */
  _startValidationCheck() {
    // Clear any existing interval
    if (this.validationInterval) {
      clearInterval(this.validationInterval);
    }

    // Check every 500ms if popup should still be visible
    this.validationInterval = setInterval(() => {
      if (!this.isOpen) {
        clearInterval(this.validationInterval);
        return;
      }

      // Check if we should still be showing the popup
      const shouldClose = this._shouldClosePopup();

      if (shouldClose) {
        this.hide();
        clearInterval(this.validationInterval);
      }
    }, 500);
  }

  /**
   * Check if popup should be closed based on current page state
   * @private
   */
  _shouldClosePopup() {
    // Close if no longer on a chart page
    const path = window.location.pathname;
    const isChartPage = path.includes('/trade/solana/') || path.includes('/trade/');

    if (!isChartPage) {
      return true; // Not on chart page, close popup
    }

    // Close if the admin on the page has changed
    const chartHeader = document.getElementById('chart-admin-header');
    if (chartHeader) {
      const usernameEl = chartHeader.querySelector('.chart-admin-username');
      const pageUsername = usernameEl ? usernameEl.getAttribute('data-username') : null;

      if (pageUsername && pageUsername !== this.currentUsername) {
        return true; // Different admin now, close popup
      }
    }

    // Close if the chart header for this admin no longer exists
    if (!chartHeader && this.currentUsername) {
      // Try to find if there's a chart header at all
      const anyChartHeader = document.getElementById('chart-admin-header');
      if (anyChartHeader) {
        const usernameEl = anyChartHeader.querySelector('.chart-admin-username');
        const pageUsername = usernameEl ? usernameEl.getAttribute('data-username') : null;
        if (pageUsername && pageUsername !== this.currentUsername) {
          return true;
        }
      }
    }

    return false; // Should stay open
  }

  /**
   * Hide popup
   */
  hide() {
    if (!this.isOpen) return;

    // Clear validation interval
    if (this.validationInterval) {
      clearInterval(this.validationInterval);
      this.validationInterval = null;
    }

    // Reset button active state in the chart header
    const quickStatsBtn = document.querySelector('.quick-stats-toggle-btn.active');
    if (quickStatsBtn) {
      quickStatsBtn.classList.remove('active');
    }

    // Remove drag event listeners
    window.removeEventListener('mousemove', this._handleDragMove, { capture: true });
    window.removeEventListener('mouseup', this._handleDragEnd, { capture: true });

    // Remove ESC key listener
    document.removeEventListener('keydown', this._handleEscape);

    // Hide from view immediately
    if (this.backdrop) {
      this.backdrop.style.display = 'none';
    }

    // Remove from DOM
    if (this.backdrop && this.backdrop.parentNode) {
      this.backdrop.parentNode.removeChild(this.backdrop);
    }

    this.isOpen = false;
    this.isMinimized = false;
    this.currentUsername = null;
    this.backdrop = null;
    this.container = null;
    this.header = null;
    this.content = null;
  }

  /**
   * Force hide any existing popup instances (cleanup for stale popups)
   * @private
   */
  _cleanupStalePopups() {
    // Remove any existing quick-stats-popup-backdrop elements
    const existingBackdrops = document.querySelectorAll('.quick-stats-popup-backdrop');
    existingBackdrops.forEach(backdrop => {
      if (backdrop.parentNode) {
        backdrop.parentNode.removeChild(backdrop);
      }
    });
  }

  /**
   * Minimize popup to title bar only
   */
  minimize() {
    if (!this.isOpen || this.isMinimized) return;
    this.isMinimized = true;
    this.container.classList.add('minimized');

    // Update minimize button to expand button
    const minimizeBtn = this.header.querySelector('.quick-stats-minimize-btn');
    if (minimizeBtn) {
      minimizeBtn.style.display = 'none';
    }

    // Show expand button
    let expandBtn = this.header.querySelector('.quick-stats-expand-btn');
    if (!expandBtn) {
      expandBtn = document.createElement('button');
      expandBtn.className = 'quick-stats-expand-btn';
      expandBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>`;
      expandBtn.title = 'Expand';
      expandBtn.addEventListener('click', () => this.expand());
      this.header.querySelector('.quick-stats-popup-controls').insertBefore(expandBtn, this.header.querySelector('.quick-stats-close-btn'));
    }
    expandBtn.style.display = 'flex';
  }

  /**
   * Expand popup from minimized state
   */
  expand() {
    if (!this.isOpen || !this.isMinimized) return;
    this.isMinimized = false;
    this.container.classList.remove('minimized');

    // Update expand button to minimize button
    const expandBtn = this.header.querySelector('.quick-stats-expand-btn');
    if (expandBtn) {
      expandBtn.style.display = 'none';
    }

    // Show minimize button
    const minimizeBtn = this.header.querySelector('.quick-stats-minimize-btn');
    if (minimizeBtn) {
      minimizeBtn.style.display = 'flex';
    }
  }

  /**
   * Toggle minimize/expand state
   */
  toggleMinimize() {
    if (this.isMinimized) {
      this.expand();
    } else {
      this.minimize();
    }
  }

  /**
   * Create popup DOM structure
   * @private
   */
  _createPopup() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'quick-stats-popup-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'quick-stats-popup-container';
    this.container.style.left = this.position.x + 'px';
    this.container.style.top = this.position.y + 'px';

    // Create header
    this.header = document.createElement('div');
    this.header.className = 'quick-stats-popup-header';
    this.header.innerHTML = `
      <div class="quick-stats-popup-title">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <path d="M3 9h18"/>
          <path d="M9 21V9"/>
        </svg>
        Quick Stats
      </div>
      <div class="quick-stats-popup-controls">
        <button class="quick-stats-minimize-btn" title="Minimize">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="4 14 10 14 10 20"/>
            <polyline points="20 10 14 10 14 4"/>
            <line x1="14" y1="10" x2="21" y2="3"/>
            <line x1="3" y1="21" x2="10" y2="14"/>
          </svg>
        </button>
        <button class="quick-stats-close-btn" title="Close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
    `;

    // Create content
    this.content = document.createElement('div');
    this.content.className = 'quick-stats-popup-content';

    // Add loading skeleton
    this.content.innerHTML = `
      <div class="quick-stats-loading">
        <div class="quick-stats-loading-skeleton"></div>
        <div class="quick-stats-loading-skeleton"></div>
        <div class="quick-stats-loading-skeleton"></div>
      </div>
    `;

    // Assemble popup
    this.container.appendChild(this.header);
    this.container.appendChild(this.content);
    this.backdrop.appendChild(this.container);

    // Setup drag handlers
    this._setupDragHandlers();

    // Setup button handlers
    const minimizeBtn = this.header.querySelector('.quick-stats-minimize-btn');
    minimizeBtn.addEventListener('click', () => this.minimize());

    const closeBtn = this.header.querySelector('.quick-stats-close-btn');
    closeBtn.addEventListener('click', () => this.hide());
  }

  /**
   * Setup drag event handlers
   * @private
   */
  _setupDragHandlers() {
    this.header.addEventListener('mousedown', this._handleDragStart);
  }

  /**
   * Handle drag start
   * @private
   */
  _handleDragStart(e) {
    // Don't drag if clicking on buttons
    if (e.target.closest('button')) return;

    this.isDragging = true;

    const rect = this.container.getBoundingClientRect();
    this.dragOffset = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    this.container.classList.add('dragging');

    // Use window instead of document for better event capture
    // Use capture: true to catch events before they might be cancelled
    window.addEventListener('mousemove', this._handleDragMove, { capture: true });
    window.addEventListener('mouseup', this._handleDragEnd, { capture: true });

    // Failsafe: end drag if mouse leaves the window
    window.addEventListener('mouseleave', this._handleDragEnd, { once: true });
  }

  /**
   * Handle drag move
   * @private
   */
  _handleDragMove(e) {
    if (!this.isDragging) return;

    let newX = e.clientX - this.dragOffset.x;
    let newY = e.clientY - this.dragOffset.y;

    // Constrain to viewport
    const maxX = window.innerWidth - this.container.offsetWidth;
    const maxY = window.innerHeight - this.container.offsetHeight;

    newX = Math.max(0, Math.min(newX, maxX));
    newY = Math.max(0, Math.min(newY, maxY));

    this.container.style.left = newX + 'px';
    this.container.style.top = newY + 'px';

    this.position = { x: newX, y: newY };
  }

  /**
   * Handle drag end
   * @private
   */
  _handleDragEnd = () => {
    if (!this.isDragging) return;

    this.isDragging = false;
    this.container.classList.remove('dragging');
    this._savePosition();

    // Remove event listeners
    window.removeEventListener('mousemove', this._handleDragMove, { capture: true });
    window.removeEventListener('mouseup', this._handleDragEnd, { capture: true });
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape(e) {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  }

  /**
   * Load saved position from storage
   * @private
   */
  async _loadPosition() {
    if (typeof QuickStatsPopupStorage !== 'undefined') {
      const saved = await QuickStatsPopupStorage.getPosition();
      if (saved) {
        // Validate position is within viewport
        const maxX = window.innerWidth - 320;
        const maxY = window.innerHeight - 600;
        if (saved.x >= 0 && saved.x <= maxX && saved.y >= 0 && saved.y <= maxY) {
          this.position = saved;
        }
      }
    }
  }

  /**
   * Save current position to storage
   * @private
   */
  async _savePosition() {
    if (typeof QuickStatsPopupStorage !== 'undefined') {
      await QuickStatsPopupStorage.setPosition(this.position.x, this.position.y);
    }
  }

  /**
   * Fetch and render data for username
   * @private
   */
  async _fetchAndRenderData(username) {
    try {
      const data = await this._fetchData(username);
      this._renderContent(data.stats, data.tokens, this.settings);
    } catch (error) {
      console.error('[QuickStatsPopup] Error fetching data:', error);
      this._renderError();
    }
  }

  /**
   * Fetch stats and tokens for username
   * @private
   */
  async _fetchData(username) {
    if (typeof SheetsData === 'undefined') {
      throw new Error('SheetsData not available');
    }

    // Get stats
    const stats = await SheetsData.getAdminStats(username);

    // Get tokens
    const tokens = await SheetsData.getAdminTokens(username);

    return { stats, tokens };
  }

  /**
   * Render popup content
   * @private
   */
  _renderContent(stats, tokens, settings = {}) {
    if (!stats || !tokens) {
      this._renderEmpty();
      return;
    }

    // Only show score distribution in popup if it's disabled on the chart page
    const showScoreDistribution = settings.showChartScoreDistro !== true;

    let contentHtml = '';

    if (showScoreDistribution) {
      contentHtml += `
        <div class="quick-stats-section">
          <div class="quick-stats-section-title">Score Distribution</div>
          <div class="quick-stats-score-grid">
            ${this._renderScoreDistribution(stats)}
          </div>
        </div>
      `;
    }

    contentHtml += `
      <div class="quick-stats-section">
        <div class="quick-stats-section-title">Performance Trend</div>
        <div class="quick-stats-trend-chart-wrapper">
          <canvas id="quickStatsTrendChart" class="quick-stats-trend-chart-canvas"></canvas>
        </div>
      </div>
      <div class="quick-stats-section">
        <div class="quick-stats-section-title">Top 5 Tokens</div>
        <div class="quick-stats-tokens-list">
          ${this._renderTopTokens(tokens)}
        </div>
      </div>
    `;

    this.content.innerHTML = contentHtml;

    // Attach copy CA button handlers
    const copyButtons = this.content.querySelectorAll('.quick-stats-copy-ca-btn');
    copyButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        const address = btn.getAttribute('data-address');
        if (address) {
          navigator.clipboard.writeText(address).then(() => {
            // Show copied feedback
            const originalHtml = btn.innerHTML;
            btn.classList.add('copied');
            btn.innerHTML = `
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            `;

            setTimeout(() => {
              btn.classList.remove('copied');
              btn.innerHTML = originalHtml;
            }, 1500);
          }).catch(err => {
            console.error('[QuickStatsPopup] Failed to copy address:', err);
          });
        }
      });
    });

    // Load token images
    this._loadTokenImages(tokens);

    // Render trend chart after DOM is ready
    requestAnimationFrame(() => {
      this._renderTrendChart(tokens);
    });
  }

  /**
   * Load token images using MEVX API
   * @private
   */
  async _loadTokenImages(tokens) {
    // Sort to get top 5 tokens (same logic as _renderTopTokens)
    const sortedTokens = [...tokens]
      .sort((a, b) => {
        const scoreA = a.token_score ?? 999;
        const scoreB = b.token_score ?? 999;
        if (scoreA !== scoreB) return scoreA - scoreB;
        const athA = a.ath_market_cap ?? 0;
        const athB = b.ath_market_cap ?? 0;
        return athB - athA;
      })
      .slice(0, 5);

    // Get addresses that need images
    const addressesToFetch = sortedTokens
      .map(t => t.base_token)
      .filter(addr => addr && addr.length > 0);

    if (addressesToFetch.length === 0) {
      return;
    }

    // Fetch image URLs from MEVX API
    if (typeof MevxApiClient !== 'undefined') {
      const mevxClient = new MevxApiClient();
      const results = await mevxClient.fetchBatchTokens(addressesToFetch);

      // Update images in DOM - results is a Map
      results.forEach((data, address) => {
        if (data && data.logo) {
          const imgEl = this.content.querySelector(`.quick-stats-token-image[data-address="${address}"]`);
          const placeholderEl = this.content.querySelector(`.quick-stats-token-image[data-address="${address}"]`)?.parentElement?.querySelector('.quick-stats-token-image-placeholder');

          if (imgEl) {
            imgEl.src = data.logo;
            imgEl.onload = () => {
              imgEl.style.display = 'block';
              if (placeholderEl) {
                placeholderEl.style.display = 'none';
              }
            };
            imgEl.onerror = () => {
              // Keep placeholder if image fails to load
            };
          }
        }
      });
    }
  }

  /**
   * Render score distribution HTML
   * @private
   */
  _renderScoreDistribution(stats) {
    const scores = [
      { value: 0, count: stats.tokens_score_0 || 0 },
      { value: 1, count: stats.tokens_score_1 || 0 },
      { value: 2, count: stats.tokens_score_2 || 0 },
      { value: 3, count: stats.tokens_score_3 || 0 },
      { value: 4, count: stats.tokens_score_4 || 0 },
      { value: 5, count: stats.tokens_score_5 || 0 },
      { value: 'F', count: stats.tokens_score_6 || 0, failed: true }
    ];

    return scores.map(score => `
      <div class="quick-stats-score-item quick-stats-score-${score.failed ? 'failed' : score.value}">
        <span class="quick-stats-score-value">${score.value}</span>
        <span class="quick-stats-score-count">${score.count}</span>
      </div>
    `).join('');
  }

  /**
   * Render top 5 tokens HTML
   * @private
   */
  _renderTopTokens(tokens) {
    // Debug: log the tokens before sorting
    console.log('[QuickStatsPopup] Tokens before sort:', tokens.map(t => ({ score: t.token_score, symbol: t.token_symbol, ath: t.ath_market_cap })));

    // Sort by score (lower is better), then by ATH (higher is better)
    const sortedTokens = [...tokens].sort((a, b) => {
      const scoreA = a.token_score ?? 999;
      const scoreB = b.token_score ?? 999;
      if (scoreA !== scoreB) return scoreA - scoreB;
      const athA = a.ath_market_cap ?? 0;
      const athB = b.ath_market_cap ?? 0;
      return athB - athA;
    });

    // Debug: log after sorting
    console.log('[QuickStatsPopup] Tokens after sort:', sortedTokens.map(t => ({ score: t.token_score, symbol: t.token_symbol, ath: t.ath_market_cap })));

    // Get top 5 tokens (regardless of score)
    const top5 = sortedTokens.slice(0, 5);

    if (top5.length === 0) {
      return `<div class="quick-stats-empty">No top tokens found</div>`;
    }

    return top5.map(token => {
      const address = token.base_token || '';
      const hasAddress = address && address.length > 0;
      const symbol = token.token_symbol || 'N/A';

      return `
        <div class="quick-stats-token-card" data-token-address="${this._escapeHtml(address)}">
          <div class="quick-stats-token-image-wrapper">
            <div class="quick-stats-token-image-placeholder">${this._escapeHtml(symbol.charAt(0))}</div>
            <img class="quick-stats-token-image" data-address="${this._escapeHtml(address)}" alt="" style="display: none;">
          </div>
          <div class="quick-stats-token-score quick-stats-score-${token.token_score}">
            ${token.token_score}
          </div>
          <div class="quick-stats-token-info">
            <div class="quick-stats-token-symbol">${this._escapeHtml(symbol)}</div>
            <div class="quick-stats-token-ath">${this._formatATH(token.ath_market_cap)}</div>
          </div>
          ${hasAddress ? `
            <button class="quick-stats-copy-ca-btn" data-address="${this._escapeHtml(address)}" title="Copy CA">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
            </button>
          ` : ''}
        </div>
      `;
    }).join('');
  }

  /**
   * Render trend chart
   * @private
   */
  _renderTrendChart(tokens) {
    const canvas = this.content.querySelector('#quickStatsTrendChart');
    if (!canvas || !canvas.parentElement) return;

    const wrapper = canvas.parentElement;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    // Get wrapper dimensions
    const rect = wrapper.getBoundingClientRect();
    const width = rect.width;
    const height = 160;

    // Set canvas size with DPR
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // Sort tokens by creation date
    const sortedTokens = [...tokens]
      .filter(t => t.token_age !== undefined && t.token_age !== null)
      .sort((a, b) => this._parseTokenAge(a.token_age) - this._parseTokenAge(b.token_age))
      .slice(-15); // Show last 15 tokens

    if (sortedTokens.length === 0) {
      // Show empty state
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.font = '12px Inter, -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('No token data available', width / 2, height / 2);
      return;
    }

    // Chart config
    const padding = { top: 12, right: 12, bottom: 24, left: 35 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Score colors
    const scoreColors = {
      0: '#10b981', 1: '#22d3ee', 2: '#60a5fa',
      3: '#fbbf24', 4: '#fb923c', 5: '#ef4444', 6: '#ef4444'
    };

    // Draw grid and Y-axis labels
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '10px Inter, -apple-system, sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';

    for (let score = 0; score <= 6; score++) {
      const y = padding.top + (score / 6) * chartHeight;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
      ctx.fillText(score.toString(), padding.left - 4, y);
    }

    // Draw smooth trend line using bezier curves
    if (sortedTokens.length > 1) {
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.35)';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();

      // Get all points with clamped Y values
      const points = sortedTokens.map((token, i) => {
        const score = Math.min(6, Math.max(0, token.token_score || 0));
        return {
          x: padding.left + (i / (sortedTokens.length - 1)) * chartWidth,
          y: padding.top + (score / 6) * chartHeight,
          score: score
        };
      });

      // Move to first point
      ctx.moveTo(points[0].x, points[0].y);

      // Draw smooth curve through points with clamped control points
      if (points.length === 2) {
        ctx.lineTo(points[1].x, points[1].y);
      } else {
        for (let i = 0; i < points.length - 1; i++) {
          const p0 = points[Math.max(0, i - 1)];
          const p1 = points[i];
          const p2 = points[i + 1];
          const p3 = points[Math.min(points.length - 1, i + 2)];

          // Catmull-Rom to Bezier conversion with clamping
          const cp1x = p1.x + (p2.x - p0.x) / 6;
          let cp1y = p1.y + (p2.y - p0.y) / 6;
          const cp2x = p2.x - (p3.x - p1.x) / 6;
          let cp2y = p2.y - (p3.y - p1.y) / 6;

          // Clamp control points to chart bounds (prevent overshoot beyond score 0-6)
          const minY = padding.top;
          const maxY = padding.top + chartHeight;
          cp1y = Math.max(minY, Math.min(maxY, cp1y));
          cp2y = Math.max(minY, Math.min(maxY, cp2y));

          ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
        }
      }

      ctx.stroke();
    }

    // Draw data points
    sortedTokens.forEach((token, i) => {
      const x = padding.left + (sortedTokens.length > 1
        ? (i / (sortedTokens.length - 1)) * chartWidth
        : chartWidth / 2);
      const score = Math.min(6, Math.max(0, token.token_score || 0));
      const y = padding.top + (score / 6) * chartHeight;
      const color = scoreColors[score] || '#888';

      // Subtle glow effect
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, 4);
      gradient.addColorStop(0, color + '25');
      gradient.addColorStop(1, color + '00');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Outer ring
      ctx.strokeStyle = color + '80';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.stroke();

      // Inner circle
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, 2, 0, Math.PI * 2);
      ctx.fill();
    });

    // Token count label
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = '10px Inter, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Last ${sortedTokens.length} tokens`, width / 2, height - 10);
  }

  /**
   * Render empty state
   * @private
   */
  _renderEmpty() {
    this.content.innerHTML = `
      <div class="quick-stats-empty">
        No data available for this admin
      </div>
    `;
  }

  /**
   * Render error state
   * @private
   */
  _renderError() {
    this.content.innerHTML = `
      <div class="quick-stats-empty">
        Error loading data. Please try again.
      </div>
    `;
  }

  /**
   * Parse token age string to timestamp
   * @private
   */
  _parseTokenAge(ageString) {
    // Format: "X days ago" or date string
    if (!ageString) return 0;

    const match = ageString.match(/(\d+)\s*(day|days|hour|hours|week|weeks)/);
    if (match) {
      const value = parseInt(match[1]);
      const unit = match[2].toLowerCase();
      const now = Date.now();

      if (unit.startsWith('day')) {
        return now - (value * 24 * 60 * 60 * 1000);
      } else if (unit.startsWith('hour')) {
        return now - (value * 60 * 60 * 1000);
      } else if (unit.startsWith('week')) {
        return now - (value * 7 * 24 * 60 * 60 * 1000);
      }
    }

    // Try parsing as date
    const date = new Date(ageString);
    if (!isNaN(date.getTime())) {
      return date.getTime();
    }

    return 0;
  }

  /**
   * Parse token age to date
   * @private
   */
  _parseAgeToDate(ageString) {
    const timestamp = this._parseTokenAge(ageString);
    return new Date(timestamp);
  }

  /**
   * Format ATH market cap
   * @private
   */
  _formatATH(ath) {
    if (!ath) return 'N/A';

    const num = parseFloat(ath);
    if (isNaN(num)) return 'N/A';

    if (num >= 1000000) {
      return '$' + (num / 1000000).toFixed(2) + 'M';
    } else if (num >= 1000) {
      return '$' + (num / 1000).toFixed(1) + 'K';
    }
    return '$' + num.toFixed(0);
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   */
  _escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in scripts
if (typeof window !== 'undefined') {
  window.QuickStatsPopup = QuickStatsPopup;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QuickStatsPopup };
}
