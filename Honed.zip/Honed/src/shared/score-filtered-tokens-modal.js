/**
 * Score Filtered Tokens Modal
 * Modal for displaying tokens filtered by a specific score
 */

// Guard against duplicate script loading
if (typeof window.ScoreFilteredTokensModal !== 'undefined') {
  console.log('[ScoreFilteredTokensModal] Already loaded, skipping...');
} else {

class ScoreFilteredTokensModal {
  constructor() {
    this.backdrop = null;
    this.container = null;
    this.isOpen = false;
    this.currentUsername = null;
    this.currentScore = null;
    this.mevxClient = new MevxApiClient();
    this.abortController = null;
    this.escapeHandlerBound = null;
    this.tokenListClickBound = null;

    // Intersection Observer for lazy loading MEVX data
    this.mevxIntersectionObserver = null;
  }

  /**
   * Show modal for a specific admin and score
   * @param {string} username - Admin username
   * @param {number|string} score - Score to filter by (0-5 or 'F' for failed)
   * @param {string} adminName - Optional admin display name
   */
  async show(username, score, adminName = null) {
    if (this.isOpen) {
      this.hide();
    }

    this.currentUsername = username;
    this.currentScore = score;
    this.isOpen = true;
    this.abortController = new AbortController();

    // Create modal structure
    this._createModal();

    // Add to DOM
    document.body.appendChild(this.backdrop);
    document.body.classList.add('modal-open');

    // Load and render data
    await this._loadData(adminName);
  }

  /**
   * Hide modal
   */
  hide() {
    if (!this.isOpen) return;

    // Cancel pending requests
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    // Disconnect intersection observer
    if (this.mevxIntersectionObserver) {
      this.mevxIntersectionObserver.disconnect();
      this.mevxIntersectionObserver = null;
    }

    // Disable pointer events immediately and hide visually
    if (this.backdrop) {
      this.backdrop.style.pointerEvents = 'none';
      this.backdrop.style.display = 'none';
    }

    // Remove from DOM - use try/catch to ensure removal even if errors occur
    try {
      if (this.backdrop && this.backdrop.parentNode) {
        this.backdrop.parentNode.removeChild(this.backdrop);
      }
    } catch (e) {
      console.error('[ScoreFilteredTokensModal] Error removing backdrop:', e);
    }

    // Ensure modal-open class is removed from body
    document.body.classList.remove('modal-open');

    // Remove ESC listener
    if (this.escapeHandlerBound) {
      document.removeEventListener('keydown', this.escapeHandlerBound);
      this.escapeHandlerBound = null;
    }
    
    // Remove token list click listener
    if (this.tokenListClickBound) {
      const tokenList = document.querySelector('.score-filtered-token-list');
      if (tokenList) {
        tokenList.removeEventListener('click', this.tokenListClickBound);
      }
      this.tokenListClickBound = null;
    }

    this.isOpen = false;
    this.currentUsername = null;
    this.currentScore = null;
    this.backdrop = null;
    this.container = null;

    // Force a cleanup of any orphaned backdrops (defensive measure)
    setTimeout(() => {
      const orphanedBackdrops = document.querySelectorAll('.score-filtered-modal-backdrop');
      orphanedBackdrops.forEach(backdrop => {
        if (backdrop.parentNode) {
          console.warn('[ScoreFilteredTokensModal] Removing orphaned backdrop');
          backdrop.parentNode.removeChild(backdrop);
        }
      });
    }, 100);
  }

  /**
   * Create modal DOM structure
   * @private
   */
  _createModal() {
    // Create backdrop
    this.backdrop = document.createElement('div');
    this.backdrop.className = 'score-filtered-modal-backdrop';

    // Create container
    this.container = document.createElement('div');
    this.container.className = 'score-filtered-modal-container';

    // Score display
    const scoreDisplay = this.currentScore === 'F' ? 'Failed' : `Score ${this.currentScore}`;
    const scoreClass = this.currentScore === 'F' ? 'score-failed' : `score-${this.currentScore}`;

    // Create close button
    const closeButton = document.createElement('button');
    closeButton.className = 'score-filtered-modal-close-button';
    closeButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
    closeButton.addEventListener('click', () => this.hide());

    // Create header
    const header = document.createElement('div');
    header.className = 'score-filtered-modal-header';
    header.innerHTML = `
      <div class="score-filtered-modal-title">
        <span class="score-filtered-badge ${scoreClass}">${scoreDisplay}</span>
        <span class="score-filtered-username">@${this._escapeHtml(this.currentUsername)}</span>
      </div>
    `;

    // Create content area with loading state
    const content = document.createElement('div');
    content.className = 'score-filtered-modal-content';
    content.innerHTML = `
      <div class="score-filtered-loading">
        <div class="score-filtered-spinner"></div>
        <div class="score-filtered-loading-text">Loading tokens...</div>
      </div>
    `;

    // Assemble modal
    this.container.appendChild(closeButton);
    this.container.appendChild(header);
    this.container.appendChild(content);
    this.backdrop.appendChild(this.container);

    // Add event listeners
    this.backdrop.addEventListener('click', (e) => {
      if (e.target === this.backdrop) {
        this.hide();
      }
    });

    // Bind and store ESC handler
    this.escapeHandlerBound = this._handleEscape.bind(this);
    document.addEventListener('keydown', this.escapeHandlerBound);
  }

  /**
   * Handle ESC key press
   * @private
   */
  _handleEscape(e) {
    if (e.key === 'Escape' && this.isOpen) {
      this.hide();
    }
  }

  /**
   * Load and render data
   * @private
   */
  async _loadData(adminName) {
    const content = this.container.querySelector('.score-filtered-modal-content');
    if (!content) return;

    try {
      // Fetch admin tokens
      const tokens = await this._fetchAdminTokens();

      // Filter by score
      const filteredTokens = this._filterTokensByScore(tokens, this.currentScore);

      if (filteredTokens.length === 0) {
        this._renderEmptyState(content);
        return;
      }

      this._renderTokens(content, filteredTokens);

      // Set up lazy loading for MEVX data
      this._setupMevxLazyLoading();

    } catch (error) {
      console.error('[ScoreFilteredTokensModal] Failed to load data:', error);
      this._renderError(content, error);
    }
  }

  /**
   * Fetch admin tokens from SheetsData
   * @private
   */
  async _fetchAdminTokens() {
    if (typeof SheetsData === 'undefined') return [];

    const tokens = await SheetsData.getAdminTokens(this.currentUsername);
    return tokens || [];
  }

  /**
   * Filter tokens by score
   * @private
   */
  _filterTokensByScore(tokens, score) {
    if (!tokens || tokens.length === 0) return [];

    return tokens.filter(token => {
      if (score === 'F') {
        // Failed tokens (score 6 or is_failed_token flag)
        return token.token_score === 6 || token.token_score === '6' || token.is_failed_token === true;
      }
      // Convert score to number for comparison (token_score is stored as number in DB)
      const numericScore = parseInt(score, 10);
      return token.token_score === numericScore || token.token_score === score;
    });
  }

  /**
   * Render token list
   * @private
   */
  _renderTokens(content, tokens) {
    // Sort by score first (lower is better), then by ATH market cap within each score
    const sortedTokens = [...tokens].sort((a, b) => {
      const scoreA = a.token_score || 0;
      const scoreB = b.token_score || 0;

      // First sort by score (lower scores first)
      if (scoreA !== scoreB) {
        return scoreA - scoreB;
      }

      // Within same score, sort by ATH market cap (descending)
      return (b.ath_market_cap || 0) - (a.ath_market_cap || 0);
    });

    content.innerHTML = `
      <div class="score-filtered-token-list">
        ${sortedTokens.map(token => this._createTokenCardHTML(token)).join('')}
      </div>
      <div class="score-filtered-modal-footer">
        <div class="score-filtered-token-count">${sortedTokens.length} token${sortedTokens.length !== 1 ? 's' : ''} found</div>
      </div>
    `;

    // Add event delegation for copy buttons
    const tokenList = content.querySelector('.score-filtered-token-list');
    this.tokenListClickBound = this._handleTokenListClick.bind(this);
    tokenList.addEventListener('click', this.tokenListClickBound);
  }

  /**
   * Create token card HTML
   * @private
   */
  _createTokenCardHTML(token) {
    const scoreClass = `score-${token.token_score || 0}`;
    const formattedATH = this._formatCurrency(token.ath_market_cap || 0);
    const failedBadge = token.is_failed_token ? '<span class="score-filtered-token-failed-badge">FAILED</span>' : '';

    return `
      <div class="score-filtered-token-card" data-token-address="${this._escapeHtml(token.base_token || '')}">
        <div class="score-filtered-token-left">
          <div class="score-filtered-token-logo">
            <div class="score-filtered-token-logo-placeholder">?</div>
          </div>
          <div class="score-filtered-token-age-display">${this._formatTokenAge(token.token_age)}</div>
        </div>
        <div class="score-filtered-token-info">
          <div class="score-filtered-token-header">
            <div class="score-filtered-token-name-symbol">
              <span class="score-filtered-token-name">${this._escapeHtml(token.token_name || 'Unknown')}</span>
              <span class="score-filtered-token-symbol">${this._escapeHtml(token.token_symbol || '')}</span>
            </div>
            <div class="score-filtered-token-badges">
              <span class="score-filtered-token-score-badge ${scoreClass}">Score: ${token.token_score || 0}</span>
              ${failedBadge}
            </div>
          </div>
          <div class="score-filtered-token-description">${this._escapeHtml(token.token_description || token.token_name || '')}</div>
          <div class="score-filtered-token-metrics">
            <div class="score-filtered-token-metric">
              <span class="score-filtered-token-metric-label">ATH:</span>
              <span class="score-filtered-token-metric-value">${formattedATH}</span>
            </div>
          </div>
          <div class="score-filtered-token-address-row">
            <span class="score-filtered-token-address">${this._escapeHtml(token.base_token || '')}</span>
            <button class="score-filtered-token-copy-btn" data-token-address="${this._escapeHtml(token.base_token || '')}" title="Copy address">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
            </button>
          </div>
          <div class="score-filtered-token-socials">
            ${token.community_link ? `<a href="${this._escapeHtml(token.community_link)}" target="_blank" rel="noopener" class="score-filtered-token-social-link" title="Community">
              <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </a>` : ''}
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Set up IntersectionObserver for lazy loading MEVX data
   * @private
   */
  _setupMevxLazyLoading() {
    // Disconnect existing observer if any
    if (this.mevxIntersectionObserver) {
      this.mevxIntersectionObserver.disconnect();
    }

    const tokenList = this.container?.querySelector('.score-filtered-token-list');

    this.mevxIntersectionObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          const card = entry.target;
          const address = card.getAttribute('data-token-address');

          this.mevxIntersectionObserver.unobserve(card);

          if (card.hasAttribute('data-mevx-loading')) continue;
          card.setAttribute('data-mevx-loading', 'true');

          this._fetchSingleTokenMevxData(address, card);
        }
      }
    }, {
      root: tokenList || null,
      rootMargin: '100px',
      threshold: 0
    });

    const tokenCards = this.container.querySelectorAll('.score-filtered-token-card');
    tokenCards.forEach(card => {
      this.mevxIntersectionObserver.observe(card);
    });
  }

  /**
   * Fetch MEVX data for a single token card
   * @private
   */
  async _fetchSingleTokenMevxData(address, card) {
    if (!address || !card || !this.isOpen) return;

    try {
      const results = await this.mevxClient.fetchBatchTokens([address], () => {});

      if (!this.isOpen || !card.isConnected) return;

      const data = results.get(address);
      if (data) {
        this._updateTokenCardWithMevx(card, data);
      }

      card.removeAttribute('data-mevx-loading');

    } catch (error) {
      console.error('[ScoreFilteredTokensModal] Failed to fetch MEVX data:', error);
      card.removeAttribute('data-mevx-loading');
    }
  }

  /**
   * Update token card with MEVX data
   * @private
   */
  _updateTokenCardWithMevx(card, mevxData) {
    const logoContainer = card.querySelector('.score-filtered-token-logo');
    const socialsContainer = card.querySelector('.score-filtered-token-socials');

    // Update logo
    if (mevxData.logo && logoContainer) {
      const img = document.createElement('img');
      img.src = mevxData.logo;
      img.alt = '';
      img.crossOrigin = 'anonymous';
      img.referrerPolicy = 'no-referrer';
      img.onerror = () => {
        logoContainer.innerHTML = '<div class="score-filtered-token-logo-placeholder">?</div>';
      };
      logoContainer.innerHTML = '';
      logoContainer.appendChild(img);
    }

    // Update socials
    if (socialsContainer && mevxData.socials) {
      let socialsHtml = '';

      if (mevxData.socials.twitter) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.twitter)}" target="_blank" rel="noopener" class="score-filtered-token-social-link" title="Twitter">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
        </a>`;
      }

      if (mevxData.socials.website) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.website)}" target="_blank" rel="noopener" class="score-filtered-token-social-link" title="Website">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        </a>`;
      }

      if (mevxData.socials.telegram) {
        socialsHtml += `<a href="${this._escapeHtml(mevxData.socials.telegram)}" target="_blank" rel="noopener" class="score-filtered-token-social-link" title="Telegram">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>
        </a>`;
      }

      socialsContainer.innerHTML = socialsHtml;
    }
  }

  /**
   * Handle clicks on token list
   * @private
   */
  _handleTokenListClick(e) {
    const copyBtn = e.target.closest('.score-filtered-token-copy-btn');
    if (copyBtn) {
      e.stopPropagation();
      const address = copyBtn.getAttribute('data-token-address');
      if (address) {
        navigator.clipboard.writeText(address).then(() => {
          const originalHTML = copyBtn.innerHTML;
          copyBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
          copyBtn.classList.add('copied');
          setTimeout(() => {
            copyBtn.innerHTML = originalHTML;
            copyBtn.classList.remove('copied');
          }, 1500);
        }).catch(err => {
          console.error('[ScoreFilteredTokensModal] Failed to copy address:', err);
        });
      }
    }
  }

  /**
   * Render empty state
   * @private
   */
  _renderEmptyState(content) {
    content.innerHTML = `
      <div class="score-filtered-empty">
        <div class="score-filtered-empty-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <div class="score-filtered-empty-title">No Tokens Found</div>
        <div class="score-filtered-empty-desc">No tokens with this score exist for this admin</div>
      </div>
    `;
  }

  /**
   * Render error state
   * @private
   */
  _renderError(content, error) {
    content.innerHTML = `
      <div class="score-filtered-error">
        <div class="score-filtered-error-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        </div>
        <div class="score-filtered-error-title">Failed to Load Tokens</div>
        <div class="score-filtered-error-desc">${this._escapeHtml(error.message || 'Unknown error')}</div>
      </div>
    `;
  }

  /**
   * Format currency for display
   * @private
   */
  _formatCurrency(value) {
    const number = parseFloat(value) || 0;
    if (number >= 1000000) {
      return '$' + (number / 1000000).toFixed(2) + 'M';
    }
    if (number >= 1000) {
      return '$' + (number / 1000).toFixed(2) + 'K';
    }
    return '$' + number.toFixed(2);
  }

  /**
   * Format token age
   * @private
   */
  _formatTokenAge(ageString) {
    if (!ageString) return '';

    const match = ageString.match(/(\d+)\s*([a-z]+)\s*ago/i);
    if (!match) return `<span class="score-filtered-token-age-badge">${this._escapeHtml(ageString)}</span>`;

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    const now = new Date();
    let creationDate;

    switch (unit) {
      case 'd':
      case 'day':
      case 'days':
        creationDate = new Date(now);
        creationDate.setDate(now.getDate() - value);
        break;
      case 'mo':
      case 'month':
      case 'months':
        creationDate = new Date(now);
        creationDate.setMonth(now.getMonth() - value);
        break;
      case 'h':
      case 'hour':
      case 'hours':
        creationDate = new Date(now);
        creationDate.setHours(now.getHours() - value);
        break;
      default:
        return `<span class="score-filtered-token-age-badge">${this._escapeHtml(ageString)}</span>`;
    }

    let detailedAge = ageString.replace(/\s*ago/i, '');
    if (value >= 30 && (unit === 'd' || unit === 'day' || unit === 'days')) {
      const months = Math.floor(value / 30);
      detailedAge = `${months}mo/${value}d`;
    }

    const day = creationDate.getDate();
    const month = creationDate.toLocaleString('default', { month: 'short' });
    const year = creationDate.getFullYear();
    const currentYear = now.getFullYear();

    let dateString = `${day}${this._getOrdinal(day)} ${month}`;
    if (year !== currentYear) {
      dateString += ` ${year}`;
    }

    return `
      <div class="score-filtered-token-age-container">
        <span class="score-filtered-token-age-badge">${this._escapeHtml(detailedAge)}</span>
        <span class="score-filtered-token-date-badge">${dateString}</span>
      </div>
    `;
  }

  /**
   * Get ordinal suffix for day number
   * @private
   */
  _getOrdinal(day) {
    const j = day % 10;
    const k = day % 100;
    if (j === 1 && k !== 11) return 'st';
    if (j === 2 && k !== 12) return 'nd';
    if (j === 3 && k !== 13) return 'rd';
    return 'th';
  }

  /**
   * Escape HTML to prevent XSS
   * @private
   */
  _escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Export for use in content scripts
if (typeof window !== 'undefined') {
  window.ScoreFilteredTokensModal = ScoreFilteredTokensModal;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ScoreFilteredTokensModal;
}

} // End of duplicate load guard
